"""Ćwiczenie nr 7 Część 2 Zadanie 1  - suma liczb zmiennoprzecinkowych w linii poleceń - sys.argv"""
def main() -> None:
    """suma liczb zmiennoprzecnkowych w linii poleceń - sys.argv"""
    #print("\033c")
    print("Program, traktuje argumenty linii polecen", end=" ")
    print("jako liczby zmiennoprzecinkowe i wypisuje ich sumę.")
    input("Wciśnij ENTER aby kontynuować.")
    suma_liczb_r_linii_p()
def suma_liczb_r_linii_p() -> float:
    """ Suma liczb zmiennoprzecinkowych w linii poleceń - sys.argv"""
    import sys
    suma_ = 0.0
    dl_linii_p = len(sys.argv)
    for i in range(1, dl_linii_p):
        try:
            suma_ += float(sys.argv[i])
        except:
            continue
    print(sys.argv)
    print(suma_)
    return suma_
if __name__ == "__main__":
    main()
