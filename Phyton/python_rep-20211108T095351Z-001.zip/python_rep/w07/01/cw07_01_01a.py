"""Ćwiczenie nr 7 Część 1 Zadanie 1 Punkt A  - Słownik par znak : ilość ze znaków występującyh w łańcuchu"""
def main() -> None:
    """Słownik par znak : ilość - znaków występującyh w łańcuchu"""
    print("\033c")
    print("Program wykorzystując funkcję \"funkcja_7a\",", end=" ")
    print("pobiera łąńcuch znaków i zwraca słownik zawierający", end=" ")
    print("dla każdego znaku wystepujacego w łancuchu podanym", end=" ")
    print("jako argument informacje ile razy znak ten wystepuje", end=" ")
    print("w tym łancuchu.")
    str_str = input("\nPodaj łańcuch znaków.\n>>> ")
    ile_znak_dict = funkcja_7a(str_str)
    wiz(str_str, ile_znak_dict)

def funkcja_7a(str_str_: str) -> dict:
    """zwraca słownik zawierajacy pary znak (w łąńcuchu str_str_) : ilość """
    ile_znak_dict_ = {}
    for znak in str_str_:
        ile_znak_dict_[znak] = ile_znak_dict_[znak] + 1 if znak in ile_znak_dict_ else 1
    print(ile_znak_dict_)
    return ile_znak_dict_

def wiz(str_str_: str, ile_znak_dict_: set) -> None:
    """ wyzualizacja wyników """
    print("\033c")
    print("Podano ciąg znaków: \"{}\".".format(str_str_))
    print("Stworzono słownik:\n{}.\n".format(sorted(ile_znak_dict_.items())))
if __name__ == "__main__":
    main()
