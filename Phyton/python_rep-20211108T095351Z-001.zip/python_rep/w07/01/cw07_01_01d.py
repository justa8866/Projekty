"""Ćwiczenie nr 7 Część 1 Zadanie 1 Punkt D  - najczęściej występująca (dowolna) litera w łańcuchu"""
def main() -> None:
    """Najczęściej występująca (dowolna) litera w łańcuchu"""
    print("\033c")
    print("Program wykorzystując funkcję \"funkcja_7d\",", end=" ")
    print("pobiera łąńcuch znaków i zwraca literę", end=" ")
    print("wystepującą najczęściej", end=" ")
    print("w łancuchu podanym jako argument.", end=" ")
    print("Jeżeli jest kilka takich liter,", end=" ")
    print("to funkcja może zwrócić dowolną z nich.")

    str_str = input("\nPodaj łańcuch znaków.\n>>> ")
    litera_str = funkcja_7d(str_str)
    wiz(str_str, litera_str)

def funkcja_7d(str_str_: str) -> str:
    """zwraca dowolną literę wystepującą najczęściej w łąńcuchu str_str_"""
    from string import ascii_letters
    ile_znak_dict_ = {}
    litera_str_ = []
    for znak in str_str_:
        if znak in ascii_letters:
            ile_znak_dict_[znak] = ile_znak_dict_[znak] + 1 if znak in ile_znak_dict_ else 1
    for znak in ile_znak_dict_:
        if ile_znak_dict_[znak] == max(ile_znak_dict_.values()):
            litera_str_ = znak
    print(litera_str_)
    return litera_str_

def wiz(str_str_: str, litera_str_: str) -> None:
    """ wyzualizacja wyników """
    print("\033c")
    print("Podano ciąg znaków: \"{}\".".format(str_str_))
    print("Jedna z liter występujących najczęściej to litera: \"{}\".\n".format(litera_str_))
if __name__ == "__main__":
    main()
