"""Ćwiczenie nr 7 Część 1 Zadanie 4  - praca z rozdziałem Python instrukcj dla programisty - Słowniki"""
def main() -> None:
    """Słowniki"""
    print("\033c")
    #6.1
    dane_dict_0 = {"first_name":"Anna", "last_name":"Mika","city":"Warszawa", "age":"18"}
    print("\n6.1\n", dane_dict_0,"\n")

    #6.2
    print("\n6.2")
    dane_liczby = {"Anna":3, "Olga":3.1,"Ala":3.14, "Ela":0,"Wiola":1024}
    for imie in dane_liczby:
        print("Ulubioną liczbą dla {} jest {}.".format(imie,dane_liczby[imie]))

    #6.3
    print("\n6.3")
    s1 = "Rootkit"
    d1 = "(ang. root \"korzeń, rdzeń\") – narzędzie pomocne we włamaniach do systemów informatycznych."
    s2 = "Sniffer"
    d2 = "program komputerowy lub urządzenie, którego zadaniem jest przechwytywanie i ewentualnie analizowanie danych przepływających w sieć."
    s3 = "DDoS"
    d3 = "(ang. distributed denial of service, rozproszona odmowa usługi) – atak na system komputerowy lub usługę sieciową w celu uniemożliwienia działania poprzez zajęcie wszystkich wolnych zasobów, przeprowadzany równocześnie z wielu komputerów (np. zombie)."
    s4 = "Spoofing"
    d4 = "ang. spoof – naciąganie, szachrajstwo) – grupa ataków na systemy teleinformatyczne polegająca na podszywaniu się pod inny element systemu informatycznego."
    s5 = "Wirus albański"
    d5 = "to łańcuszek internetowy, podający się za \"wirusa\" i proszący użytkownika o rozesłanie go dalej i ewentualnie o wyrządzenie swojemu komputerowi jakiejś szkody."
    glosariusz = {}
    for i in range(1,6):
        eval("glosariusz.update({s" + str(i) + ":d" + str(i) + "})")

    for slowo in glosariusz:
        print("{}:\n{}\n".format(slowo.upper(), glosariusz[slowo]))

    #6.4
    s1 = "Tuple"
    d1 = "Tuples are used to store multiple items in a single variable."
    s2 = "Variables"
    d2 = "Variables are containers for storing data values."
    s3 = "List"
    d3 = "Lists are used to store multiple items in a single variable."
    s4 = "Set"
    d4 = "Sets are used to store multiple items in a single variable. A set is a collection which is both unordered and unindexed."
    s5 = "Dictionary"
    d5 = "Dictionaries are used to store data values in key:value pairs. A dictionary is a collection which is unordered, changeable and does not allow duplicates. Dictionaries are written with curly brackets, and have keys and values"
    for i in range(1,6):
        eval("glosariusz.update({s" + str(i) + ":d" + str(i) + "})")
    print("\n6.4")
    for slowo, definicja in glosariusz.items():
        print("{}:\n{}\n".format(slowo.upper(), definicja))

    #6.5
    print("\n6.5")
    rzeki_dict = {"Wisła":["Polska","Polskę"], "Nil":["Egipt","Egipt"],"Loara":["Franjca","Francję"]}

    for rzeka, panstwo in rzeki_dict.items():
        print("{} przepływa przez {}.".format(rzeka.title(), panstwo[1].title()))
    for rzeka in rzeki_dict:
        print("Nazwa rzeki: {} ".format(rzeka.title()))
    for panstwo in rzeki_dict.values():
        print("Państwo: {}".format(panstwo[0].title()))

    #6.6
    print("\n6.6")
    osoby_list = ["Anna", "Maciej", "Marcin", "Filip", "Jacek"]
    jezyk_dict = {"Maciej":"C+", "Filip":"Python","Anna":"Java"}
    for imie in osoby_list:
        print("{}, dziękuję za udział w ankiecie.".format(imie.title())) if imie in jezyk_dict else print("{}, UZUPEJNIJ ANKETĘ!!!.".format(imie.title()))

    #6.7
    print("\n6.7")
    dane_dict_1 = {"first_name":"Marcin", "last_name":"Wolny","city":"Opole", "age":"26"}
    dane_dict_2 = {"first_name":"Wojtek", "last_name":"Klak","city":"Łódź", "age":"23"}
    people_list = []
    for i in range(3):
        eval("people_list.append(dane_dict_"+ str(i) +")")
    for i in range(len(people_list)):
        print("Dane {} osoby:\n{}".format(i+1, people_list[i]))

    #6.8
    print("\n6.8")
    pet_dict_0 = {"owner_first_name":"Marcin", "owner_last_name":"Waron","city":"Opole", "type":"aligator","age":"2","wieght":"120","status":"w zoo"}
    pet_dict_1 = {"owner_first_name":"Anna", "owner_last_name":"Mora","city":"Warszawa", "type":"pies","age":"6","wieght":"20","status":"w schonisku"}
    pet_dict_2 = {"owner_first_name":"Maciej", "owner_last_name":"Loka","city":"Wieluń", "type":"kot","age":"1","wieght":"2","status":"u właściciela"}
    pet_dict_3 = {"owner_first_name":"Wojtek", "owner_last_name":"Naruk","city":"Radom", "type":"delfin","age":"7","wieght":"150","status":"w oceanarium"}
    pet_list = []
    for i in range(4):
        eval("pet_list.append(pet_dict_"+ str(i) +")")
    for i in range(len(pet_list)):
        print("Dane {} zwierzaka:".format(i+1))
        for cecha in pet_list[i]: 
            print(cecha, "-", pet_list[i][cecha])
        print()

    #6.9
    print("\n6.9")
    favorite_places = {"Anna":["Polska","Majorka","Lesbon"], "Ola":["Karaiby","Egipt","Turcja"],"Ala":["Franjca","Włochy","Chorwacja"], "Olga":["Rosja","Białoruś","Kazachstan"]}
    for osoba, miejsca in favorite_places.items():
        print("{:<6} - ulubione miejsca to:".format(osoba.title()), end=" ")
        for i in range(3):
            print("{:<10}".format(miejsca[i].title()), end=" ")
        print()

    #6.10
    print("\n6.10")
    dane_liczby2 = {"Anna":[3], "Olga":[3.1,0],"Ala":[3.14,7,13], "Ela":[0,1,2,3,5,7,11,13,17,19],"Wiola":[0,2,4,16,32,64,128,256, 512,1024]}
    for osoba, liczby in dane_liczby2.items():
        print("{:<6} - ulubione liczby to:".format(osoba.title()), end=" ")
        for i in range(len(liczby)):
            print("{:<4}".format(liczby[i]), end=" ")
        print()

    #6.11
    print("\n6.11")
    city_dict_0 = {"name":"Ople", "country":"Polska", "fact": "128 012 mieszkańców w czerwcu 2020 roku."}
    city_dict_1 = {"name":"Wieluń", "country":"Polska", "fact": "Wieluń uzyskał prawo składu w 1444 roku"}
    city_dict_2 = {"name":"Radom", "country":"Polska", "fact": "Przed 1795 miasto królewskie w powiecie radomskim województwa sandomierskiego."}
    city_dict = {}
    city_dict["0"] = city_dict_0
    city_dict["1"] = city_dict_1
    city_dict["2"] = city_dict_2
    #for i in range(3):
        #eval("city_dict[\""+ str(i) + "\"] = city_dict_"+ str(i))
    for i in range(len(city_dict)):
        #print(city_dict)
        print("\nDane {}. miasta: {}".format(i+1, city_dict[str(i)]))

    #6.12
    print("\n6.12")
    city_dict_3 = {"name":"Szczecin", "country":"Polska", "fact": "Szczecin jest trzecim pod względem zajmowanej powierzchni (300,55 km² z czego prawie 24% zajmują grunty pod wodami) i siódmym pod względem liczby ludności miastem Polski."}
    city_dict_4 = {"name":"Bielsko Biała", "country":"Polska", "fact": "Bielsko-Biała formalnie powstało 1 stycznia 1951 r. z połączenia położonego na Śląsku Cieszyńskim Bielska oraz małopolskiej Białej."}
    city_dict_5 = {"name":"Białystok", "country":"Polska", "fact": "Przed 1795 miasto królewskie w powiecie radomskim województwa sandomierskiego."}
    city_dict["3"] = city_dict_3
    city_dict["4"] = city_dict_4
    city_dict["5"] = city_dict_5
    #for i in range(3):
        #eval("city_dict.update(city_dict_"+ str(i) +")")
    for i in range(len(city_dict)):
        city_ = city_dict[str(i)]
        print("\nDane {} miasta:\nnazwa: {}\nkraj: {}\nfact: {}".format(i+1, city_["name"], city_["country"], city_["fact"]))
if __name__ == "__main__":
    main()

