"""Ćwiczenie nr 7 Część 1 Zadanie 2  - słownik liczb całkowitych"""
def main() -> None:
    """słownik liczb całkowitych"""
    print("\033c")
    print("Program wykorzystując funkcję \"slownik_liczb_z\",", end=" ")
    print("wczytuje liczby całkowite podawane przez użytkownika", end=" ")
    print("do słownika i okresla liczbę ich wystapień.")

    ile_liczb_dict = slownik_liczb_z()
    wiz(ile_liczb_dict)

def slownik_liczb_z() -> dict:
    """wczytuje słownik liczba całkowita : ilość wczytanych liczb"""
    ile_liczb_dict_ = {}
    nr_liczb_ = 1
    while True:
        print("\nWciśnij ENTER przed podniem liczby aby zakończyć wczytywanie.")
        print("Podaj {}. liczbę całkowitą:".format(nr_liczb_), end=" ")
        liczba_z_str_ = input()
        if liczba_z_str_ == "":
            break
        elif liczba_z_str_ == "-0":
            liczba_z_str_ = "0"
        try:
            int(liczba_z_str_)
            ile_liczb_dict_[liczba_z_str_] = ile_liczb_dict_[liczba_z_str_] + 1 if liczba_z_str_ in ile_liczb_dict_ else 1
            nr_liczb_ += 1
            print("Wczytano liczbę naturalną. Obecny stan słownika:", ile_liczb_dict_)
        except:
            print("Podany ciąg znaków nie jest liczbą całkowitą.")
    return ile_liczb_dict_

def wiz(ile_liczb_dict_: dict) -> None:
    """ wyzualizacja wyników """
    print("\033c")
    print("Utworzono słownik: \"{}\".".format(ile_liczb_dict_))

if __name__ == "__main__":
    main()

