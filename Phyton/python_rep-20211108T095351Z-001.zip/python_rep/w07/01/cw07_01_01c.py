"""Ćwiczenie nr 7 Część 1 Zadanie 1 Punkt C  - Słownik par litera : ilość liter, niezależnie od ich wielkości, występującyh w łańcuchu"""
def main() -> None:
    """Słownik par litera : ilość liter, niezależnie od ich wielkości, występującyh w łańcuchu"""
    print("\033c")
    print("Program wykorzystując funkcję \"funkcja_7c\",", end=" ")
    print("pobiera łąńcuch znaków i zwraca słownik zawierający", end=" ")
    print("informację ile razy każda litera,", end=" ")
    print("niezależnie od jej wielkości, wystepuje", end=" ")
    print("w łancuchu podanym jako argument,", end=" ")
    print("o ile w nim wystepuje chociaż raz.")
    str_str = input("\nPodaj łańcuch znaków.\n>>> ")
    ile_znak_dict = funkcja_7c(str_str)
    wiz(str_str, ile_znak_dict)

def funkcja_7c(str_str_: str) -> dict:
    """zwraca słownik zawierajacy pary litera (w łąńcuchu str_str_) : ilość liter niezależnie od ich wielkości"""
    from string import ascii_letters
    ile_znak_dict_ = {}
    for znak in str_str_.lower():
        if znak in ascii_letters:
            ile_znak_dict_[znak] = ile_znak_dict_[znak] + 1 if znak in ile_znak_dict_ else 1
    print(ile_znak_dict_)
    return ile_znak_dict_

def wiz(str_str_: str, ile_znak_dict_: set) -> None:
    """ wyzualizacja wyników """
    print("\033c")
    print("Podano ciąg znaków: \"{}\".".format(str_str_))
    print("Stworzono słownik:\n{}.\n".format(sorted(ile_znak_dict_.items())))
if __name__ == "__main__":
    main()
