f1=open('plik_text.txt', 'r')
f2=open('plik_text.txt', 'r')
f3=open('plik_text.txt', 'r')
f4=open('plik_text.txt', 'r')
from cw07_01_01a import funkcja_7a
from cw07_01_01b import funkcja_7b
from cw07_01_01c import funkcja_7c
from cw07_01_01d import funkcja_7d

funkcja_7a(f1.read())
print()
funkcja_7b(f2.read())
print()
funkcja_7c(f3.read())
print()
funkcja_7d(f4.read())
