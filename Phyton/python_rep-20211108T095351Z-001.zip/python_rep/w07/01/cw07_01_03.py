"""Ćwiczenie nr 7 Część 1 Zadanie 3  - słownik liczb w tekście"""
def main() -> None:
    """słownik liczb w tekście"""
    print("\033c")
    print("Program wykorzystując funkcję \"slownik_liczb_tekst\",", end=" ")
    print("wczytuje kolejno linie tekstu i rozkłąda na słowa", end=" ")
    print("wyszukuje liczby zapisane przy pomocy cyfr.", end=" ")
    print("Tworzy słownik którym kluczami są liczby,", end=" ")
    print("a wartościami – liczby ich wystapień")

    slownik_liczb_tekst()

def slownik_liczb_tekst() -> dict:
    """ Tworzy słownik którym kluczami są liczby w tekście, a wartościami – liczby ich wystapień"""
    from string import punctuation as znaki_
    znaki_ = znaki_.replace("-"," ")
    ile_liczb_dict_ = {}
    slowa_list_ = []
    nr_linii_ = 1
    while True:
        print("\nWciśnij ENTER przez podniem tekstu aby zakończyć wczytywanie linii.")
        print("Podaj {}. linię tekstu:".format(nr_linii_))
        linia_str_ = input(">>>")
        if linia_str_ == "":
            break

        slowa_list_ = linia_str_.split()
        for slowo in slowa_list_:
            try:
                slowo = slowo.strip(znaki_)
                slowo = slowo.replace(",",".")
                if slowo == "-0":
                    slowo = "0"
                float(slowo)
                ile_liczb_dict_[slowo] = ile_liczb_dict_[slowo] + 1 if slowo in ile_liczb_dict_ else 1
            except:
                continue
        nr_linii_ += 1
        print("Wczytano linię nr {}. Obecny stan słownika:".format(nr_linii_), ile_liczb_dict_)
    print("\033c")
    print("Utworzono słownik:\n{}.".format(ile_liczb_dict_))
    return ile_liczb_dict_
if __name__ == "__main__":
    main()

