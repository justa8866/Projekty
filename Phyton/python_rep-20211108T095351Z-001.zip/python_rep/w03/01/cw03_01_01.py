"""Ćwiczenie nr 3"""
"""Część 1 Instrukcja warunkowa."""
"""Zadanie nr 1. Napisz program, który wczyta z klawiatury liczbę zmiennoprzecinkowa i używając prostej instrukcji warunkowej wypisze na ekran wartość bezwzgledną tej liczby. W tym programie nie należy używać funkcji wbudowanej abs. """



def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def main():
    czysc_ekran()
    print("Program, nie używając funkcji wbudowanej abs, wczytuje liczbę zmiennoprzecinkową i używająć prostej instukcji warunkowej  oblicza wartość bezwzgledną tej liczby.")
    
    #wczytanie danych
    spr_1 = True
    while spr_1:
        liczba_str=input("Podaj liczbę: ")
        try:
            liczba = float(liczba_str)
            spr_1 = False
        except:
            print("Wprowadzona wartość {} nie jest liczbą.".format(liczba_str))
    
    #analiza danych
    if liczba < 0 or liczba == -0.0:
        liczba_abs = liczba * -1
    else:
        liczba_abs = liczba
              
    # wizualizacja wyniku
    czysc_ekran()
    print("Wprowadzono liczbę: {}".format(liczba))
    print("Obliczona wartość bezwzględna: {}".format(liczba_abs))

if __name__ == "__main__":
    main()
