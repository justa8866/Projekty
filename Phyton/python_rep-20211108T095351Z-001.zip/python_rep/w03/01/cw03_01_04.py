"""Ćwiczenie nr 3"""
"""Część 1 Instrukcja warunkowa."""
"""Zadanie nr 4. Napisz program znajdujacy pierwiastek równania liniowego ax+b=0. W przypadku gdy a=0, program powinien wypisac odpowiedni komunikat."""

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę zmiennoprzecinkową. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna liczba_
    spr_liczba_ = False
    liczba_=[]
    try:
        liczba_str_ = liczba_str_.strip(" ")
        liczba_str_ = liczba_str_.replace(",",".")
        liczba_ = float(liczba_str_)
        spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą.".format(liczba_str_))   
    return(spr_liczba_, liczba_)

def main():
    
    czysc_ekran()
    spac_str=" "
    print("Program oblicza pierwiastek równania liniowego:\n\n{}b\n ax + b = 0  =>  x = - ---\n{}a\n\nW przypadku gdy a = 0, program wyświetla odpowiedni komunikat o błędzie.".format(24*spac_str,24*spac_str))
    
    #wczytanie danych
    spr_w1 = False
    while spr_w1 == False:
        liczba_a_str=input("\nPodaj liczbę rzeczwistą a (równania liniowego ax + b = 0): ")
        spr_w1, liczba_a = spr_liczba(liczba_a_str)
    
    spr_w2 = False
    while spr_w2 == False:
        liczba_b_str=input("\nPodaj liczbę rzeczwistą a (równania liniowego ax + b = 0): ")
        spr_w2, liczba_b = spr_liczba(liczba_b_str)
        

    #analiza danych i wizuajizacja
    czysc_ekran()
    dl_liczba_b = len(str(liczba_b))
    if liczba_a == 0:
        czysc_ekran()
        kreska_str = dl_liczba_b * spac_str
        dl_liczba_b=len(str(liczba_b))    
        print("Niestety nie można wyznaczyć pierwiastka równania dla a = 0.\nDla a = 0,  ax + b = 0 => b = 0 - równanienie nie jest równaiem liniowym i jest prawdziwe tylko gdy b = 0.\n\n Podczas próby  obliczenia pierwiastka równania liniowego zgodnie ze wzorem:\n{}b{}{}\n ax + b = 0  =>  x = - --- = - {}\n{}a{}{:{align}{width}}\n\nnastąpiłaby próba dzielenia przez zero.".format(24*spac_str,6*spac_str, liczba_b, dl_liczba_b* "-", 24*spac_str,6*spac_str, liczba_a, align="^", width=str(dl_liczba_b)))
    else:
        dl_liczba_a = len(str(liczba_b))
        dl_liczba_b = len(str(liczba_b))
        if dl_liczba_a > dl_liczba_b:
            dl_liczba = dl_liczba_a
        else:
            dl_liczba = dl_liczba_b

        wynik = -1 * liczba_b / liczba_a

        print("Wprowadzono liczby:\na = {}\nb = {}\n".format(liczba_b, liczba_a))
        print("Obliczona wartość pierwiastka równania liniowego zgodnie ze wzorem:\n{}b      {}\n ax + b = 0  =>  x = - --- = - {} = {}\n{}a      {:{align}{width}}".format(24*spac_str, liczba_b, dl_liczba* "-",wynik, 24*spac_str, liczba_a, align="^", width=str(dl_liczba)))
    
if __name__ == "__main__":
    main()
