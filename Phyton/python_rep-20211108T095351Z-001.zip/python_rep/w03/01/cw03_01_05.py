"""Ćwiczenie nr 3"""
"""Część 1 Instrukcja warunkowa."""
"""Zadanie nr 5. Napisz program, który wczyta trzy liczby zmiennoprzecinkowe, a nastepnie wypisze najmniejszą i najwiekszą liczbę. W tym programie nie należy używac funkcji
wbudowanych min oraz max."""

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę zmiennoprzecinkową. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna liczba_
    spr_liczba_ = False
    liczba_=[]
    try:
        liczba_str_ = liczba_str_.strip(" ")
        liczba_str_ = liczba_str_.replace(",",".")
        liczba_ = float(liczba_str_)
        spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą.".format(liczba_str_))   
    return(spr_liczba_, liczba_)

def main():
    
    czysc_ekran()
    
    print("Program, nie używaąc funkci wbudowanych min oraz max, wczytuje trzy liczby zmiennoprzecinkowe i znajduje najmniejszą i największą liczę.")
    
    #wczytanie danych
    ciag=[]
    
    for i in range(1,4): # 1,2,3
        spr_w1 = False
        while spr_w1 == False:
            liczba_str=input("\nPodaj {} liczbę: ".format(i))
            spr_w1, liczba = spr_liczba(liczba_str)
        if i == 1:
            liczba_max = liczba
            liczba_min = liczba
        else:
            if liczba > liczba_max:
                liczba_max = liczba
            
            if liczba < liczba_min:
                liczba_min = liczba
        
        ciag.append(liczba)
           

    # wizuajizacja
    czysc_ekran()
    czysc_ekran()
    print("Wprowadzono następujące liczby:")
    for i in range(1,4):
        print("{}. liczba - {}".format(i,ciag[i-1]))   
      
    print("\nWyznaczono:\n- liczba najmniejsza: {}\n- liczba największa:  {}".format(liczba_min, liczba_max))
    
if __name__ == "__main__":
    main()
