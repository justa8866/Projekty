"""Ćwiczenie nr 3"""
"""Część 1 Instrukcja warunkowa."""
"""Zadanie nr 6. Napisz program rozwiazujacy problem z poprzedniego zadania z wykorzystaniem funkcji max3(x, y, z). W tym programie takze nie nalezy uzywac funkcji wbudowanych min oraz max."""

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę zmiennoprzecinkową. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna liczba_
    spr_liczba_ = False
    liczba_=[]
    try:
        liczba_str_ = liczba_str_.strip(" ")
        liczba_str_ = liczba_str_.replace(",",".")
        liczba_ = float(liczba_str_)
        spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą.".format(liczba_str_))   
    return(spr_liczba_, liczba_)

def max3(_x_, _y_ ,_z_ ):
    ciag_=[_x_, _y_, _z_]
    
    for i in range(0,3): # 0,1,2
        liczba_ = ciag_[i]
        if i == 0:
            liczba_max_ = liczba_
            liczba_min_ = liczba_
        else:
            if liczba_ > liczba_max_:
                liczba_max_ = liczba_
            
            if liczba_ < liczba_min_:
                liczba_min_ = liczba_

    return(liczba_min_, liczba_max_)

def main():
    
    czysc_ekran()
    
    print("Program, nie używaąc funkci wbudowanych min oraz max, wczytuje trzy liczby zmiennoprzecinkowe i znajduje najmniejszą i największą liczę przy użyciu funkcji max3(x, y, z).")
    
    #wczytanie danych
    ciag=[]
    for i in range(3): # 0,1,2
        spr_w1 = False
        while spr_w1 == False:
            liczba_str=input("\nPodaj {} liczbę: ".format(i+1))
            spr_w1, liczba = spr_liczba(liczba_str)
            
        ciag.append(liczba)
       
    liczba_min, liczba_max = max3(ciag[0], ciag[1], ciag[2] )
    #liczba_a liczba_b, liczba_c = ciag

    # wizuajizacja
    czysc_ekran()
    czysc_ekran()
    print("Wprowadzono następujące liczby:")
    for i in range(3):
        print("{}. liczba - {}".format(i+1,ciag[i]))   
      
    print("\nWyznaczono:\n- liczba najmniejsza: {}\n- liczba największa:  {}".format(liczba_min, liczba_max))
    
if __name__ == "__main__":
    main()
