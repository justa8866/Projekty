"""Ćwiczenie nr 3"""
"""Część 1 Instrukcja warunkowa."""
"""Zadanie nr 7. Napisz program oblicząjacy pole i obwód trójkąta o bokach wczytanych z klawiatury. W przypadku podania wartości, które nie moga być bokami trójkąta ma zostać wyświetlony komunikat: „To nie są boki trójkąta! Kończe program.”."""

import math 

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_bok_tr(bok_a_str_, bok_b_str_, bok_c_str_): 
    #funkcja sprawdza czy zmienne bok_a_str, bok_b_str, bok_c_str typu string mogą być przekonwertowana na liczby zmiennoprzecinkowe dodatnie oraz czy mogą być bokami trójkąta. Zwraca zmienną spr_trojkat_ = True gdy tak i False gdy nie oraz liczby bok_a_, bok_b_, bok_c_
    spr_bok_trojkat_ = False
    bok_a_ = []
    bok_b_ = []
    bok_c_ = []

    try:
        bok_a_ = float(bok_a_str_)
        bok_b_ = float(bok_b_str_)
        bok_c_ = float(bok_c_str_)
        if bok_a_ > 0 and bok_b_ > 0 and bok_c_ > 0 and bok_a_ + bok_b_ > bok_c_ and bok_a_ + bok_c_ > bok_b_ and bok_b_ + bok_c_ > bok_a_:
            spr_bok_trojkat_ = True
    except:
        spr_bok_trojkat_ = False
        
    return(spr_bok_trojkat_, bok_a_, bok_b_, bok_c_)

def main():
    
    czysc_ekran()
    
    print("Program oblicza pole i obwód trójkąta o bokach wczytanych z klawiatury. W przypadku podania wartosci, które nie moga byc bokami trójkąta zostanie wyswietlony komunikat: „To nie są boki trójkąta! Kończe program.”")
    
    #wczytanie danych
    bok_a_str = input("\nPodaj długość boku a: ")
    bok_b_str = input("\nPodaj długość boku b: ")
    bok_c_str = input("\nPodaj długość boku c: ")
    
       
    #analiza
    spr_bok_trojkat, bok_a, bok_b, bok_c = spr_bok_tr(bok_a_str, bok_b_str, bok_c_str)

    if spr_bok_trojkat:
        obwod_tr = bok_a + bok_b + bok_c
        pole_tr = math.sqrt((bok_a + bok_b + bok_c)*(-bok_a + bok_b + bok_c)*(bok_a - bok_b + bok_c)*(bok_a + bok_b - bok_c)) / 4
        
    # wizuajizacja
    czysc_ekran()
    print("Wprowadzono następujące długości boków trójkąta:")
    print("- bok a: ", bok_a_str)
    print("- bok b: ", bok_b_str) 
    print("- bok c: ", bok_c_str)   
    if spr_bok_trojkat:
        print("\nObliczono obwód trójkąta równy:", obwod_tr)
        print("Obliczono pole trójkąta równe: ", pole_tr,"\n")
    else:
        print("\nTo nie są boki trójkąta! Kończe program.\n")
        
if __name__ == "__main__":
    main()
