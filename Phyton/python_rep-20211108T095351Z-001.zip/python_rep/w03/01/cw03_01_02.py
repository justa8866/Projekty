"""Ćwiczenie nr 3"""
"""Część 1 Instrukcja warunkowa."""
"""Zadanie nr 2. Napisz funkcje sgn(x), która zwraca znak (inaczej: signum) swojego argumentu. (Znak liczby dodatniej jest równy 1, znak liczby ujemnej -1 dla 0 jest równy 0.) W funkcji main wczytaj liczbe zmiennoprzecinkowa, a nastepnie wypisz na ekran jej znak. """
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def sgn(x_): #funkcja sprawdza znak liczby x_ oraz zwraca zmiennią sgn_=1 dla liczby dodatniej sgn_=-1 dla ujemnej oraz 0 dla liczby 0.
    sgn_=1
    if x_ < 0:
        sgn_ = -1
    elif x_ == 0:    
        sgn_ = 0
    return(sgn_)

def main():
    
    czysc_ekran()
    print("Program wczytuje liczbę zmiennoprzecinkową i wyświetla jej znak.\n*znak liczby dodatniej jest równy 1,\n*znak liczby ujemnej jest równy -1,\n*znak liczby 0 jest równy 0.")
    
    #wczytanie danych
    spr_1 = True
    while spr_1:
        liczba_str=input("\nPodaj liczbę: ")
        try:
            liczba = float(liczba_str)
            spr_1 = False
        except:
            print("Wprowadzona wartość {} nie jest liczbą.".format(liczba_str))
    
    #analiza danych
    znak = sgn(liczba)
              
    # wizualizacja wyniku
    czysc_ekran()
    print("Wprowadzono liczbę: {}".format(liczba))
    print("Obliczona wartość znaku: {}".format(znak))
    print("\n*znak liczby dodatniej jest równy 1,\n*znak liczby ujemnej jest równy -1,\n*znak liczby 0 jest równy 0.")

if __name__ == "__main__":
    main()
