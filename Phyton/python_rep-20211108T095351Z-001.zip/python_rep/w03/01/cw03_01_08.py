"""Ćwiczenie nr 3"""
"""Część 1 Instrukcja warunkowa."""
"""Zadanie nr 8. Napisz program rozwiazujacy problem z poprzedniego zadania z wykorzystaniem trzech funkcji:
• poprawne_boki(a, b, c), która zwraca wartość True gdy jej argumenty mogą być bokami trójkata; w przeciwnym przypadku funkcja ma zwrócic wartosc False;
• pole_trojkata(a, b, c);
• obwod_trojkata(a, b, c)."""

import math 

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def poprawne_boki(a_, b_, c_): 
    #funkcja sprawdza czy zmienne bok_a_str, bok_b_str, bok_c_str typu string mogą być przekonwertowana na liczby zmiennoprzecinkowe dodatnie oraz czy mogą być bokami trójkąta. Zwraca zmienną spr_trojkat_ = True gdy tak i False gdy nie.
    spr_tr_ = False
    try:
        l_a_ = float(a_)
        l_b_ = float(b_)
        l_c_ = float(c_)
        if l_a_ > 0 and l_b_ > 0 and l_c_ > 0 and l_a_ + l_b_ > l_c_ and l_a_ + l_c_ > l_b_ and l_b_ + l_c_ > l_a_:
            spr_tr_ = True
    except:
        spr_tr_= False
        
    return(spr_tr_)

def pole_trojkata(a, b, c):
    pole_tr = math.sqrt((a + b + c)*(-a + b + c)*(a - b + c)*(a + b - c)) / 4
    
    return(pole_tr)

def obwod_trojkata(a, b, c):
    obwod_tr = a + b + c
    
    return(obwod_tr)



def main():
    
    czysc_ekran()
    
    print("Program oblicza pole i obwód trójkąta o bokach wczytanych z klawiatury (wykorzystując funkcje: poprawne_boki(a, b, c), pole_trojkata(a, b, c) i obwod_trojkata(a, b, c) ). W przypadku podania wartosci, które nie moga byc bokami trójkąta zostanie wyswietlony komunikat: „To nie są boki trójkąta! Kończe program.”")
    
    #wczytanie danych
    bok_a_str = input("\nPodaj długość boku a: ")
    bok_b_str = input("\nPodaj długość boku b: ")
    bok_c_str = input("\nPodaj długość boku c: ")
    
       
    #analiza
    if poprawne_boki(bok_a_str, bok_b_str, bok_c_str):
        bok_a = float(bok_a_str)
        bok_b = float(bok_b_str)
        bok_c = float(bok_c_str)
        pole_tr = pole_trojkata(bok_a, bok_b, bok_c) 
        obwod_tr = obwod_trojkata(bok_a, bok_b, bok_c)
    # wizuajizacja
    czysc_ekran()
    print("Wprowadzono następujące długości boków trójkąta:")
    print("- bok a: ", bok_a_str)
    print("- bok b: ", bok_b_str) 
    print("- bok c: ", bok_c_str)   
    if poprawne_boki(bok_a_str, bok_b_str, bok_c_str):
        print("\nObliczono obwód trójkąta równy:", obwod_tr)
        print("Obliczono pole trójkąta równe: ", pole_tr,"\n")
    else:
        print("\nTo nie są boki trójkąta! Kończe program.\n")
    #print("\nWyznaczono:\n- liczba najmniejsza: {}\n- liczba największa:  {}".format(liczba_min, liczba_max))
    
if __name__ == "__main__":
    main()
