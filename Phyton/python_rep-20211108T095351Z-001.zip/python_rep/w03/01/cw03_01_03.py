"""Ćwiczenie nr 3"""
"""Część 1 Instrukcja warunkowa."""
"""Zadanie nr 3. Napisz program, który wczyta dwie liczby zmiennoprzecinkowe, a nastepnie wypisze wynik z dzielenia pierwszej przez drugą, o ile druga liczba jest różna od zera. Jeżeli dzielenie nie bedzie możliwe, to należy wypisać na ekran odpowiedni komunikat."""



def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba(liczba_str_): #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę zmiennoprzecinkową. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna Liczba_
    spr_liczba_ = False
    liczba_=[]
    try:
        liczba_ = float(liczba_str_)
        spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą.".format(liczba_str_))   
    return(spr_liczba_, liczba_)

def main():
    
    czysc_ekran()
    print("Program wczytuje dwie liczby zmiennoprzecinkowe (a - dzielna i b - dzielnik). Następnie oblicza iloraz c = a/b. Program poinformuje o próbie dzielenia przez zero.")
    
    #wczytanie danych
    spr_w1 = False
    while spr_w1 == False:
        liczba_a_str=input("\nPodaj liczbę a - dzielna: ")
        spr_w1, liczba_a = spr_liczba(liczba_a_str)
    
    spr_w2 = False
    while spr_w2 == False:
        liczba_b_str=input("\nPodaj liczbę b - dzielnik: ")
        spr_w2, liczba_b = spr_liczba(liczba_b_str)
        

    #analiza danych i wizuajizacja
    czysc_ekran()
    if liczba_b == 0:
            czysc_ekran()
            print("Niestety nie można podać wyniku ilorazu a / b dla:\na - dzielna = {},\nb - dzielnik = {}.\nNastąpiła próba dzielenie przez zero.\n".format(liczba_a, liczba_b))
    else:
        wynik_c = liczba_a / liczba_b
        print("Wprowadzono liczby:\na - dzielna: {}\nb - dzielnik: {}".format(liczba_a, liczba_b))
        print("Obliczona wartość ilorazu \nc = a / b = {}".format(wynik_c))
    
if __name__ == "__main__":
    main()
