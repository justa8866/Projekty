"""Ćwiczenie nr 3"""
"""Część 2 Połaczenie instrukcji iteracyjnej for i instrukcji warunkowej"""
"""Zadanie nr 5. Wczytać liczbę naturalna n, a nastepnie wczytując kolejno n liczb rzeczywistych znaleźć ilość sasiadujących par (a ; b) takich, ze a > 0 i b > 0. (Przykład: dla liczby n = 6 i kolejnych liczb 3; 5; 2;-4; 9; 7 poprawna odpowiedz to 3 (pary (3; 5), (5; 2)
oraz (9; 7)))."""

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę zmiennoprzecinkową. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna liczba_
    spr_liczba_ = False
    liczba_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_ = float(liczba_str_)
        spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą.".format(liczba_str_))   
    return(spr_liczba_, liczba_)

def spr_liczba_N(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę naturalną. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną
    spr_liczba_ = False
    liczba_n_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_n_ = int(liczba_str_)
        if liczba_n_ > 0:
            spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą naturalną np. 1, 2, 3, ... itd.".format(liczba_str_))   
    return(spr_liczba_, liczba_n_)

def main():
    czysc_ekran()
    

    print("Program wczytuje liczbę naturalną n, a nastepnie wczytując kolejno n liczb rzeczywistych  wyznacza ilość par kolejnych liczb (a , b) takich, że a > 0 i b > 0.")
    
    #wczytanie danych
    # wczytanie liczby naturalnej
    spr_w1 = False
    while spr_w1 == False:
        liczba_n_str=input("\nPodaj liczbę naturalną (ilość liczb): ")
        spr_w1, liczba_n = spr_liczba_N(liczba_n_str)
    
    # wczytywanie i oblicznie ilości par
    
    licz_par = 0
    ciag = []
    for i in range(1,liczba_n+1):
        spr_w2 = False
        while spr_w2 == False:
            liczba_str = input("\nPodaj {} liczbę rzeczwistą: ".format(i))
            spr_w2, liczba = spr_liczba(liczba_str)
        
        if i == 1:
            liczba_i = liczba
        else:
            #liczba_i, liczba_i_m_1 = liczba, liczba_i
            if liczba_i > 0 and liczba > 0:
                licz_par += 1
            liczba_i = liczba
        ciag.append(liczba)
        
    # wizuajizacja wyników
    czysc_ekran()
    print("Wprowadzono następujące liczby:")
    for i in range(1,liczba_n+1):
        print("{}. liczba - {}".format(i,ciag[i-1]))   
    
    if licz_par == 0:
        print("\nNie znaleźono żadnej pary kolejno wczytywanych liczb (a , b) takich, że a > 0 i b > 0.")
    elif licz_par == 1: 
        print("\nWyznaczono {} parę kolejno wczytywanych liczb (a , b) takich, że a > 0 i b > 0.".format(licz_par))
    elif licz_par < 5: 
        print("\nWyznaczono {} pary kolejno wczytywanych liczb (a , b) takich, że a > 0 i b > 0.".format(licz_par))
    else:
        print("\nWyznaczono {} par kolejno wczytywanych liczb (a , b) takich, że a > 0 i b > 0.".format(licz_par)) 
    
if __name__ == "__main__":
    main()
