"""Ćwiczenie nr 3"""
"""Część 2 Połaczenie instrukcji iteracyjnej for i instrukcji warunkowej"""
"""Zadanie nr 2. Wczytać liczbę naturalną n, a nastepnie wczytując kolejno n liczb rzeczywistych obliczyć podwojoną sumę tych sposród nich, które sa dodatnie."""

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę zmiennoprzecinkową. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna liczba_
    spr_liczba_ = False
    liczba_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_ = float(liczba_str_)
        spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą.".format(liczba_str_))   
    return(spr_liczba_, liczba_)

def spr_liczba_N(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę naturalną. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną
    spr_liczba_ = False
    liczba_n_= []
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_n_ = int(liczba_str_)
        if liczba_n_ > 0:
            spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą naturalną np. 1, 2, 3, ... itd.".format(liczba_str_))   
    return(spr_liczba_, liczba_n_)

def main():
    czysc_ekran()
    

    print("Program wczytuje liczbę naturalną n, a nastepnie wczytując kolejno n liczb rzeczywistych oblicza podwojoną sumę tych sposród nich, które sa dodatnie.")
    
    #wczytanie danych
    # wczytanie liczby naturalnej
    spr_w1 = False
    while spr_w1 == False:
        liczba_n_str=input("\nPodaj liczbę naturalną (ilość liczb): ")
        spr_w1, liczba_n = spr_liczba_N(liczba_n_str)
    
    # wczytywanie i oblicznie sumy
    
    
    suma = 0
    ciag = []
    for i in range(1,liczba_n+1):
        spr_w2 = False
        while spr_w2 == False:
            liczba_str=input("\nPodaj {} liczbę rzeczwistą: ".format(i))
            spr_w2, liczba = spr_liczba(liczba_str)
        
        ciag.append(liczba)
        if liczba > 0:
            suma += 2 * liczba
        
        

    # wizuajizacja
    czysc_ekran()
    print("Wprowadzono następujące liczby:")
    for i in range(1,liczba_n+1):
        print("{}. liczba - {}".format(i,ciag[i-1]))   
      
    print("\nObliczono podwojoną sumę wprowadzonych liczb dodatnich.: {} ".format(suma))
    
if __name__ == "__main__":
    main()
