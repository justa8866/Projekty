"""Ćwiczenie nr 3"""
"""Część 2 Połaczenie instrukcji iteracyjnej for i instrukcji warunkowej"""
"""Zadanie nr 1. Do każdego z ponizszych punktów napisać odpowiedni program. W każdym z tych programów wczytać liczbę naturalna n, a następnie wczytując kolejno n liczb naturalnych obliczyć ile wsród wczytanych liczb jest takich, które:
Podpunkt e) spełniają warunek 2**k < ak < k!, dla 1 <= k <= n"""
import math

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę zmiennoprzecinkową. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna liczba_
    spr_liczba_ = False
    liczba_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_ = float(liczba_str_)
        spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą.".format(liczba_str_))   
    return(spr_liczba_, liczba_)

def spr_liczba_N(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę naturalną. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną
    spr_liczba_ = False
    liczba_n_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_n_ = int(liczba_str_)
        if liczba_n_ > 0:
            spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą naturalną np. 1, 2, 3, ... itd.".format(liczba_str_))   
    return(spr_liczba_, liczba_n_)

def main():
    czysc_ekran()
    
    print("Program wczytuje liczbę naturalna n, a nastepnie wczytując kolejno n liczb rzeczywistych oblicza ile wsród wczytanych liczb spełniających warunek:\n2\u1d4f < ak < k!, dla 1 < k < n.")
    
    #wczytanie danych
    # wczytanie liczby naturalnej
    spr_w1 = False
    while spr_w1 == False:
        liczba_n_str=input("\nPodaj liczbę naturalną (ilość liczb): ")
        spr_w1, liczba_n = spr_liczba_N(liczba_n_str)
    
    # wczytywanie i oblicznie 
    licz_e = 0
    ciag=[]
    for k in range(1,liczba_n+1):
        spr_w2 = False
        while spr_w2 == False:
            liczba_str=input("\nPodaj {} liczbę rzeczwistą: ".format(k))
            spr_w2, liczba = spr_liczba(liczba_str)
        if 2**k < liczba and liczba < math.factorial(k):
            licz_e += 1    
            
                    
        ciag.append(liczba)
        
    # wizuajizacja
    czysc_ekran()
    print("Wprowadzono następujące liczby:")
    for i in range(liczba_n):
        print("{}. liczba: {}".format(i+1,ciag[i]))   
    
    if licz_e == 0:
        print("\nNie wprowadzono żadnej liczby spełniającej warunek 2\u1d4f < ak < k! dla 1 < k < n.\n")  
    elif licz_e == 1:
        print("\nWprowadzono 1 liczbę spełniającą warunek 2\u1d4f < ak < k! dla 1 < k < n.\n")
    elif licz_e < 5: # 2, 3, 4
        print("\nWprowadzono {} {}.\n".format(licz_e, "liczby spełniające warunek 2\u1d4f < ak < k! dla 1 < k < n"))
    else: # 5 6 ...
        print("\nWprowadzono {} {}.\n".format(licz_e, "liczb spełniających warunek 2\u1d4f < ak < k! dla 1 < k < n"))
    
if __name__ == "__main__":
    main()
