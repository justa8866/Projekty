"""Ćwiczenie nr 8 Część 2 Zadanie 1 - Pliki binarne"""
def main() -> None:
    a = is_png("png2.png")
    print(a)
def is_png(nazwa_plik_rb: str) -> bool:
    png_byte = bytes([137, 80, 78, 71, 13, 10, 26, 10])
    with open(nazwa_plik_rb, "rb") as plik_rb:
        naglowek_plik = plik_rb.read(8)
    return png_byte == naglowek_plik
if __name__ == "__main__":
    main()
