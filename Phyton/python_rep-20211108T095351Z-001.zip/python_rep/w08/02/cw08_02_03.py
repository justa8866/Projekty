"""Ćwiczenie nr 8 Część 2 Zadanie 10 - Pliki binarne"""
def main() -> None:
    a = b'\x00\01\x02'
    b = b'Python'
    szyfr_a = szyfruj(a, 255)
    szyfr_b = szyfruj(b, 255)
    print("a: " + str(a))
    print("Szyfr_a: " + str(szyfr_a))
    print("b: " + str(b))
    print("Szyfr_b: " + str(szyfr_b))

def szyfruj(buf: bytes, mask: int) -> bytes:
    if not(mask in range(256)):
        return bytes(0)
    szyfr = []
    for i in buf:
        szyfr.append(i ^ mask)
    #print(szyfr)
    return bytes(szyfr)
if __name__ == "__main__":
    main()


