"""Ćwiczenie nr 8 Część 2 Zadanie 10 - Pliki binarne"""
def main() -> None:
    print("Wejście: ", str(b'\x00\x01\x02'), "Wyjście: ",szyfr_cezara(b'\x00\x01\x02', 3))
    print("Wejście: ", str(b'Python'), "Wyjście: ",szyfr_cezara(b'Python', -6))
def szyfr_cezara(buf: bytes, shift: int) -> bytes:
    szyfr = []
    for lit in buf:
        szyfr.append((lit + int(shift)) % 256 )
    return bytes(szyfr)

if __name__ == "__main__":
    main()
