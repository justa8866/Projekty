"""Ćwiczenie nr 8 Część 2 Zadanie 4 - Pliki binarne"""
def main() -> None:
    import sys
    import os.path
    if len(sys.argv) < 3:
        sys.exit("Za mało argumentów")
    nazwa_plik_rb = sys.argv[1]
    if not (os.path.isfile(nazwa_plik_rb)):
        return print("Błąd pliku źródłowego", nazwa_plik_rb)
    try:
        nazwa_plik_wb = sys.argv[2]
        open(nazwa_plik_wb, "wb")
    except:
       return print("Błąd pliku zapisu", nazwa_plik_rb) 
    try:
        maska = int(sys.argv[3])
        if not(maska in range(256)):
            return print("Błąd maski", maska)
    except:
        return print("Błąd maski", maska)
    plik_rb = open(nazwa_plik_rb, "rb")
    plik_wb = open(nazwa_plik_rb, "wb")
    while True:
        porcja32 = plik_rb.read(32)
        if len(porcja32) == 0:
            break
        szyfr32 = szyfruj(porcja32, maska)
        print(str(szyfr32))
        plik_wb.write(szyfr32)
    plik_rb.close()
    plik_wb.close()

def szyfruj(buf: bytes, mask: int) -> bytes:
    if not(mask in range(256)):
        return bytes(0)
    szyfr = []
    for i in buf:
        szyfr.append(i ^ mask)
    #print(szyfr)
    return bytes(szyfr)
if __name__ == "__main__":
    main()
