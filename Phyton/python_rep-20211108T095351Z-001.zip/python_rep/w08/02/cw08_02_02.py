"""Ćwiczenie nr 8 Część 2 Zadanie 2 - Pliki binarne"""
def main() -> None:
    import sys
    import os.path
    nazwa_plik_rb = []
    if len(sys.argv) < 3:
        sys.exit("Za mało argumentów")
    for i in range(1, len(sys.argv)):
        nazwa_plik = sys.argv[i]
        if not (os.path.isfile(nazwa_plik)):
            return print("Błąd pliku źródłowego nr {}".format(i), nazwa_plik)
        nazwa_plik_rb.append(nazwa_plik)
    spr = is_png(nazwa_plik_rb)
    print(spr)
def is_png(*nazwa_plik_rb: list) -> bool:
    spr = []
    png_byte = bytes([137, 80, 78, 71, 13, 10, 26, 10])
    for nazwa in nazwa_plik_rb[0]:
        print(nazwa)
        with open(nazwa, "rb") as plik_rb:
            naglowek_plik = plik_rb.read(8)
        spr.append(bool(png_byte == naglowek_plik))
    return spr
if __name__ == "__main__":
    main()
