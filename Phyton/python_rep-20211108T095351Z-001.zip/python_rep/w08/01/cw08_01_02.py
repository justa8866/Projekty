"""Ćwiczenie nr 8 Część 1 Zadanie 2 - Pliki tekstowe"""
def main() -> None:
    while True:
        nawa_plik_01 = input('\nPodaj nazwę pliku źródłowego: ')
        try:
            plik_r = open(nawa_plik_01, "r")
            break
        except:
            print("Nie można było otworzyć pliku: \"{}\"".format(nawa_plik_01))
            continue
    while True:
        nawa_plik_01 = input('\nPodaj nazwę pliku docelowego: ')
        try:
            plik_x = open(nawa_plik_01, "x")
            break
        except:
            print("Nie można było utwożyć nowego pliku: \"{}\"".format(nawa_plik_01))
            continue
    nr_linii = 1
    while True:
        linia = plik_r.readline()
        if linia == "":
            break
        plik_x.write(str(nr_linii) + " " + linia)
        nr_linii += 1
    plik_r.close()
    plik_x.close()

if __name__ == "__main__":
    main()
