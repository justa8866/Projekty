"""Ćwiczenie nr 8 Część 1 Zadanie 3 Punkt a - Pliki tekstowe"""
def main() -> None:
    nazwa_plik = input('\nPodaj nazwę pliku źródłowego: ')
    fun_puntk_a(nazwa_plik)
    fun_puntk_b(nazwa_plik)
    fun_puntk_c(nazwa_plik)

def fun_puntk_a(nazwa_plik_: str) -> int:
    while True:
        try:
            plik_r = open(nazwa_plik_, "r")
            break
        except:
            print("\nNie można było otworzyć pliku: \"{}\"".format(nazwa_plik_))
            dl_linii_max = None
            return dl_linii_max
    dl_linii_max = 0
    while True:
        linia = plik_r.readline()
        if linia == "":
            break
        if dl_linii_max < len(linia.strip()):
            dl_linii_max = len(linia.strip())

    plik_r.close()
    print("\nDługość najdłuższej linii pliku {} wynosi {} znaków.\nNie licząc znaku końca linii.".format(nazwa_plik_, dl_linii_max))
    dl_linii_max = None
def fun_puntk_b(nazwa_plik_: str) -> str:
    while True:
        try:
            plik_r = open(nazwa_plik_, "r")
            break
        except:
            print("\nNie można było otworzyć pliku: \"{}\"".format(nazwa_plik_))
            linii_max = None
            return linii_max 
    linii_max = ""
    while True:
        linia = plik_r.readline()
        if linia == "":
            break
        if len(linii_max) < len(linia):
            linii_max = (linia)
    plik_r.close()
    print("\nNajdłuższa linia pliku {} to:\n{}".format(nazwa_plik_, linii_max.strip()))
    return linii_max

def fun_puntk_c(nazwa_plik_: str) -> tuple:
    while True:
        try:
            plik_r = open(nazwa_plik_, "r")
            break
        except:
            print("\nNie można było otworzyć pliku: \"{}\"".format(nazwa_plik_))
            dl_linii_max = None
            linia_max = None
            return dl_linii_max, linia_max 

    linia_max = ""
    dl_linii_max = 0
    while True:
        linia = plik_r.readline()
        if linia == "":
            break
        if dl_linii_max < len(linia):
            dl_linii_max = len(linia)
            linia_max = linia
    dl_linii_max = len(linia_max.strip())
    plik_r.close()
    print("\n{} - {} znaków.\nNie licząc znaku końca linii.".format(linia_max.strip(), dl_linii_max))
    return dl_linii_max, linia_max
if __name__ == "__main__":
    main()
