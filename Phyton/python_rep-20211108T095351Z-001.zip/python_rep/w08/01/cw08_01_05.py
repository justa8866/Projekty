"""Ćwiczenie nr 8 Część 1 Zadanie 5 - Pliki tekstowe"""
def main() -> None:
    import sys
    import os.path
    linie = []
    if len(sys.argv) < 3:
        sys.exit("Za mało argumentów")
    nazwa_plik_r = sys.argv[1]
    nazwa_plik_w = sys.argv[2]
    if not (os.path.isfile(nazwa_plik_r)):
        sys.exit("Brak pliku", nazwa_plik_r)

    with open(nazwa_plik_r) as plik_r:
        for linia in plik_r:
            linie.append(linia.strip())
    with open(nazwa_plik_w, "w") as plik_w:
        plik_w.write("\n".join(reversed(linie)))
if __name__ == "__main__":
    main()
