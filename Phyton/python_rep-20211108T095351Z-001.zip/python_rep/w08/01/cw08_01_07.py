"""Ćwiczenie nr 8 Część 1 Zadanie 7 - Pliki tskstowe"""
def main() -> None:
    import sys
    import os.path
    from cw08_01_06 import reversed_line
    linie = []
    if len(sys.argv) < 2:
        sys.exit("Brak argumentów")
    nazwa_plik_w = sys.argv[1]
    if not (os.path.isfile(nazwa_plik_w)):
        return print("Brak pliku", nazwa_plik_w)
    with open(nazwa_plik_w, "r+") as plik_w:
        for linia in plik_w:
            if not linia == "\n" or linia == "":
                linia = linia.strip("\n")
                linie.append("\n" + (reversed_line(linia)))
            if linia == "\n":
                linie.append(linia)
        plik_w.seek(0)
        plik_w.write("".join(reversed(linie)))
        #plik_w.seek(0)
        #plik_w.write("".join(linie))
if __name__ == "__main__":
    main()
