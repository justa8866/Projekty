"""Ćwiczenie nr 8 Część 1 Zadanie 1 - Pliki tekstowe"""
def main() -> None:
    #Otwiera plik o nazwie hello.txt.
    plik = open("hello.txt", "w+")
    #Zapisuje w tym pliku komunikat "Hello, World!
    plik.write("Hello, World!") 
    #Zamyka ten plik.
    plik.close()
    #Otwiera ten sam plik ponownie.
    hallo_plik = open("hello.txt", "r")
    #Wczytuje z pliku komunikat do zmiennej łancuchowej.
    halo_str = hallo_plik.readline()
    #Wypisuje wczytaną linię.
    print(halo_str)
    #Zamyka ten plik.
    hallo_plik.close()
if __name__ == "__main__":
    main()
