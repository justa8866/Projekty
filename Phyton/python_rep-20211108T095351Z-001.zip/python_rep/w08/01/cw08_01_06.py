"""Ćwiczenie nr 8 Część 1 Zadanie 6 - Pliki tekstowe"""
def main() -> None:
    tekst = "teskst 01234\n"
    print("Przed: " + tekst)
    tekst = reversed_line(tekst)
    print("Po: " + tekst)
def reversed_line(tekst_str: str) -> str:
    tsket_str = tekst_str[::-1].strip('\n')
    if tekst_str.endswith('\n'):
        tsket_str += '\n'
    return tsket_str
if __name__ == "__main__":
    main()


