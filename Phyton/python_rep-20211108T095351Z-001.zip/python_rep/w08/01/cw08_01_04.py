"""Ćwiczenie nr 8 Część 1 Zadanie 4 - Pliki tekstowe"""
def main() -> None:
    import sys
    import os.path
    pliki = []
    nazwa_plik_w = ''
    if len(sys.argv) < 3:
        sys.exit('Za mało argumentów')
    for i in range(1, len(sys.argv) - 1):
        if os.path.isfile(sys.argv[i]):
            pliki.append(sys.argv[i])
        else:
            print("Plik nie istnieje: ", sys.argv[i])
    nazwa_plik_w = sys.argv[len(sys.argv) - 1]
    if len(pliki) <= 0:
        return print('No pliki')
    with open(nazwa_plik_w, 'w') as plik_w:
        for nazwa_pliku in pliki:
            with open(nazwa_pliku) as plik_r:
                plik_w.write(plik_r.read())
            plik_w.write("\n")
    if os.path.isfile(nazwa_plik_w):
        print('Zapisano plik', nazwa_plik_w)
if __name__ == "__main__":
    main()
