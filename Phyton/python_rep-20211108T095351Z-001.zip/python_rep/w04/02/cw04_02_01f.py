"""Ćwiczenie nr 4"""
"""Część 2"""  
"""Zadanie Nr 1"""
"""Do każdego z ponizszych punktów należy napisać odpowiedni program. W każdym z tych programów wczytać liczbę naturalną n, a nastepnie wczytując kolejno n liczb rzeczywistych obliczyć wartość odpowiednich wyrażeń:"""
"""Podpunkt (f) a1 + a2 + . . . + an oraz a1 * a2 * . . . * an"""

import math

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def sprawdz_N(str_):
    #funkcja sprwdza czy cig znaków może być przekonwertowany na liczbę naturalną
        
    try:
        spr_=int(str_)
        if spr_>0:
            spr_=True
        else:
            print("Podana liczba nie jest liczbą nauralną")
            spr_= False
    except:
        print("Podana liczba nie jest liczbą naturalną.")
        spr_= False
        
    return(spr_)

def sprawdz_R(str_):
        #funkcja sprwdza czy cig znaków może być przekonwertowany na liczbę rzeczywistą
    try:
        float(str_)
        spr_=True
    except:
        print("Podana liczba nie jest liczbą rzeczywistą.")
        spr_= False
        
    return(spr_)

def wprowadz_n():# wprowadzanie liczby naturalnej
    spr_ = False
    while spr_ == False:
        n_str = input("\nPodaj liczbę naturlną n - ilość wyrazów cigu: ")
        n_str = n_str.strip(" ")
        spr_ = sprawdz_N(n_str)
    return(int(n_str))

def wprowadz_ciag_R(n_):#wprowadza ciąg n liczb rzeczywistych
    ciag_ = []
    for i in range(1, n_ + 1):
        spr_ = False
        while spr_ == False:
            str_wyraz = input("Podaj {} wyraz ciągu: ".format(i))
            str_wyraz = str_wyraz.strip(" ")
            str_wyraz = str_wyraz.replace(",",".")
            spr_ = sprawdz_R(str_wyraz)
        wyraz_ = float(str_wyraz)
        ciag_.append(wyraz_)
    print(ciag_)
    return(ciag_)

def licz_f(n_,ciag_): # liczy sumę i iloczyn n wyrazów ciągu
    wynik_ = [0, 1]
    for i in range(0, n_):
        wynik_[0] += ciag_[i]
        wynik_[1] *= ciag_[i]
    return(wynik_)

def wiz(n_, ciag_, wynik_): # wizualizacja wników
    czysc_ekran()
    for i in range(1, n_ + 1):
        print("a{} = {}".format(i,ciag_[i - 1]))
    
    print("\nObliczona suma  wyrazów ciągu:    {}".format(wynik_[0]))
    print("Obliczony iloczyn  wyrazów ciągu: {}\n".format(wynik_[1]))


def main():
    czysc_ekran()
    print("Program wczytuje liczbę naturalną n, a nastepnie wczytując kolejno n liczb rzeczywistych obliczycza sumę oraz iloczyn wczytanych liczb rzeczywistych.\n")
    
    n = wprowadz_n()         # wprowdzenie ilości wyrazów ciągu     
    ciag = wprowadz_ciag_R(n) # wprowdzenie kolejnych wyrazów ciągu
    
    wynik_a = licz_f(n, ciag) #obliczanie 
    
    wiz(n, ciag, wynik_a)
        
if __name__ == "__main__":
    main()
