"""Ćwiczenie nr 4"""
"""Część 3"""  
"""Zadanie Nr 1"""
"""Wczytać liczbę naturalna do zmiennej n. Do kazdego z poniższych punktów napisać odpowiedni program."""
"""Podpunkt (a)Znaleźć wszystkie liczby mniejsze od n wzajemnie pierwsze z liczbą n."""

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba_N(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę naturalną. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną.
    spr_liczba_ = False
    liczba_n_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_n_ = int(liczba_str_)
        if liczba_n_ > 0:
            spr_liczba_ = True
        else:
            print("Wprowadzona liczba {} nie jest liczbą naturalną np. 1, 2, 3, ... itd.".format(liczba_n_))      
    except:
        print("Wprowadzona wartość {} nie jest liczbą naturalną np. 1, 2, 3, ... itd.".format(liczba_str_))   
    return(spr_liczba_, liczba_n_)

def wprowadz_n(): #wczytuje n
    spr_n_ = False
    while spr_n_ == False:
        n_str_=input("\nPodaj liczbę naturalną n: ")
        spr_n_, liczba_n_ = spr_liczba_N(n_str_)
    return(liczba_n_)

def nwd(a_, b_): 
    if b_ > 0:
        return(nwd(b_, a_ % b_))
    else:
        return(a_)

def licz_a(liczba_n_): # wyznacz liczby względnie pierwsze do n mniejsze od n
    ciag_ = [1]
    for i in range(2, liczba_n_):
        nwd_ = nwd(i, liczba_n_)
        if nwd_ == 1:
            ciag_.append(i)
    return (ciag_)

def wiz(n_, wynik_a_): #wizualizacja
    czysc_ekran()
    print("Dla liczby naturalnej n = {} wyznaczono następujące liczby mniejsze od n względnie pierwsze do n:\n{}.\n".format(n_, wynik_a_))

def main():
    czysc_ekran()
    print("Program wczytuje liczbę naturalną n.\nNastepnie oblicza wszystkie liczby mniejsze od n wzajemnie pierwsze z liczbą n.\n")
    
    n = wprowadz_n()         # wczytanie liczby n     
    
    wynik_a = licz_a(n) #obliczanie liczb względnie pierwszych 
    
    wiz(n, wynik_a) # wizualizacja
        
if __name__ == "__main__":
    main()
