"""Ćwiczenie nr 4"""
"""Część 3"""  
"""Zadanie Nr 2"""
"""Wczytać liczbę naturalna do zmiennej n. Wiadomo, że każdą liczbę można przedstawić w postaci sumy kwadratów nie wiecej
niż 4 liczb naturalnych (twierdzenie Lagrange’a). Znaleźć liczby naturalne a, b, c, d,
takie że n = a^2 + b^2 + c^2 + d^2."""
import math
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba_N(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę naturalną. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną.
    spr_liczba_ = False
    liczba_n_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_n_ = int(liczba_str_)
        if liczba_n_ > 0:
            spr_liczba_ = True
        else:
            print("Wprowadzona liczba {} nie jest liczbą naturalną np. 1, 2, 3, ... itd.".format(liczba_n_))      
    except:
        print("Wprowadzona wartość {} nie jest liczbą naturalną np. 1, 2, 3, ... itd.".format(liczba_str_))   
    return(spr_liczba_, liczba_n_)

def wprowadz_n(): #wczytuje n
    spr_n_ = False
    while spr_n_ == False:
        n_str_=input("\nPodaj liczbę naturalną n: ")
        spr_n_, liczba_n_ = spr_liczba_N(n_str_)
    return(liczba_n_)

def licz(liczba_n_): # wyznacz liczby względnie pierwsze do n mniejsze od n
    r_ = liczba_n_
    il_licz_ = 4
    
    abcd_ = [0, 0, 0, 0]
    for i in range(0,4):
        abcd_[i] = math.floor(math.sqrt(r_))
        r_ -= (abcd_[i])**2
        print(r_)
        print(i)
        print(abcd_)
            
    il_licz_ = 4 - abcd_.count(0)
    return (abcd_, il_licz_)


def wiz(n_, abcd_, il_licz_): #wizualizacja
    czysc_ekran()
    if il_licz_ == 1:
        print("Dla liczby naturalnej n = {} wyznaczono {} liczbę naturalna a = {} (b, c, d = 0) takie że:\nn = a\u00B2 + b\u00B2 + c\u00B2 + d\u00B2\nczyli: {} = {}\u00B2".format(n_, il_licz_, abcd_[0], n_,abcd_[0]))
    elif il_licz_ == 2:
        print("Dla liczby naturalnej n = {} wyznaczono {} liczby naturalne a = {} i b = {} (c, d = 0) takie że:\nn = a\u00B2 + b\u00B2 + c\u00B2 + d\u00B2\nczyli: {} = {}\u00B2 + {}\u00B2".format(n_, il_licz_, abcd_[0], abcd_[1], n_,abcd_[0], abcd_[1]))
    elif il_licz_ == 3:
        print("Dla liczby naturalnej n = {} wyznaczono {} liczby naturalne a = {}, b = {}, c = {} (d = 0) takie że:\nn = a\u00B2 + b\u00B2 + c\u00B2 + d\u00B2\nczyli: {} = {}\u00B2 + {}\u00B2 + {}\u00B2".format(n_, il_licz_, abcd_[0], abcd_[1], abcd_[2], n_,abcd_[0], abcd_[1], abcd_[2]))
    else:
        print("Dla liczby naturalnej n = {} wyznaczono {} liczby naturalne a = {}, b = {}, c = {} i d = {} takie że:\nn = a\u00B2 + b\u00B2 + c\u00B2 + d\u00B2\nczyli: {} = {}\u00B2 + {}\u00B2 + {}\u00B2 + {}\u00B2".format(n_, il_licz_, abcd_[0], abcd_[1], abcd_[2],  abcd_[3], n_,abcd_[0], abcd_[1], abcd_[2], abcd_[3]))

def main():
    czysc_ekran()
    print("Program wczytuje liczbę naturalną n.\nNastepnie oblicza nie więcej niż 4 liczby naturalne (a, b, c i d) takie że:\nn = a\u00B2 + b\u00B2 + c\u00B2 + d\u00B2.\n")
    
    n = wprowadz_n()         # wczytanie liczby n     
    
    abcd, il_licz = licz(n) #obliczanie liczb względnie pierwszych 
    
    wiz(n, abcd, il_licz) # wizualizacja
        
if __name__ == "__main__":
    main()
