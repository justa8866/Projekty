"""Ćwiczenie nr 4"""
"""Część 4 Napisy"""
"""Zadanie nr 2. Napisz funkcje remove_all(napis, usuwany), której wynikiem jest napis powstały poprzez usuniecie z napisu bedacego jej pierwszym argumentem, wszystkich wystapien napisu bedacego jej drugim argumentem. Przykładowo, wynikiem wywołania remove("abrakadabra", "ab") bedzie napis "rakadra". W funkcji main przetestuj działanie funkcji remove_all."""
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def remove_all(napis, usuwany):# z napisu napis usuwa wszystkie wystąpienia napisu usuwany 
    napis_new = napis.replace(usuwany,"")
    
    return(napis_new)

def main():
    czysc_ekran()
    
    print("Program wczytuje dwa ciągi znaków.\nNastępnie usuwa wszystkie wystąpienia drugiego ciągu znaków z ciągu pierwszego.\n")
    
    # wczytanie ciągów znaków
    str_1 = ""
    str_2 = ""

    spr_z1 = False
    while spr_z1 == False:
        str_1 = input("\nPodaj pierwszy ciąg znaków: ")
        if str_1 != "":
            spr_z1 = True
        else:
            print("Ciąg nie może być pusty.")
    spr_z2 = False
    while spr_z2 == False:
        str_2 = input("\nPodaj drugi ciąg znaków: ")
        if str_2 != "" and str_1.count(str_2) > 0:
            spr_z2 = True
        elif str_1.count(str_2) == 0:
            print("Podany ciąg znaków nie występuje z ciągu pierwszym")
        else:
            print("Ciąg nie może być pusty.")
    
    # oblicznie - usuwanie z z1 ciągu z2 
    str_new = remove_all(str_1,str_2)
        
    # wizuajizacja
    czysc_ekran()
    print("Wprowadzono następujące ciągi znaków:")
    print("Ciąg nr 1:",str_1)
    print("Ciąg nr 2:",str_2)
    print("Ciąg nr 3:",str_new,"\n\nCiąg nr 3 powstał na skutek usunięcia wszystkich wystąpień drugiego ciągu znaków z ciągu pierwszego.")

    
if __name__ == "__main__":
    main()

