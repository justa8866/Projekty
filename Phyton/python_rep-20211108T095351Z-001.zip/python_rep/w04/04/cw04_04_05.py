"""Ćwiczenie nr 4"""
"""Część 4 Napisy"""
"""Zadanie nr 5. Napisz funkcje mirror(napis), która z napisu bedącego jej argumentem tworzy napis bedący konkatenacją (czyli złączeniem) tego argumentu i jego odwrócenia. Przykładowo, wywołanie mirror("linka") powinno zwrócić napis "linkaaknil". W funkcji main przetestuj działanie funkcji mirror."""

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def mirror(napis):# z napisu tworzy odwrócony napis 
    
    sipan = ""
    for i in napis:
        sipan = i + sipan
    mirror_napis = napis + sipan
    return(mirror_napis)

def main():
    czysc_ekran()
    
    print("Program wczytuje napis.\nNastępnie tworzy napis bedący konkatenacją (czyli złączeniem) tego napisu i jego odwrócenia.\n")
    
    # wczytanie napisu
    str_1 = ""
    str_1_bez = ""
    znaki = "., !?0123456789"
    spr_n1 = False
    while spr_n1 == False:
        str_1 = input("\nPodaj swój napis: ")
        
        str_1_bez = str_1.lower()
        for i in znaki:
            str_1_bez = str_1_bez.replace(i,"")
            
        if str_1 != "" and str_1_bez.isalpha():
            spr_n1 = True
        else:
            print("Napis musi składać się z przynajmniej z jednej litery.")
    
    
    # oblicznie - czy palindron 
    str_new = mirror(str_1)
        
    # wizuajizacja
    czysc_ekran()
    print("Wprowadzono napis:" , str_1)
    print("Konkatenacja napisu:", str_new)
    
if __name__ == "__main__":
    main()

