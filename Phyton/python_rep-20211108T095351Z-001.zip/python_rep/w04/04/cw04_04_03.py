"""Ćwiczenie nr 4"""
"""Część 4 Napisy"""
"""Zadanie nr 3. Napisz funkcje reverse(napis), która z napisu bedacego jej argumentem tworzy odwrócony napis. Przykładowo, wywołanie reverse("hello") powinno zwrócic napis "olleh". W funkcji main przetestuj działanie funkcji reverse."""
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def reverse(napis):# z napisu tworzy odwrócony napis 
    
    sipan = ""
    for i in napis:
        sipan = i + sipan
    return(sipan)
    
    
def main():
    czysc_ekran()
    
    print("Program wczytuje napis.\nNastępnie tworzy odwrócony napis.\n")
    
    # wczytanie napisu
    str_1 = ""
    str_1_bez = ""
    znaki = " .,:;!?-\'\"@%#&"
    spr_n1 = False
    while spr_n1 == False:
        str_1 = input("\nPodaj swój napis: ")
        str_1_bez = str_1
        for i in znaki:
            str_1_bez = str_1_bez.replace(i,"")
            

        if str_1 != "" and str_1_bez.isalnum():
            spr_n1 = True
        else:
            print("Napis musi składać się z przynajmniej jednej litery.")
    
    
    # oblicznie - usuwanie z z1 ciągu z2 
    str_new = reverse(str_1)
        
    # wizuajizacja
    czysc_ekran()
    print("Wprowadzono napis: ", str_1)
    print("Odwrócony napis to:",str_new)
    
if __name__ == "__main__":
    main()
