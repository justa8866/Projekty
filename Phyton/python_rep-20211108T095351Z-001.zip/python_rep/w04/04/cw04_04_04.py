"""Ćwiczenie nr 4"""
"""Część 4 Napisy"""
"""Zadanie nr 4. Napisz funkcje palindrom(napis), która zwraca wartosc True, jezeli jej argument jest palindromem, a wartość False w przeciwnym przypadku. Przykładowo,wywołanie palindrom("kajak") powinno zwrócić wartość True. W funkcji palindrom możesz skorzystać z funkcji z poprzedniego zadania. W funkcji main
przetestuj działanie funkcji palindrom."""
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def reverse(napis):# z napisu tworzy odwrócony napis 
    
    sipan = ""
    for i in napis:
        sipan = i + sipan
    return(sipan)

def palindron(napis): #sprawdza czy słowo jest palidronem     
    # korzysta z funkcji reverse
    czy_palindron = False
    sipan = reverse(napis)
    if napis == sipan:
       czy_palindron = True 
    return(czy_palindron)

def main():
    czysc_ekran()
    
    print("Program wczytuje napis.\nNastępnie sprawdza czy napis jest palidronem.\n")
    
    # wczytanie napisu
    str_1 = ""
    str_1_bez = ""
    znaki = "., !?0123456789"
    spr_n1 = False
    while spr_n1 == False:
        str_1 = input("\nPodaj swój napis: ")
        
        str_1_bez = str_1.lower()
        for i in znaki:
            str_1_bez = str_1_bez.replace(i,"")
            
        if len(str_1_bez) > 2 and str_1_bez.isalpha():
            spr_n1 = True
        else:
            print("Napis musi składać się z przynajmniej z trzech liter.")
    
    
    # oblicznie - czy palindron 
    cala_prawda = palindron(str_1_bez)
        
    # wizuajizacja
    czysc_ekran()
    print("Wprowadzono napis:", str_1)
    if cala_prawda:
        print("Napis jest palindronem!")
    else:
        print("Napis nie jest palindronem.")
    
if __name__ == "__main__":
    main()

