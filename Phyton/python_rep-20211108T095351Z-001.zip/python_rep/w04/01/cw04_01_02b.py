"""Ćwiczenie nr 4"""
"""Część 1 Proste iteracje"""
"""Zadanie nr 2. Wczytać liczbę naturalną do zmiennej n oraz liczbe rzeczywista do zmiennej a."""
"""Podpunkt b) oblicz wartość (b) a * (a + 1) * . . . * (a + n - 1)"""
import math

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")


def spr_liczba_N(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę naturalną. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną
    spr_liczba_ = False
    liczba_N_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_N_ = int(liczba_str_)
        if liczba_N_ > 0:
            spr_liczba_ = True
        else:
            print("Wprowadzona liczba {} nie jest liczbą naturalną.".format(liczba_str_))     
    except:
        print("Wprowadzona wartość {} nie jest liczbą naturalną.".format(liczba_str_))   
    return(spr_liczba_, liczba_N_)

def spr_liczba_R(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę rzeczywistą. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną
    spr_liczba_ = False
    liczba_R_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_R_ = float(liczba_str_)
        spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą rzeczywistą.".format(liczba_str_))   
    return(spr_liczba_, liczba_R_)

def iloczyn_a_n(liczba_n_, liczba_a_):# znajduje iloczyn wyrażenia a * (a + 1) * . . . * (a + n - 1).  
    iloczyn_ = liczba_a_
    for i in range(2, liczba_n_ + 1):
        iloczyn_ *= liczba_a_ + (i - 1)
        
    return(iloczyn_)
    
def wiz(liczba_n_, liczba_a_, iloczyn_b_): # wizualizacja wyników
    czysc_ekran()
    print("Dla a = {} i n = {}  obliczonno wartość wyrażenia: \na * (a + 1) * . . . * (a + n - 1) = {}.\n ".format(liczba_a_, liczba_n_, iloczyn_b_))
    

def main():
    czysc_ekran()
    
    print("Program wczytuje liczbę naturalną n oraz liczbę rzeczywistą a.\nNstępnie oblicza wartość wyrażenia:")
    print("a * (a + 1) * . . . * (a + n - 1).")
    
    
    #wczytanie danych
    spr_n = False
    while spr_n == False:
        n_str=input("\nPodaj liczbę naturalną n: ")
        spr_n, liczba_n = spr_liczba_N(n_str)
    spr_a = False
    while spr_a == False:
        a_str=input("\nPodaj liczbę rzeczywistą a: ")
        spr_a, liczba_a = spr_liczba_R(a_str)
    
    # oblicznie - cyfry znaczącej
    iloczyn_b = iloczyn_a_n(liczba_n, liczba_a)
        
    # wizuajizacja
    wiz(liczba_n, liczba_a, iloczyn_b)
    
if __name__ == "__main__":
    main()

