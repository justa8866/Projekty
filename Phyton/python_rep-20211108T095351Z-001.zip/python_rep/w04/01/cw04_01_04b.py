"""Ćwiczenie nr 4"""
"""Część 1 Proste iteracje"""
"""Zadanie nr 4. Wczytac liczbę rzeczywistą do zmiennej a."""
"""Podpunkt b) znaleźć najmniejszą liczbę n, taką że 1 + 1/2 + 1/3 + : : : + 1/n > a."""
import time

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba_R(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę rzeczywistą. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną
    spr_liczba_ = False
    liczba_R_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_R_ = float(liczba_str_)
        spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą rzeczywistą.".format(liczba_str_))   
    return(spr_liczba_, liczba_R_)

def znajdz_n(liczba_a_):# znajduje najmniejszą liczbę n, taką że 1 + 1/2 + 1/3 + : : : + 1/n > a.  
    spr_z_ = False
    suma_ = 0
    n_ = 0
    t_ = time.monotonic()
    dop_czas = 10
    while suma_ <= liczba_a_:
        n_ += 1
        suma_ += 1 / n_
        t_p = time.monotonic()
        if t_p - t_  > dop_czas:
            print("Przekroczono dopuszczlny czas obliczeń równy {} sekund i pomimo sprawdzenia n do liczby {} nie znaleziono wyniku.".format(dop_czas, n_))
            input("Wciśnij ENTER")
            return(spr_z_, n_)
    spr_z_ = True
    return(spr_z_, n_)
    
def wiz(liczba_n_, liczba_a_): # wizualizacja wyników
    czysc_ekran()
    print("Dla a = {} obliczonno najmniejsze n = {} takie że:".format(liczba_a_, liczba_n_))
    print("     1     1             1     ")
    print("1 + --- + --- + . . . + --- > a")
    print("     2     3             n     ")

def main():
    czysc_ekran()
    
    print("Program wczytuje liczbę rzeczywistą.\nNstępnie oblicza najmniejsza liczbe n, taką że:")
    print("     1     1             1     ")
    print("1 + --- + --- + . . . + --- > a")
    print("     2     3             n     ")
    
    #wczytanie danych
    spr_a = False
    while spr_a == False:
        a_str=input("\nPodaj liczbę rzeczywistą a: ")
        spr_a, liczba_a = spr_liczba_R(a_str)
    
    # oblicznie - cyfry znaczącej
    spr_z, liczba_n = znajdz_n(liczba_a)
        
    # wizuajizacja
    if spr_z:
        wiz(liczba_n, liczba_a)
    
if __name__ == "__main__":
    main()

