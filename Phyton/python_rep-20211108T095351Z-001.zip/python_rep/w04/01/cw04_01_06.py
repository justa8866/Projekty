"""Ćwiczenie nr 4"""
"""Część 1 Proste iteracje"""
"""Zadanie nr 6. Wczytać dwie liczby naturalne do zmiennych m i n. Obliczyć sumę m najmniej znaczacych cyfr liczby n. (Przykład: dla liczb m = 2 i n = 1989 poprawna odpowiedzia jest liczba 17, a dla liczb m = 5 i n = 1989 komunikat Niepoprawne dane)."""
#import sys
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba_N(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę naturalną. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną
    spr_liczba_ = False
    liczba_N_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_N_ = int(liczba_str_)
        if liczba_N_ > 0:
            spr_liczba_ = True
        else:
            print("Wprowadzona liczba {} nie jest liczbą naturalną np. 1, 2, 3, ... itd.".format(liczba_N_))      
    except:
        print("Wprowadzona wartość {} nie jest liczbą naturalną np. 1, 2, 3, ... itd.".format(liczba_str_))   
    return(spr_liczba_, liczba_N_)

def suma_znaczaca(liczba_m_, str_n_):# liczy m sumę najmniejznaczących cyfr liczby n
    suma_z = 0
    if len(str_n_) >= liczba_m_:
        for i in range(0, liczba_m_):
            suma_z += int(str_n_[-i-1])    
    
        return(suma_z)
    else:
        return(None)

def main():
    czysc_ekran()
    
    print("Program wczytuje dwie liczby naturalne do zmiennych m i n.\nNstępnie oblicza sumę m najmniej znaczacych cyfr liczby n.\nGdy nie można obliczyć sumy podaje komunikat \"Niepoprawne dane!\"")
    
    #wczytanie danych
    spr_m = False
    while spr_m == False:
        m_str=input("\nPodaj liczbę naturalną m: ")
        spr_m, liczba_m = spr_liczba_N(m_str)

    spr_n = False
    while spr_n == False:
        n_str=input("\nPodaj liczbę naturalną n: ")
        spr_n, liczba_n = spr_liczba_N(n_str)
    
    # oblicznie - sumy n liczb znaczących
    suma_cyfr = suma_znaczaca(liczba_m, n_str)
    
    # wizuajizacja
    czysc_ekran()
    if suma_cyfr == None:
        print("Niepoprawne dane!")
    elif liczba_m == 1:
        print("Suma {} najmniej znaczącej cyfry liczby {} jest równa {}.".format(liczba_m, liczba_n, suma_cyfr))
    else:
        print("Suma {} najmniej znaczących cyfr liczby {} jest równa {}.".format(liczba_m, liczba_n, suma_cyfr))
    
if __name__ == "__main__":
    main()

