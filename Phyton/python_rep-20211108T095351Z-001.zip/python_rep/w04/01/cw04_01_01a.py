"""Ćwiczenie nr 4"""
"""Część 1 Proste iteracje"""
"""Zadanie nr 1. Wczytać liczbę naturalną do zmiennej n."""
"""Podpunkt a) oblicz wartość a^n."""
import math

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")


def spr_liczba_N(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę naturalną. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną
    spr_liczba_ = False
    liczba_N_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_N_ = int(liczba_str_)
        if liczba_N_ > 0:
            spr_liczba_ = True
        else:
            print("Wprowadzona liczba {} nie jest liczbą naturalną.".format(liczba_str_))     
    except:
        print("Wprowadzona wartość {} nie jest liczbą naturalną.".format(liczba_str_))   
    return(spr_liczba_, liczba_N_)

def licz_2_n(liczba_n_):# oblicza 2^n.  
    
    return(2**liczba_n_)
    
def wiz(liczba_n_,licz_a_): # wizualizacja wyników
    czysc_ekran()
    print("Dla n = {}  obliczonno wartość wyrażenia: \n2\u207f = {}.\n ".format(liczba_n_, licz_a_))
    

def main():
    czysc_ekran()
    
    print("Program wczytuje liczbę naturalną n.\nNstępnie oblicza wartość wyrażenia 2\u207f.")
    
    
    
    #wczytanie danych
    spr_n = False
    while spr_n == False:
        n_str=input("\nPodaj liczbę naturalną n: ")
        spr_n, liczba_n = spr_liczba_N(n_str)
        
    # oblicznie 
    licz_a = licz_2_n(liczba_n)
        
    # wizuajizacja
    wiz(liczba_n, licz_a)
    
if __name__ == "__main__":
    main()

