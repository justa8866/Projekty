"""Ćwiczenie nr 4"""
"""Część 1 Proste iteracje"""
"""Zadanie nr 3. Wczytać liczbć rzeczywista do zmiennej x."""
"""Podpunkt c) oblicz wartość sin x + sin^2 x + : : : + sin^n x."""
import math

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba_R(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę rzeczywistą. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną
    spr_liczba_ = False
    liczba_R_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_R_ = float(liczba_str_)
        spr_liczba_ = True
    except:
        print("Wprowadzona wartość {} nie jest liczbą rzeczywistą.".format(liczba_str_))   
    return(spr_liczba_, liczba_R_)

def suma_sin_n(liczba_x_):# znajduje sumę wyrażenia sin x + sin^2 x + : : : + sin^n x..  
    suma_ = 0
    dif_ = 1
    i = 1
    while dif_ > 1e-128: 
        dif_ = math.sin(liczba_x_)**i
        suma_ += dif_
        i += 1
    return(suma_)
    
def wiz(liczba_x_, suma_c_): # wizualizacja wyników
    czysc_ekran()
    print("Dla x = {} obliczonno wartość wyrażenia sin x  + sin\u00b2 x + ... + sin\u207f x = {}. ".format(liczba_x_, suma_c_))
    

def main():
    czysc_ekran()
    
    print("Program wczytuje liczbę rzeczywistą x.\nNstępnie oblicza wartość wyrażenia:")
    print("sin x  + sin\u00b2 x + ... + sin\u207f x")
    
    
    #wczytanie danych
    spr_x = False
    while spr_x == False:
        x_str=input("\nPodaj liczbę rzeczywistą x: ")
        spr_x, liczba_x = spr_liczba_R(x_str)
    
    # oblicznie - cyfry znaczącej
    suma_c = suma_sin_n(liczba_x)
        
    # wizuajizacja
    wiz(liczba_x, suma_c)
    
if __name__ == "__main__":
    main()

