"""Ćwiczenie nr 4"""
"""Część 1 Proste iteracje"""
"""Zadanie nr 8. Wczytać dwie liczby naturalne do zmiennych m i n. Wypisać wszystkie liczby pierwsze p, takie że m <= p <= n."""

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def spr_liczba_M(liczba_str_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę naturalną. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną
    spr_liczba_ = False
    liczba_m_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_m_ = int(liczba_str_)
        if liczba_m_ > 0:
            spr_liczba_ = True
        else:
            print("Wprowadzona liczba {} nie jest liczbą naturalną np. 1, 2, 3, ... itd.".format(liczba_m_))      
    except:
        print("Wprowadzona wartość {} nie jest liczbą naturalną np. 1, 2, 3, ... itd.".format(liczba_str_))   
    return(spr_liczba_, liczba_m_)

def spr_liczba_N(liczba_str_, liczba_m_): 
    #funkcja sprawdza czy zmienna liczba_str typu string może być przekonwertowana na liczbę naturalną większą od liczby n. Zwraca zmienną spr_liczba_ = True gdy tak i False gdy nie oraz liczbę - zmienna  liczba_ będącą liczbą nturalną
    spr_liczba_ = False
    liczba_n_=[]
    try:
        liczba_str_= liczba_str_.strip(" ")
        liczba_str_= liczba_str_.replace(",",".")
        liczba_n_ = int(liczba_str_)
        if liczba_n_ > liczba_m_:
            spr_liczba_ = True
        else:
            print("Wprowadzona liczba {} nie jest liczbą naturalną większą od {}.".format(liczba_n_, liczba_m_))
    except:
        print("Wprowadzona wartość {} nie jest liczbą naturalną większą od {}.".format(liczba_str_, liczba_m_))   
    return(spr_liczba_, liczba_n_)

    
def czy_pierwsza(liczba_n_):
    if liczba_n_ == 1:
        return False
    for i in range(2, liczba_n_):
        if liczba_n_ % i == 0:
            return False
    return True

def n_m_pierwsze(m_,n_):
    pierwsze=[]
    for i in range(m_,n_ + 1):
        if czy_pierwsza(i):
            pierwsze.append(i)
    return(pierwsze)

def main():
    czysc_ekran()
    
    print("Program wczytuje dwie liczby naturalne do zmiennych m i n.\nNstępnie znajduje wszystkie liczby pierwsze p, takie że m <= p <= n.")
    
    #wczytanie danych
    # wczytanie liczby naturalnej
    spr_m = False
    while spr_m == False:
        m_str=input("\nPodaj liczbę naturalną m: ")
        spr_m, liczba_m = spr_liczba_M(m_str)

    spr_n = False
    while spr_n == False:
        n_str=input("\nPodaj liczbę naturalną n: ")
        spr_n, liczba_n = spr_liczba_N(n_str, liczba_m)
    
    
    # oblicznie - szukanie liczb pierwszych
    ciag_liczb_pierwszych = n_m_pierwsze(liczba_m,liczba_n)
        
    # wizuajizacja
    czysc_ekran()
    if ciag_liczb_pierwszych == []:
        print("W przedziale <{},{}> nie znaleziono liczb pierszych".format(liczba_m, liczba_n))
    else:
       print("W przedziale <{},{}> znaleziono następujące liczby piersze: \n{}".format(liczba_m, liczba_n,ciag_liczb_pierwszych))     
if __name__ == "__main__":
    main()

