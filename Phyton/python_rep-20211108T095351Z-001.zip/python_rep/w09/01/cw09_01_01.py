""" Ćwiczenie nr 9. Zadanie 1. Wybrane funkcje wbudowane """
import sys
import random
def main() -> None:
    #if not(sys.argv) or len(sys.argv) != 2:
    if len(sys.argv) != 2:
        return print("Nie podano poprawnie argumentu")
    try:
        zasieg = int(sys.argv[1])
        if zasieg < 1:
            return print("Argument nie jest liczbą naturalną!")
    except:
        return print("Argument nie jest liczbą naturalną!")
    tab = [random.randint(-99, 100) for j in range(zasieg)]
    print("Tab = {}".format(tab))
    #ppkt a
    najwiek_licz = max(tab)
    print("Najwieksza liczba z listy: {}".format(najwiek_licz))
    #ppkt b
    najwiek_licz_bezw = max(tab, key=abs)
    print("Najwieksza co do wartości bezwzglednej liczba z listy: {}".format(najwiek_licz_bezw))
    #ppkt c
    tab_sort_r = tab
    tab_sort_r.sort()
    print("Posortowana rosnąco: {}".format(tab_sort_r))
    #ppkt d
    tab_sort_m = tab
    tab_sort_m.sort(reverse=True)
    print("Posortowana malejąco: {}".format(tab_sort_m))
    #ppkt e
    tab_sort_r_bez = tab
    tab_sort_r_bez.sort(key=abs)
    print("Posortowana rosnąco co do wartości bezwzglednej: {}".format(tab_sort_r_bez))
    #ppkt f
    tab_sort_m_bez = tab
    tab_sort_m_bez.sort(reverse=True, key=abs)
    print("Posortowana rosnąco co do wartości bezwzglednej: {}".format(tab_sort_m_bez))
if __name__ == "__main__":
    main()
