""" Ćwiczenie nr 9. Zadanie 2. Iteratory"""
import sys
def main() -> None:
    if len(sys.argv) != 2:
        return print("Nie podano argumentu!")
    try:
        licz_n = int(sys.argv[1])
        if licz_n < 1:
            return print("Argument nie jest liczbą naturalną!")
    except:
        return print("Argument nie jest liczbą naturalną!")
    numery = []
    i = 1
    while i <= licz_n:
        numery.append(i)
        i += 1
    suma = sum(numery)
    print(suma)
if __name__ == "__main__":
    main()
