""" Ćwiczenie nr 9. Zadanie 1. Iteratory"""
def main() -> None:
    miasta = ["Gdańsk", "Elbląg", "Kraków", "Łódź", "Opole", "Radom", 'Warszawa']
    iterator = iter(miasta)
    try:
        while val := next(iterator):
            print(val)
    except StopIteration:
        print("Stop Iteration")
if __name__ == "__main__":
    main()
