""" Ćwiczenie nr 9. Zadanie 3. Iteratory"""
import sys
def main() -> None:
    if len(sys.argv) != 2:
        return print("Nie podano argumentu!")
    try:
        licz_n = int(sys.argv[1])
        if licz_n < 1:
            return print("Argument nie jest liczbą naturalną!")
    except:
        return print("Argument nie jest liczbą naturalną!")
    suma = 0
    for i in range(1, licz_n + 1):
        suma += i
    print(suma)
if __name__ == "__main__":
    main()
