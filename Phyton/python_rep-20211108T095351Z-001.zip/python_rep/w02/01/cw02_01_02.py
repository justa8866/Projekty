"""Ćwiczenie nr 2"""
"""Część 1 Zadanie nr 2 Napisz program w języku Python, który wczytuje promień koła i oblicza jego pole."""
import math
def main(): 
    # zmienna r_k-promień koła (str-znaki licz-liczba) 
    # zmienna pl_k-pole koła
    # zmienna il_pr; spr_r_k; zmienne w pętli while do sprawdzenia poprawność wpisanych danych
    
    spr_r_k = False
    il_pr = 3
    str_r_k = 0
    licz_r_k= 0
    
    print("Program liczy pole koła na podstawie wprowadzonej długości promienia.")

    while spr_r_k==False and il_pr>=0:
        if il_pr==0:
            licz_r_k=1
            il_pr=il_pr-1
            print("\nNie podano poprawnie długości promienia. Przyjęto promień równy 1.\n")
        else:    
            print("Pozostała ilość prób:",il_pr)
            str_r_k = input("Podaj promień koła: ") 
            str_r_k = str_r_k.replace(",",".")
            try:
                licz_r_k=float(str_r_k)
                if licz_r_k>0:
                    spr_r_k=True
                    print("\nWprowadzono promień koła:", licz_r_k)
                else:
                    il_pr=il_pr-1
                    print("Nie podano poprawnie długości promienia")
                    print("Promień powinien być dodatni.")
                                        
            except:
                il_pr=il_pr-1
                print("Nie podano poprawnie długości promienia")
       
    #obliczanie powierzchni koła
    pl_k = math.pi * (licz_r_k**2) 
    #wizualizacja wyników
    print("\nWprowadzony promień koła:  ",licz_r_k,"\nObliczone pole koła wynosi:", pl_k)
    
if __name__ == "__main__":
    main()
