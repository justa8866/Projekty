"""Ćwiczenie nr 2"""
"""Część 1  Zadanie 5. Napisz program w języku Python, który przekonwertuje stopniową miarę kąta na miarę
wyrażoną w radianach."""
import math
def czysc_ekran():# czyści ekran
    try:
        print(chr(27)+"[2j")
        print("\033c")
        print("\x1bc")
    except:
        print("\n\n\n")

def sp_czy_licz_st(str_str):
    # funkcja sprawdza czy ciąg znaków srt_ może być przekształcona na liczbę i czy liczba jest dodatnia w przedziale do 0 do 360.
    try:
        licz_licz = float(str_str)
        if licz_licz>=0 and licz_licz<=360:
            spr_spr = True
        else:
            spr_spr = False
    except:
        spr_spr = False
    finally:
        if spr_spr == True:
            licz_SS = int(math.floor(licz_licz))
            licz_mm = int(math.floor((licz_licz-licz_SS)*60))
            licz_sk = float((licz_licz-licz_SS-(licz_mm / 60)) * 3600 )

            print("Wprowadzony kąt w stopniach poprawny: {:.9f}\u00B0 \nczyli: {:.0f}\u00B0 {:.0f}\' {:.4f}\" ".format(licz_licz,licz_SS,licz_mm,licz_sk))
        else:
            print("Nie wprowadzono poprawnie kąta w stopniach od 0\u00B0 do 360\u00B0")
        return(spr_spr)

def sp_czy_licz_sms(str_str):
    # funkcja sprawdza czy ciąg znaków srt_ może być przekształcona na stopnie minuty i sekundy oddzielone spacją w przedziale 0 do 360.
    try:
        in_sp_=str_str.index(" ")
        str_2_=str_str[in_sp_+1:]
        in_sp2_=str_2_.index(" ")
        
        str_SS=str_str[:in_sp_]
        str_mm=str_2_[:in_sp2_]
        str_sk=str_2_[in_sp2_+1:]

        licz_SS = int(str_SS)
        licz_mm = int(str_mm)
        licz_sk = float(str_sk)
        licz_sms=licz_SS+(licz_mm / 60)+(licz_sk / 3600)
        if licz_sms>=0 and licz_sms<=360 and licz_SS>=0 and licz_SS<=360 and licz_mm>=0 and licz_mm<60 and licz_sk>=0 and licz_sk<60:
            spr_spr = True
        else:
            spr_spr = False
    except:
        spr_spr = False
    finally:
        if spr_spr == True:
            print("Wprowadzony kąt w stopniach poprawny: {:.0f}\u00B0 {:.0f}\' {:.4f}\" \nczyli: {:.9f}\u00B0".format(licz_SS,licz_mm,licz_sk,licz_sms))
        else:
            print("Nie wprowadzono poprawnie kąta (od 0\u00B0 do 360\u00B0) w stopniach minutach i sekundach oddzilonymi znakiem spacji (np. 93 46 56.6)")
        return(spr_spr)

def podaj_st(il_pr_):
    # funkcja wprowadza miarę kąta w stopniach od 0 do 360* 
    # kożysta z funkcji sp_czy_licz_st
    # il_pr_ zmienna ilość prób 
    # po x złych próbach przyjmuje 1
    spr__ = False
    while spr__==False and il_pr_>=0:
        if il_pr_<=0:
            licz__=90
            il_pr_=il_pr_-1
            
            print("\nNie wprowadzono poprawnie miary kąta w stopniach.","\nPrzyjęto kąt równy 90\u00B0.\n")
            
            input("\nWciśnij ENTER aby zobaczyć przykłądową konwerrsję na radiany.\n")
        else:    
            print("Pozostała ilość prób:",il_pr_)
            str__ = input("Podaj miarę kąta w stopniach (SS.SSS):")
            str__=str__.strip(" ")
            str__ = str__.replace(",",".")
            if sp_czy_licz_st(str__) == True:
                licz__ = float(str__)
                spr__ = True
            else:
                il_pr_=il_pr_-1
    return(licz__)
    
def podaj_sms(il_pr_):
    # funkcja wprowadza miarę kąta w stopniach od 0 do 360* 
    # kożysta z funkcji sp_czy_licz_st
    # il_pr_ zmienna ilość prób 
    # po x złych próbach przyjmuje 1
    spr__ = False
    while spr__==False and il_pr_>=0:
        if il_pr_<=0:
            licz__=90
            il_pr_=il_pr_-1
            print("\nNie wprowadzono poprawnie miary kąta w stopniach.","\nPrzyjęto kąt równy 90\u00B0.\n")
        else:    
            print("Pozostała ilość prób:",il_pr_)
            str__ = input("Podaj miarę kąta w stopniach (SS mm ss):")
            str__=str__.strip(" ")
            str__ = str__.replace(",",".")
            if sp_czy_licz_sms(str__) == True:
                in_sp_=str__.index(" ")
                str_2_=str__[in_sp_+1:]
                in_sp2_=str_2_.index(" ")
        
                str_SS=str__[:in_sp_]
                str_mm=str_2_[:in_sp2_]
                str_sk=str_2_[in_sp2_+1:]

                licz_SS = int(str_SS)
                licz_mm = int(str_mm)
                licz_sk = float(str_sk)
                licz__=licz_SS+(licz_mm / 60)+(licz_sk / 3600)
                spr__ = True
            else:
                il_pr_=il_pr_-1
    return(licz__)

def main(): 
    spr_m=0
    
    while spr_m == 0:
        print("Program konwertuje miarę stopniową kąta (od zera do 360 stopni) na radiany. SS - stopnie; mm - minuty; ss - sekundy.")
        wybor=input("\nWybierz sposób formatowania wprowadzanej miary stopniowej:\n1. SS.SS       - Wciśnij 1\n2. SS mm ss.s  - Wciśnij 2\n3. Pomoc       - Wciśnij P\n\nWybierz 1,2 lub P i wciśnij ENTER:")
        if wybor == "1":
            czysc_ekran()
            stopnie = podaj_st(3)
            spr_m=1
        elif wybor == "2":
            czysc_ekran()
            stopnie = podaj_sms(3)
            spr_m=1
        elif wybor == "p" or wybor == "P":
            czysc_ekran()
            print("Program konwertuje miarę stopniową kąta (od zera do 360 stopni) na radiany.")
            print("Stosowne skróty:\nSS-stopnie\nmm-minyty \nss-sekundy")
            print("1. Program przyjmuje skalę stopniową od 0 do 360 stopni podaną jako pełne stopnie SSS np. 23 - dwadzieścia trzy stopnie. Stopnie mogą mieć swoje części dziesiąte, setne, tysięczne itd. za znakiem kropki SSS.S np. 23.31 - dwadzieścia trzy i trzydzieści jeden setnych stopna. Jeżeli tak chcesz wprowadzać miarę stopniową to w menu wyboru wciśnij 1.")
            print("\n2. Program przyjmuje miarę stopniową w formacie pełne stopnie, pełne minuty i sekundy  oddzielone znakiem spacji SS mm ss.s np. 23 17 53 - dwadzieścia trzy stopnie siedemnaście minut pięćdziesiąt trzy sekundy. Sekundy mogą mieć swoje części dziesiątne, setne, tysięczne itd. za znakiem kropki np. 23 17 53.7 - dwadzieścia trzy stopnie siedemnaście minut pięćdziesiąt trzy i siedem dziesiątnych sekundy. Jeżeli tak chcesz wprowadzać miarę stopniową to w menu wyboru wciśnij 2.")
            input("\nWciśnij ENTER aby przejść do menu wyboru.\n")
            czysc_ekran()
        else:
            czysc_ekran()
    #print(stopnie)
    #konwercja na radiany
    radiany = (stopnie / 180) * math.pi
    licz_SS = int(math.floor(stopnie))
    licz_mm = int(math.floor((stopnie-licz_SS)*60))
    licz_sk = float((stopnie-licz_SS-(licz_mm / 60)) * 3600)

    #wizulizacja
    czysc_ekran()
    print("\nWprowadzono kąt w stopniach: {:.0f}\u00B0 {:.0f}\' {:.4f}\" \n                      czyli: {:.9f}\u00B0".format(licz_SS,licz_mm,licz_sk,stopnie))
    print("Obliczono kąt w radianach:  ", radiany,"[rad]")

if __name__ == "__main__":
    main()
