"""Ćwiczenie nr 2"""
"""Część 1 Zadanie nr 1. Napisz program w języku Python, który wczytuje promień okręgu i oblicza jego obwód"""
import math
def main(): 
    # zmienna r_ok-promień okręgu 
    # zmienna ob_ok-obwód okręgu
    # zmienna il_pr; spr_r_ok; spr_ob_ok spr_jd zmienne w pętli while do sprawdzenia poprawność wpisanych danych
    li_zn=2 #liczb znaczących 3.14 -2 po przecinku
    spr_r_k=False
    il_pr=3
    
    print("Program liczy obwód okręgu na podstawie wprowadzonej długości promienia.")

    while spr_r_k==False and il_pr>0:
        r_ok = input("Podaj promień okręgu: ")
        
        r_ok = r_ok.strip(" ") #oczyszcza ze spacji
        r_ok = r_ok.replace(",",".") #zamienia , na .
        
        il_pr = il_pr-1 # ilość prób
        
        dl_li = len(r_ok) #długość 
   
        r_ok_bez_m  = r_ok.replace("-","")
        r_ok_bez_kr = r_ok.replace(".","")
        r_ok_bez_zn = r_ok_bez_m.replace(".","")
        if r_ok_bez_kr.strip("0")=="":
            print("Promień powinien być dodoatni")

        elif r_ok.isdigit()==True: #tylko cyfry liczba naturalna
            spr_r_k = True
            r_ok=int(r_ok)
        
        elif r_ok.count('-')==0 and r_ok.count('.')==1 and r_ok_bez_kr.isdigit()==True:  #liczba z kropką dziesiętną rzeczywista dodatnia
            in_kr= r_ok.index(".")
            li_zn=len(r_ok)-in_kr-1
            r_ok=float(r_ok)
            spr_r_k = True
        
        elif r_ok[0]=="-" and r_ok.count('-')==1 and r_ok.count('.')<=1 and r_ok_bez_zn.isdigit()==True:  #liczba ujemna
            print("\nPromień nie może być ujemny.\n")
                    
        else:
            print("\nNie podałeś poprawnie promienia.\n",)
      
        if il_pr==0:
            r_ok=1
            print("\nNie podano poprawnie długości promienia.\nPrzyjęto promień równy 1.\n")
    

    #obliczanie obwodu
    ob_ok= 2 * math.pi * r_ok 
    
    # określanie liczb znaczcych
    li_zn = 0
    il_z_pk = 0
    il_z_zk = 0
    r_o=str(r_ok)
    if r_o.count(".")==0 and r_o.isdigit()==True:
        li_zn=0
        for i in r_o:
            if r_o[-1]=="0":
                il_z_pk=il_z_pk+1
                r_o=r_o[:-1]
                li_zn=li_zn-1
      
    elif r_o.count(".")==1 and r_ok_bez_kr.isdigit()==True:
        in_kr=r_o.index(".")
        li_pk=r_o[:in_kr]
        li_zk=r_o[in_kr+1:]
        st_li_zk=li_zk.rstrip("0")
                
        if len(st_li_zk)>0:
            li_zn=len(st_li_zk)
        
        elif len(st_li_zk)==0:
            li_zn=0
            for i in li_pk:
                if li_pk[-1]=="0":
                    il_z_pk=il_z_pk+1
                    li_pk=li_pk[:-1]
                    li_zn=li_zn-1

    #obliczanie obwodu
    ob_ok= 2 * math.pi * r_ok 
    
    #wizualizacja wyniku
    if li_zn==0 or li_zn==1:
        li_zn=2
    elif li_zn<0: 
        li_zn=li_zn+2
    
    ob_ok_z = round(ob_ok,li_zn)
    
    if li_zn>0:
        
        print("\nWprowadzony promień okręgu:   ",r_ok,"\nObliczony obwód okręgu wynosi:", ob_ok,"\nObwód po zaokrądleniu wynosi: ",float(ob_ok_z))
    elif li_zn<0:
        
        print("\nWprowadzony promień okręgu:   ",r_ok,"\nObliczony obwód okręgu wynosi:", ob_ok,"\nObwód po zaokrądleniu wynosi: ",int(ob_ok_z))
              

if __name__ == "__main__":
    main()
