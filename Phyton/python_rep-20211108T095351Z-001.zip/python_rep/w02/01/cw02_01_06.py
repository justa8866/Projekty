"""Ćwiczenie nr 2"""
"""Część 1  Zadanie 6. Napisz program w języku Python, który przekonwertuje miarę kąta wyrażoną w radianach.
na stopniową miarę kata."""
import math
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
        print("\x1bc")
    except:
        print("\n\n\n")

def sp_czy_licz_rad(str_str):
    # funkcja sprawdza czy ciąg znaków srt_ może być przekształcona na liczbę i czy liczba jest dodatnia w przedziale do 0 do 2 pi.
    try:
        licz_licz = float(str_str)
        if licz_licz>=0 and licz_licz<=2*math.pi:
            spr_spr = 1
        else:
            spr_spr = 0
    except:
        str_str=str_str.replace("*","")
        str_str=str_str.replace(" ","")
        
        str_str=str_str.upper()
        str_bezPI=str_str.replace("PI","")
        str_bez=str_bezPI.replace(".","")
                 
        if str_str.count("PI") == 1 and str_bez.isdigit() == True: 
            licz_licz = float(str_bezPI)*math.pi
            spr_spr = 2
        else:
            spr_spr = 0
    finally:
        if spr_spr == 1 or spr_spr == 2:
            print("Wprowadzony kąt w radianach poprawny:",licz_licz)
        else:
            print("Nie wprowadzono poprawnie kąta w radianach od 0 do 2*Pi.")
        return(spr_spr)

def podaj_rad(il_pr_):
    # funkcja wprowadza miarę kąta w radianach od 0 do 2*pi 
    # kożysta z funkcji sp_czy_licz_st
    # il_pr_ zmienna ilość prób 
    # po x złych próbach przyjmuje 1
    spr__ = False
    while spr__==False and il_pr_>=0:
        if il_pr_<=0:
            licz__=math.pi*0.5
            il_pr_=il_pr_-1
            print("\nNie wprowadzono poprawnie miary kąta w radianach.","\nPrzyjęto kąt równy 90\u00B0 czyli:",licz__,"[rad]\n")
        else:    
            print("\nPozostała ilość prób:",il_pr_)
            str__ = input("Podaj miarę kąta w radianach (od 0 do 2*PI) w postaci:\n- liczby np. 4.123\n- wielokrotności Pi np. 1.3pi lub 1.75*Pi:\n")
            str__=str__.strip(" ")
            str__ = str__.replace(",",".")
            sspprr = sp_czy_licz_rad(str__)
            if sspprr == 1:
                licz__ = float(str__)
                spr__ = True
            elif sspprr == 2:
                str__=str__.replace("*","")
                str__=str__.replace(" ","")
                str__=str__.upper()
                str_bezPI=str__.replace("PI","")
                
                licz__ = float(str_bezPI)*math.pi
                spr__ = True
            else:
                il_pr_=il_pr_-1
    return(licz__)
    
def main(): 
    print("Program konwertuje miarę kąta w radianch (od 0 do 2*PI) na miarę stopniową stopnie.")
    radian=podaj_rad(3)    
    #print(radian)
    #konwercja na radiany
    stopnie = (radian / math.pi) * 180
    licz_SS = int(math.floor(stopnie))
    licz_mm = int(math.floor((stopnie-licz_SS)*60))
    licz_sk = float((stopnie-licz_SS-(licz_mm / 60)) * 3600)

    #wizulizacja
    #czysc_ekran()
    print("\n\n\nWprowadzono kąt w radianach:",radian,"[rad]")
    print("Obliczono kąt w stopniach:   {:.0f}\u00B0 {:.0f}\' {:.4f}\" \n                    czyli:   {:.9f}\u00B0".format(licz_SS,licz_mm,licz_sk,stopnie))

if __name__ == "__main__":
    main()
