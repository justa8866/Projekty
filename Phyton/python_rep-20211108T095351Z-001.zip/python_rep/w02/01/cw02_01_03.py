"""Ćwiczenie nr 2"""
"""Część1 1 Zadanie nr 3 Napisz program w języku Python, który wczytuje długości podstaw trapezu oraz jego
wysokość i oblicza jego pole."""
#import math
def sp_czy_licz_d(str_str):
    # funkcja sprawdza czy ciąg znaków srt_ może być przekształcona na liczbę i czy liczba jest dodatnia
    try:
        licz_licz = float(str_str)
        if licz_licz>0:
            spr_spr = True
        else:
            spr_spr = False
    except:
        spr_spr = False
    finally:
        if spr_spr== True:
            print("Wprowadzona długość poprawna:",licz_licz)
        else:
            print("Nie wprowadzono poprawnie długości")
        return(spr_spr)

def sp_czy_licz_d0(str_str):
    # funkcja sprawdza czy ciąg znaków srt_ może być przekształcona na liczbę i czy liczba nie jest ujemna
    try:
        licz_licz = float(str_str)
        if licz_licz>=0:
            spr_spr = True
        else:
            spr_spr = False
    except:
        spr_spr = False
    finally:
        if spr_spr== True:
            print("Wprowadzona długość poprawna:",licz_licz)
        else:
            print("Nie wprowadzono poprawnie długości")
        return(spr_spr)

def podaj(co_,il_pr_):
    # funkcja wprowadza długość 
    # kożysta z funkcji sp_czy_licz_d
    # co_ zmienna- tekst wprowadzenia
    # il_pr_ zmienna ilość prób 
    # po x złych próbach przyjmuje 1
    spr__ = False
    while spr__==False and il_pr_>=0:
        if il_pr_<=0:
            licz__=1
            il_pr_=il_pr_-1
            print("\nNie podano poprawnie długości ",co_, ".\nPrzyjęto długość ",co_," równą 1.\n")
        else:    
            print("Pozostała ilość prób:",il_pr_)
            str__ = input("Podaj długość "+co_+": ")
            str__ = str__.replace(",",".")
            if sp_czy_licz_d(str__) == True:
                licz__ = float(str__)
                spr__ = True
            else:
                il_pr_=il_pr_-1
    return(licz__)

def podaj0(co_,il_pr_):
    # funkcja wprowadza długość 
    # kożysta z funkcji sp_czy_licz_d0
    # co_ zmienna- tekst wprowadzenia
    # il_pr_ zmienna ilość prób 
    # po x złych próbach przyjmuje 1
    spr__ = False
    while spr__==False and il_pr_>=0:
        if il_pr_<=0:
            licz__=1
            il_pr_=il_pr_-1
            print("\nNie podano poprawnie długości ",co_, ".\nPrzyjęto długość ",co_," równą 1.\n")
        else:    
            print("Pozostała ilość prób:",il_pr_)
            str__ = input("Podaj długość "+co_+": ")
            str__ = str__.replace(",",".")
            if sp_czy_licz_d0(str__) == True:
                licz__ = float(str__)
                spr__ = True
            else:
                il_pr_=il_pr_-1
    return(licz__)

def main(): 
    
    #licz/str_p1 - długość podstawy 1  string/liczba
    #licz/str_p2 - długość podstawy 2 string/liczba
    #licz/str_h1 - długość wysokości string/liczba
    licz_p1 = 0
    licz_p2 = 0
    licz_h1 = 0

    print("Program liczy pole trapezu na podstawie wprowadzonych długości jego podstaw (druga podstawa może być równa 0) i jego ysokości.\n")
    licz_p1 = podaj("pierwszej podstawy trapezu",3)
    licz_p2 = podaj0("drugiej podstawy trapezu",3)
    licz_h1 = podaj("wysokości trapezu",3)


    #obliczanie powierzchni 
    pl_tz = ((licz_p1+licz_p2)*0.5)*licz_h1
    #wizualizacja wyników
    try:
        print(chr(27)+"[2j")
        print("\033c")
        print("\x1bc")
    finally:
        print("Wprowadzona długość pierwszej podstawy trapezu:",licz_p1)
        print("Wprowadzona długość drugiej podstawy trapezu:",licz_p2) 
        print("Wprowadzona wysokość trapezu:",licz_h1)
        if licz_p2==0:
            print("\nTrapez okazał się trójkątem o podstawie:",licz_p1,"i wysokości:",licz_h1)
            figura="trójkąta"
        elif licz_p1==licz_p2 and licz_p1==licz_h1:
            print("\nTrapez okazał się kwadratem o boku:",licz_p1,)
            figura="kwadratu"
        elif licz_p1==licz_p2:
            print("\nTrapez okazał się prostokątem o bokach:",licz_p1,"i",licz_h1)
            figura="prostokąta" 
        else:
           figura="trapezu" 
        
        print("\nObliczona powierzchnia",figura,":",pl_tz)
    
if __name__ == "__main__":
    main()
