"""Ćwiczenie nr 2"""
"""Część 1  Zadanie nr 4. Napisz program w języku Python, który wczytuje boki trójkąta i oblicza jego pole korzystając ze wzoru Herona."""
import math
def sp_czy_licz_d(str_str):
    # funkcja sprawdza czy ciąg znaków srt_ może być przekształcona na liczbę i czy liczba jest dodatnia
    try:
        licz_licz = float(str_str)
        if licz_licz>0:
            spr_spr = True
        else:
            spr_spr = False
    except:
        spr_spr = False
    finally:
        if spr_spr== True:
            print("Wprowadzona długość poprawna:",licz_licz)
        else:
            print("Nie wprowadzono poprawnie długości")
        return(spr_spr)

def podaj(co_,il_pr_):
    # funkcja wprowadza długość 
    # kożysta z funkcji sp_czy_licz_d
    # co_ zmienna- tekst wprowadzenia
    # il_pr_ zmienna ilość prób 
    # po x złych próbach przyjmuje 1
    spr__ = False
    while spr__==False and il_pr_>=0:
        if il_pr_<=0:
            licz__=1
            il_pr_=il_pr_-1
            print("\nNie podano poprawnie długości ",co_, ".\nPrzyjęto długość ",co_," równą 1.\n")
        else:    
            print("Pozostała ilość prób:",il_pr_)
            str__ = input("Podaj długość "+co_+": ")
            str__ = str__.replace(",",".")
            if sp_czy_licz_d(str__) == True:
                licz__ = float(str__)
                spr__ = True
            else:
                il_pr_=il_pr_-1
    return(licz__)

def liczb_znaczaczych(liczba_):
     # określanie liczb znaczcych
     # liczba_ - zmienna typu string!!! 
    li_zn_ = 0
    il_z_pk_ = 0
    il_z_zk_ = 0
    try:
        str_liczba_=str(liczba_)
    except:
        str_liczba_=liczba_
    finally:
        str_liczba_=str_liczba_.lstrip("-")
        str_bez_kr_=str_liczba_.replace(".","")
        if str_liczba_.count(".")==0 and str_liczba_.isdigit()==True:
            li_zn_=0
            for i in str_liczba_:
                if str_liczba_[-1]=="0":
                    il_z_pk_=il_z_pk_+1
                    str_liczba_=str_liczba_[:-1]
                    li_zn_=li_zn_-1
        elif str_liczba_.count(".")==1 and str_bez_kr_.isdigit()==True:
            in_kr_=str_liczba_.index(".")
            li_pk_=str_liczba_[:in_kr_]
            li_zk_=str_liczba_[in_kr_+1:]
            st_li_zk_=li_zk_.rstrip("0")
        
            if len(st_li_zk_)>0:
                li_zn_=len(st_li_zk_)
        
            elif len(st_li_zk_)==0:
                li_zn_=0
                for i in li_pk_:
                    if li_pk_[-1]=="0":
                        il_z_pk_=il_z_pk_+1
                        li_pk_=li_pk_[:-1]
                        li_zn_=li_zn_-1
        return(li_zn_)

def main(): 
    
    #licz/str_b1 - długość boku 1  string/liczba
    #licz/str_b2 - długość boku 2 string/liczba
    #licz/str_b3 - długość boku 3 string/liczba
    licz_b1 = 0
    licz_b2 = 0
    licz_b3 = 0

    print("Program liczy pole trójkąta na podstawie wprowadzonych długości jego boków.\n")
    while licz_b1+licz_b2<=licz_b3 or licz_b2+licz_b3<=licz_b1 or licz_b1+licz_b3<=licz_b2:
        licz_b1 = podaj("pierwszego boku trójkąta",3)
        licz_b2 = podaj("druriego boku trójkąta",3)
        licz_b3 = podaj("trzeciego boku trójkąta",3)
        if licz_b1+licz_b2<=licz_b3 or licz_b2+licz_b3<=licz_b1 or licz_b1+licz_b3<=licz_b2:
            try:
                print(chr(27)+"[2j")
                print("\033c")
                print("\x1bc")
            finally:    
                print("Ups... Podane długości boków nie tworzą trójkąta w przestrzeni kartezjańskiej. Podpowiedź - suma dwóch dowolnych boków musi być większa niż długość trzeciego.\nSpróbój ponownie.")
    #obliczanie powierzchni 
    
    heron_1=(licz_b1+licz_b2+licz_b3)*(-licz_b1+licz_b2+licz_b3)*(licz_b1-licz_b2+licz_b3)*(licz_b1+licz_b2-licz_b3)
    pl_tk1 = math.sqrt(heron_1)*0.25
    #heron_p1=(licz_b1+licz_b2+licz_b3)*0.5
    #pl_tk2 = math.sqrt(heron_p1*(heron_p1-licz_b1)*(heron_p1-licz_b2)*(heron_p1-licz_b3))
    
    #wizualizacja wyników
    z1=liczb_znaczaczych(licz_b1)
    z2=liczb_znaczaczych(licz_b2)
    z3=liczb_znaczaczych(licz_b3)
    z=[z1,z2,z3]
    z_max=z[0]
    z_min=z[0]
    for i in z:
        if z_max < i:
            z_max=i
        if z_min > i:
            z_min=i
    
    z_m=z_max+z_min+3

    try:
        print(chr(27)+"[2j")
        print("\033c")
        print("\x1bc")
    finally:
        print("Wprowadzona długość pierwszego boku trójkąta:",licz_b1)
        print("Wprowadzona długość drugiego   boku trójkąta:",licz_b2) 
        print("Wprowadzona długość trzeciego  boku trójkąta:",licz_b3)
        print("\nObliczona powierzchnia trójkąta wynosi:",pl_tk1)
        print("\nPowierzchnia trójkąta po zaokrągleniu wynosi:",round(pl_tk1,z_m))
        #print(z_m)
if __name__ == "__main__":
    main()
