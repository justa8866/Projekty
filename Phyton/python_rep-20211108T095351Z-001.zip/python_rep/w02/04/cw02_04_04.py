
"""Ćwiczenie nr 2"""
"""Część 4 Zadanie nr 4. Narysuj ponizszy rysunek wykorzystujac funkcje draw_polygon z poprzedniego zadania.
"""

import math
import turtle
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def draw_polygon(t_, n_,length_ ):
        """Niech ˙zółw t narysuje kształt"""
        for k in range(20):
            kat_=180 - ((n_ - 2) * 180) / n_ 
            #r_= (n_ * length_) / (2 * math.pi)
            #t_.penup()
            #t_.right(90+(180/n_) + (k * 18))
            #t_.fd(r_)
            t_.left(k * 18)
            #t_.pendown()
            
            for i in range(n_):
                t_.forward(length_)
                t_.left(kat_)
            t_.home()

def main():
    win = turtle.Screen()
    win.bgcolor("lightgreen")
    win.title("Wieloboki")
    win.screensize(200,200)
    t = turtle.Turtle()
    t.color("blue")
    t.pensize(3)

    
    sprmenu = False
    while sprmenu == False:
        czysc_ekran()
        print("Program uzywając grafiki zółwia rysuje nastepujace figury geometryczne:\n(a) 20 twarzy kwadratu")
        print("\nX - Wyjście z progrmmu.")
        wybor = input("Wybierz A lub X i zatwierdź klawiszem ENTER\n")
        t.clear()
        if wybor == "a" or wybor == "A":
            draw_polygon(t,4,100)
                    
                
        elif wybor == "x" or wybor == "X":
           sprmenu = True
    
if __name__ == "__main__":
    main()
