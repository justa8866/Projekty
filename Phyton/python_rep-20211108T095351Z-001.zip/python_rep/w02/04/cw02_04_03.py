
"""Ćwiczenie nr 2"""
"""Część 4 Zadanie nr 3. Napisz funkcje draw_polygon(t, n, length), która rysuje wielokat foremny. Wywołanie
tej funkcji draw_polygon(t, 8, 20).
"""

import math
import turtle
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def draw_polygon(t_, n_,length_ ):
        """Niech ˙zółw t narysuje kształt"""
        
        kat_=180 - ((n_ - 2) * 180) / n_ 
        r_= (n_ * length_) / (2 * math.pi)
        t_.penup()
        t_.right(90+(180/n_))
        t_.fd(r_)
        t_.left(90+(180/n_))
        t_.pendown()
            
        for i in range(n_):
                t_.forward(length_)
                t_.left(kat_)
        t_.ht()

def main():
    win = turtle.Screen()
    win.bgcolor("lightgreen")
    win.title("Ośmiokąt")
    win.screensize(50,50)
    t = turtle.Turtle()
    t.color("pink")
    t.pensize(5)

    
    sprmenu = False
    while sprmenu == False:
        czysc_ekran()
        print("Program uzywając grafiki zółwia rysuje nastepujace figury geometryczne:\n(a) ośmiokąt")
        print("\nX - Wyjście z progrmmu.")
        wybor = input("Wybierz A lub X i zatwierdź klawiszem ENTER\n")
        t.clear()
        if wybor == "a" or wybor == "A":
            draw_polygon(t,8,20)
                    
                
        elif wybor == "x" or wybor == "X":
           sprmenu = True
    
if __name__ == "__main__":
    main()
