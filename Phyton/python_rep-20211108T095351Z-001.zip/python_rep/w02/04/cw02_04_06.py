
"""Ćwiczenie nr 2"""
"""Część 4 Zadanie nr 6. Napisz funkcje draw_spiral(x, y, angle), która rysuje pojedyncza spirale. Argumenty
x i y to współrzedne poczatku spirali, natomiast argument angle okresla kat, o który nalezy obrócic zółwia rysujac spirale. Wykorzystaj te funkcje do narysowania ponizszego
rysunku.
"""

import math
import turtle
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def draw_spiral(x_, y_,angle_ ):
    """Niech ˙zółw t narysuje spirale"""
    
    t = turtle.Turtle()
    t.color("blue")
    t.pensize(3)
    t.penup()
    t.setpos(x_,y_)
    t.setheading(0)
    t.pendown()
    for i in range(1,501,5):
        t.forward(i)
        t.right(angle_)
    t.penup()
    t.ht()   

def main():
    win = turtle.Screen()
    win.bgcolor("lightgreen")
    win.title("Wieloboki")
    win.screensize(1800,600)

    sprmenu = False
    while sprmenu == False:
        czysc_ekran()
        print("Program uzywając grafiki zółwia rysuje nastepujace figury geometryczne:\n(a) 5 dwie spirale")
        print("X - Wyjście z progrmmu.")
        wybor = input("Wybierz A lub X i zatwierdź klawiszem ENTER.\n")
    
        if wybor == "a" or wybor == "A":
            draw_spiral(-300,0,90)
            draw_spiral(300,0,89)
     
        elif wybor == "x" or wybor == "X":
           sprmenu = True
    
if __name__ == "__main__":
    main()
