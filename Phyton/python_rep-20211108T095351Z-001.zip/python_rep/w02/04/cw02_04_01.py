
"""Ćwiczenie nr 2"""
"""Część 4 Zadanie nr 1. Uzywajac grafiki zółwia napisz program rysujący ponizszy kształt:
(a) 5 kwadratów obok siebie
"""
import math


import turtle
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def rysuj_kw(t_, dl_bok_):
        """Niech ˙zółw t narysuje wielokąty"""
        kat_=90 
        dl_bok_
        
        for i in range(4):
            t_.forward(dl_bok_)
            t_.left(kat_)


def main():
    win = turtle.Screen()
    win.bgcolor("lightgreen")
    win.title("5 kwadratów")
    win.screensize(1000,300)
    tom = turtle.Turtle()
    tom.color("pink")
    tom.pensize(10)
    
    spr_menu = False
    
    
    while spr_menu == False:
        czysc_ekran()
        print("Program uzywając grafiki zółwia rysuje nastepujace kształty:\n(a) 5 kwadratów obok siebie.")
        print("\nX - Wyjście z progrmmu.")
        wybor = input("\nWybierz A lub X  i zatwierdź klawiszem ENTER.\n")
        tom.clear()
        
        if wybor == "a" or wybor == "A":
            tom.penup()
            tom.setpos(-400,-50)
            for i in range(5):
                tom.pendown()
                rysuj_kw(tom,100)
                tom.penup()
                tom.fd(150)
            
        elif wybor == "x" or wybor == "X":
           spr_menu = True
    
    #win.mainloop()
if __name__ == "__main__":
    main()
