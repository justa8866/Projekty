
"""Ćwiczenie nr 2"""
"""Część 5 Zadanie nr 5. Wykorzystaj program z zadania 3 (z zestawu do wykładu 3) aby napisac funkcje draw_star, która zostanie wykorzystana do narysowania pięciu pentagramów.
"""

import math
import turtle
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")


def draw_star(t_, n_,length_ ):
    """Niech ˙zółw t narysuje kształt"""
    kat_=180 - (((n_ - 2) * 180) / n_) 
    r_= (n_ * length_) / (2 * math.pi)
    t_.penup()
    t_.right(90+(180/n_))
    t_.fd(r_)
    t_.left(90+(180/n_))
    length_m = length_ / 2
            
    for k in range(n_):
        t_.pendown()
        t_.left(36)
        for k in range(5):
            t_.forward(length_m)
            t_.left(144)
        t_.penup()
            
        t_.right(36)
        t_.forward(length_)
        t_.left(kat_)
        t_.ht()

def main():
    win = turtle.Screen()
    win.bgcolor("lightgreen")
    win.title("Wieloboki")
    win.screensize(600,600)
    t = turtle.Turtle()
    t.color("blue")
    t.pensize(5)

    
    sprmenu = False
    while sprmenu == False:
        czysc_ekran()
        print("Program uzywając grafiki zółwia rysuje nastepujace figury geometryczne:\n(a) 5 pentagramów na planie pentagramu")
        print("X - Wyjście z progrmmu.")
        wybor = input("Wybierz A lub X i zatwierdź klawiszem ENTER\n")
        t.clear()
        if wybor == "a" or wybor == "A":
            draw_star(t,5,200)
                    
                
        elif wybor == "x" or wybor == "X":
           sprmenu = True
    
if __name__ == "__main__":
    main()
