
"""Ćwiczenie nr 2"""
"""Część 4 Zadanie nr 2. Uzywajac grafiki zółwia napisz program rysujący ponizszy kształt:
(a) 5 kwadrtów wpisanych w siebie
"""
import math

import turtle

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def rysuj_kw(t_, dl_bok_):
        """Niech ˙zółw t narysuje kwadrat"""
        kat_=90 
        dl_bok_
        
        for i in range(4):
            t_.forward(dl_bok_)
            t_.left(kat_)


def main():
    win = turtle.Screen()
    win.bgcolor("lightgreen")
    win.title("Wieloboki")
    win.screensize(400,400)
    tom = turtle.Turtle()
    tom.color("pink")
    tom.pensize(10)
    
    spr_menu = False
    
    
    while spr_menu == False:
        czysc_ekran()
        print("Program uzywając grafiki zółwia rysuje nastepujace kształty:\n(a) 5 kwadratów wpisanych w siebie.")
        print("\nX - Wyjście z progrmmu.")
        wybor = input("\nWybierz A lub X  i zatwierdź klawiszem ENTER\n")
        tom.clear()
        tom.penup()
        tom.setpos(-200,-50)


        if wybor == "a" or wybor == "A":
            for i in range(1,6):
                print(i)
                dl_boku=i*50
                tom.penup()
                tom.setpos(-dl_boku*0.5,-dl_boku*0.5)
                tom.pendown()
                rysuj_kw(tom,dl_boku)
                tom.penup()
                tom.home()
            tom.ht()
        elif wybor == "x" or wybor == "X":
           spr_menu = True
    
    win.closescreen()
if __name__ == "__main__":
    main()
