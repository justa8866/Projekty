"""Ćwiczenie nr 2"""
"""Część 3  Zadanie 
Wczytać liczbę naturalną n, a następnie wczytując kolejno ciąg n liczb rzeczywistych
a1, a2, . . . , an wypisać w kolejnych liniach liczby tego ciągu w następującej kolejności:
a2, a3, . . . , an, a1."""

def sprawdz_N(str_):
    #funkcja sprwdza czy cig znaków może być przekonwertowany na liczbę naturalną
        
    try:
        spr_=int(str_)
        if spr_>0:
            spr_=True
        else:
            print("Podana liczba nie jest liczbą nauralną")
            spr_= False
    except:
        print("Podana liczba nie jest liczbą naturalną.")
        spr_= False
        
    return(spr_)

def sprawdz_R(str_):
        #funkcja sprwdza czy cig znaków może być przekonwertowany na liczbę rzeczywistą
    try:
        float(str_)
        spr_=True
    except:
        print("Podana liczba nie jest liczbą rzeczywistą.")
        spr_= False
        
    return(spr_)

def main():
    print("Program wczytuje liczbę naturalną n, a następnie wczytując kolejno ciąg n liczb rzeczywistych (a1, a2, . . . , an)  wypisuje w kolejnych liniach liczby tego ciągu w następującej kolejności: a2, a3, . . . , an, a1.\n")
    

    spr_1=False
    while spr_1==False:
        n_str = input("Podaj liczbę naturlną n - ilość wyrazów cigu: ")
        spr_1 =sprawdz_N(n_str)
    n=int(n_str)    
    
    
    #wprowadzenie pierwszego wyrazu ciągu
    spr_2=False
    while spr_2==False:
        str_wyraz = (input("Podaj 1 wyraz ciągu: "))
        str_wyraz = str_wyraz.replace(",",".")
        spr_2 =sprawdz_R(str_wyraz)
    
    wyraz = float(str_wyraz)
    ciag = []
    ciag.append(wyraz)
    
    # wprowdzenie kolejnych wyrazów ciągu
    for i in range(2,n+1):
        spr_3 = False
        while spr_3 == False:
            str_wyraz = input("Podaj {} wyraz ciągu: ".format(i))
            str_wyraz = str_wyraz.replace(",",".")
            spr_3 = sprawdz_R(str_wyraz)
        
        wyraz=float(str_wyraz)
        ciag.append(wyraz)
        print(ciag[i-1])     
        #print("{}. Meżny bądź, chrón pułk twój i sześć flag.".format(i))
    #wizualizacja pierwszego wyrazu
    print(ciag[1])
if __name__ == "__main__":
    main()
