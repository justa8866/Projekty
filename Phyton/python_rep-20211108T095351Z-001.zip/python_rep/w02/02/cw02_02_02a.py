"""Ćwiczenie nr 2"""
"""Część 2  Zadanie a
Do kazdego z ponizszych punktów nalezy napisac odpowiedni program. W kazdym z tych programów wczytac liczbe naturalna n, a nastepnie wczytujac kolejno n liczb rzeczywistych obliczyc wartosc odpowiednich wyrazen:
(a) a1 + a2 + : : : + an"""

import math
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def sprawdz_N(str_):
    #funkcja sprwdza czy cig znaków może być przekonwertowany na liczbę naturalną
        
    try:
        spr_=int(str_)
        if spr_>0:
            spr_=True
        else:
            print("Podana liczba nie jest liczbą nauralną")
            spr_= False
    except:
        print("Podana liczba nie jest liczbą naturalną.")
        spr_= False
        
    return(spr_)

def sprawdz_R(str_):
        #funkcja sprwdza czy cig znaków może być przekonwertowany na liczbę rzeczywistą
    try:
        float(str_)
        spr_=True
    except:
        print("Podana liczba nie jest liczbą rzeczywistą.")
        spr_= False
        
    return(spr_)

def main():
    print("Program wczytuje liczbe naturalną n, a nastepnie wczytujac kolejno n liczb rzeczywistych obliczycza sumę wczytanych liczb rzeczywistych.\n")
    

    spr_1=False
    while spr_1==False:
        n_str = input("Podaj liczbę naturlną n - ilość wyrazów cigu: ")
        spr_1 =sprawdz_N(n_str)
    n=int(n_str)    
    
    # wprowdzenie kolejnych wyrazów ciągu
    ciag=[]
    for i in range(1,n+1):
        spr_2 = False
        while spr_2 == False:
            str_wyraz = input("Podaj {} wyraz ciągu: ".format(i))
            str_wyraz = str_wyraz.replace(",",".")
            spr_2 = sprawdz_R(str_wyraz)
        
        wyraz=float(str_wyraz)
        ciag.append(wyraz)
             
    #obliczanie 
    wynik = 0
    for i in range(1,n+1):
        wynik= wynik + ciag[i-1]
    
    #wizualizacja pierwszego wyrazu
    czysc_ekran()
    
    for i in range(1,n+1):
        print("{}. wyraz ciągu: {}".format(i,ciag[i-1]))
    
    print("\nSuma wyrazów ciągu: {}".format(wynik))

if __name__ == "__main__":
    main()
