"""Ćwiczenie nr 2"""
"""Część 4  Zadanie 
Napisz program, który wypisuje na ekranie 64 razy nastepujace zdanie: Męzny bąadź, chroń pułk twój i sześć flag."""

def main():
    print("Program, który wypisuje na ekranie 64 razy nastepujace zdanie:\n\"Męzny bąadź, chroń pułk twój i sześć flag.\"")

    input("Aby wykonać progrm wciśnij ENTER")

    for i in range(1,65):
        print("{}. Męzny bąadź, chroń pułk twój i sześć flag.".format(i))
  
if __name__ == "__main__":
    main()
