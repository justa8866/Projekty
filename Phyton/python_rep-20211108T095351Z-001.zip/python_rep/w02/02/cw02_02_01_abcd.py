"""Ćwiczenie nr 2"""
"""Część 2  Zadanie 
Do każdego z poniższych punktów należy napisać odpowiedni program obliczający i wypisujący określoną w tym punkcie wartość:
(a) sumę wszystkich liczb parzystych od 2 do 100 (włącznie);
(b) sumę kwadratów wszystkich liczb od 1 do 100 (włącznie);
(c) sumę potęg liczby 2 dla wykładników od 1 do 63 (włącznie);
(d) sumę wszystkich liczb nieparzystych pomiędzy a i b (włącznie), gdzie a i b są zmiennymi, do których uprzednio należy wczytać dwie liczby całkowite. Dla a > b suma powinna wynosić zero."""
import math

def program_a():
    #program liczy sumę wszystkich liczb parzystych od 2 do 100 (włącznie)
    suma__=0
    
    for i in range(2,101,2):
        suma__= suma__ + i
    
    print("Suma wszystkich liczb parzystych od 2 do 100 (włącznie) jest równa:\n{}.".format(suma__))

    
    input("\nWciśnij ENTER aby wrócić do menu wyboru programu.\n")
    czysc_ekran()

    return(suma__)

def program_b():
    #program liczy sumę kwadratów wszystkich liczb od 1 do 100 (włącznie)
    suma__=0
    
    for i in range(1,101):
        suma__= suma__ + i**2
    
    print("Suma kwadratów wszystkich liczb od 1 do 100 (włącznie) jest równa:\n{}.".format(suma__))

    input("\nWciśnij ENTER aby wrócić do menu wyboru programu.\n")
    czysc_ekran()
    return(suma__)
    
def program_c():
    #program liczy sumę potęg liczby 2 dla wykładników od 1 do 63 (włącznie)
    suma__=0
    
    for i in range(1,64):
        suma__= suma__ + 2**i
    
    print("Suma potęg liczby 2 dla wykładników od 1 do 63 (włącznie) jest równa:\n{}.".format(suma__))

    input("\nWciśnij ENTER aby wrócić do menu wyboru programu.\n")
    czysc_ekran()
    return(suma__)
    
def program_d():
    #program liczy sumę wszystkich liczb nieparzystych pomiędzy a i b (włącznie), gdzie a i b są zmiennymi, do których uprzednio należy wczytać dwie liczby całkowite. Dla a > b suma powinna wynosić zero.
    suma__= 0
    licz_a__= 0
    licz_b__= 0

    licz_a__=podaj_licz("A",3)
    licz_b__=podaj_licz("B",3)

    if licz_a__>=0:#najwięka liczba parzysta
        licz_a_Z__ = int(math.floor(licz_a__))
        while licz_a_Z__%2==1:
            licz_a_Z__=licz_a_Z__-1
    else: #najniższa liczba parzysta
        licz_a_Z__ = math.ceil(licz_a__)
        while licz_a_Z__%2==1:
            licz_a_Z__=licz_a_Z__+1
    print(licz_a__,licz_a_Z__)
    
    if licz_b__>=0:#najwięka liczba parzysta
        licz_b_Z__ = math.floor(licz_b__)
        while licz_b_Z__%2==1:
            licz_b_Z__=licz_b_Z__-1
    else: #najniższa liczba parzysta
        licz_b_Z__ = int(math.ceil(licz_b__))
        while licz_b_Z__%2==1:
            licz_b_Z__ = licz_b_Z__+1
    print(licz_b__,licz_b_Z__)
    
    if licz_a__<=licz_b__:
        for i in range(licz_a_Z__,licz_b_Z__+1,2):
            suma__= suma__ + i
    else:
        suma__= 0
    
    czysc_ekran()
    print("Suma wszystkich liczb nieparzystych pomiędzy liczbą {} a liczbą {} (włącznie) jest równa:\n{}.".format(licz_a__,licz_b__,suma__))

    input("\nWciśnij ENTER aby wrócić do menu wyboru programu.\n")
    czysc_ekran()
    return(suma__)

def czysc_ekran():# czyści ekran
    try:
        print(chr(27)+"[2j")
        print("\033c")
        print("\x1bc")
    except:
        print("\n\n\n")

def sp_czy_licz(str_str):
    # funkcja sprawdza czy ciąg znaków srt_ może być przekształcona na liczbę i czy liczba nie jest ujemna
    try:
        licz_licz = float(str_str)
        spr_spr = True
    except:
        spr_spr = False
    finally:
        if spr_spr== True:
            print("Wprowadzona liczba poprawna:",licz_licz)
        else:
            print("Nie wprowadzono poprawnie liczby")
        return(spr_spr)

def podaj_licz(co__,il_pr_):
    # funkcja wprowadza liczbę
    # kożysta z funkcji sp_czy_licz
    # il_pr_ zmienna ilość prób 
    # po x złych próbach przyjmuje 1
    spr__ = False
    while spr__==False and il_pr_>=0:
        if il_pr_<=0:
            licz__=0
            il_pr_=il_pr_-1
            
            print("\nNie wprowadzono poprawnie liczby {}\nPrzyjęto liczbę {} równą 0.".format(co__,co__))
            input("\nWciśnij ENTER aby kontynuować.\n")
            czysc_ekran()
        else:    
            print("\nPozostała ilość prób:",il_pr_)
            str__ = input("Podaj liczbę {}:".format(co__))
            str__=str__.strip(" ")
            str__ = str__.replace(",",".")
            if sp_czy_licz(str__) == True:
                licz__ = float(str__)
                spr__ = True
            else:
                il_pr_=il_pr_-1
    return(licz__)

def main(): 
    spr_m = 0
    while spr_m == 0:
        print("Program oblicza:\n(a) sumę wszystkich liczb parzystych od 2 do 100 (włącznie);\n(b) sumę kwadratów wszystkich liczb od 1 do 100 (włącznie);\n(c) sumę potęg liczby 2 dla wykładników od 1 do 63 (włącznie);\n(d) sumę wszystkich liczb nieparzystych pomiędzy a i b (włącznie), gdzie a i b są zmiennymi, do których uprzednio należy wczytać dwie liczby całkowite. Dla a > b suma powinna wynosić zero.")
        print("\nWybierz program:\n(a) sumę wszystkich liczb parzystych od 2 do 100 (włącznie);\n(b) sumę kwadratów wszystkich liczb od 1 do 100 (włącznie);\n(c) sumę potęg liczby 2 dla wykładników od 1 do 63 (włącznie);\n(d) sumę wszystkich liczb nieparzystych pomiędzy a i b (włącznie), gdzie a i b są zmiennymi, do których uprzednio należy wczytać dwie liczby całkowite. Dla a > b suma powinna wynosić zero.")
        print("\nWpisz X i ENTER aby zakończyć program.\n")
        wybor=input("Wybierz A, B, C, D lub X i zatwierdź enterem.\n")
        if wybor == "a" or wybor == "A":
            czysc_ekran()
            program_a()
        elif wybor == "b" or wybor == "B":
            czysc_ekran()
            program_b()
        elif wybor == "c" or wybor == "C":
            czysc_ekran()
            program_c()
        elif wybor == "d" or wybor == "D":
            czysc_ekran()
            program_d()
        elif wybor == "x" or wybor == "X":
            spr_m=1
            czysc_ekran()
            print("Do zobaczenia!")
        else:
            czysc_ekran()

if __name__ == "__main__":
    main()
