
"""Ćwiczenie nr 2"""
"""Część 3 Zadanie nr 7. Uzywajac grafiki zółwia napisz program rysujący ponizszy kształt:
(a) tarcza zegara
"""
import math
import datetime

import turtle
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")



def rysuj_zegar(t_,r_):
        """Niech ˙zółw t narysuje tarcze zegara"""
              
        t_.shape("turtle")
        t_.color("blue")
        t_.setheading(90)
        t_.pensize(5)
        
        for i in range(12):
            t_.setheading(90)
            t_.penup()
            t_.right(i*30)
            t_.forward(r_)
            t_.pendown()
            t_.forward(r_ / 12)
            t_.penup()
            t_.forward(r_ / 8)
            t_.stamp()
            t_.home()

def rysuj_czas(t_,r_):
    teraz = datetime.datetime.now()
    godzina = teraz.hour
    minuta = teraz.minute
    
    t_.shape("triangle")
    t_.color("black")
    t_.pensize(10)
    t_.setheading(90)
    t_.right((godzina + (minuta / 60))*30)
    t_.pendown()
    t_.forward(r_ *0.50)
    t_.penup()
    t_.home()
    t_.setheading(90)
    t_.right(minuta * 6)
    t_.pensize(5)
    t_.pendown()
    t_.forward(r_ *0.8)
    t_.penup()
    t_.home()

def main():
    win = turtle.Screen()
    win.bgcolor("lightgreen")
    win.title("Zegar")
    tom=turtle.Turtle()
    spr_menu = False
    while spr_menu == False:
        czysc_ekran()
        print("Program uzywając grafiki zółwia rysuje nastepujace kształty:\n(a) tarcze zegara")
        print("\nX - Wyjście z progrmmu.")
        wybor = input("\nWybierz A, X lub zapytaj żółwia o godzinę i zatwierdź klawiszem ENTER\n")
        tom.clear()
        
        if wybor == "a" or wybor == "A":
            rysuj_zegar(tom,100)
        
        elif wybor.count("godzina") > 0 or wybor.count("czas") > 0:
            rysuj_zegar(tom,100)
            rysuj_czas(tom,100)           

        elif wybor == "x" or wybor == "X":
           spr_menu = True
    
    #win.mainloop()
if __name__ == "__main__":
    main()
