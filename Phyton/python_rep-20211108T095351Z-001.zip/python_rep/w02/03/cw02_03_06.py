"""Ćwiczenie nr 2"""
"""Część 3 Zadanie nr 6. Uzywajac grafiki zółwia napisz program rysujący ponizszy kształt:
(a) pentagram
"""
import math
import turtle
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def rysuj_penta(t_, dl_bok_):
        """Niech ˙zółw t narysuje pentagram"""
        t_.penup()
        dl_bok_= 2 * math.pi * dl_bok_ / 5
        t_.setpos(-int(dl_bok_*0.3),-int(dl_bok_*0.5))
        t_.pendown()
        t_.left(36)
        for i in range(5):
            t_.forward(dl_bok_)
            t_.left(144)

def main():
    win = turtle.Screen()
    win.bgcolor("lightgreen")
    win.title("Pentagram")
    bob = turtle.Turtle()
    bob.color("blue")
    bob.pensize(3)

    spr_menu = False
    while spr_menu == False:
        czysc_ekran()
        print("Program uzywając grafiki zółwia rysuje nastepujace figury geometryczne:\n(a) pentagram")
        print("\nX - Wyjście z progrmmu.")
        wybor = input("\nWybierz A lub X i zatwierdź klawiszem ENTER\n")
        bob.clear()
        if wybor == "a" or wybor == "A":
            rysuj_penta(bob,150)
                    
        elif wybor == "x" or wybor == "X":
           spr_menu = True
    
    win.mainloop()
if __name__ == "__main__":
    main()
    
