
"""Ćwiczenie nr 2"""
"""Część 3 Zadanie nr 5. Uzywajac grafiki zółwia oraz instrukcji iteracyjnej for napisz program, który rysuje nastepujace figury geometryczne:
(a) osmiokat foremny
(b) dziewieciokąt foremny
(c) dziesieciokąt foremny
(d) dwunastokąt foremny
(e) pietnastokąt foremny
(f) osiemnastokąt foremny
(g) dwudziestokąt foremny
"""
import math
import turtle
def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def rysuj_fig(t_, r_,il_bok_ ):
        """Niech ˙zółw t narysuje wielokąty"""
        kat_=180 - ((il_bok_ - 2) * 180) / il_bok_ 
        dl_bok_= 2 * math.pi * r_ / il_bok_
        t_.penup()
        t_.setpos(-int(dl_bok_*0.5),-int(dl_bok_))
        t_.pendown()
        for i in range(il_bok_):
            t_.forward(dl_bok_)
            t_.left(kat_)
        

def main():
    win = turtle.Screen()
    win.bgcolor("lightgreen")
    win.title("Wieloboki")
    bob = turtle.Turtle()
    bob.color("blue")
    bob.pensize(3)

    
    spr_menu = False
    while spr_menu == False:
        czysc_ekran()
        print("Program uzywając grafiki zółwia rysuje nastepujace figury geometryczne:\n(a) osmiokat foremny\n(b) dziewieciokąt foremny\n(c) dziesieciokąt foremny\n(d) dwunastokąt foremny\n(e) pietnastokąt foremny\n(f) osiemnastokat foremny\n(g) dwudziestokąt foremny")
        print("X - Wyjście z progrmmu.")
        wybor = input("Wybierz A, B, C, D, E, F, G lub X i zatwierdź klawiszem ENTER\n")
        bob.clear()
        if wybor == "a" or wybor == "A":
            rysuj_fig(bob,100,8)
                    
        elif wybor == "b" or wybor == "B":
           rysuj_fig(bob,100,9)
        
        elif wybor == "c" or wybor == "C":
           rysuj_fig(bob,100,10)
        
        elif wybor == "d" or wybor == "D":
           rysuj_fig(bob,100,12)
        
        elif wybor == "e" or wybor == "E":
           rysuj_fig(bob,100,15)
        
        elif wybor == "f" or wybor == "F":
           rysuj_fig(bob,100,18)
        
        elif wybor == "g" or wybor == "G":
           rysuj_fig(bob,100,20)     
        
        elif wybor == "x" or wybor == "X":
           spr_menu = True
    
    win.mainloop()
if __name__ == "__main__":
    main()
