"""Ćwiczenie nr 5"""
"""Część 1"""
"""Zadanie nr 5"""
"""Napisz funkcje minmax, która zwraca jako swój wynik krotke dwóch liczb, z których pierwsza to minimum a druga to maksimum z listy podanej jako jedyny argument tej funkcji. Przykładowo, dla listy a = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31] funkcja minmax powinna zwrócic krotke (28, 31). Przetestuj te funkcje w funkcji main."""

def main() -> None:
    czysc_ekran()
    print("Program wczytyje listę.\nNastępnie znajduje maksimum i minimum listy.\n")
    lista = wprowadz_liste()

    wynik = minmax(lista)
    wiz(lista, wynik)

def czysc_ekran() -> None: # czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def minmax(lista_: list) -> tuple: #oblicza min i max wartość listy
    if len(lista_) == 0:
        return (None, None)
    else:
        min_ = lista_[0]
        max_ = lista_[0]
        for i in range(0, len(lista_)):
            if min_ > lista_[i]:
                min_ = lista_[i]
            if max_ < lista_[i]:
                max_ = lista_[i]
    return (min_, max_)


def wprowadz_liste() -> list: # funkcja wczytuje listę
    lista_ = []
    nr_ele = 1
    wyraz_ = " "
    print("Wprowadzenie pustego elementu kończy wczytywanie listy.")
    while len(wyraz_) > 0:
        print("Wprowadź {}. element listy:".format(nr_ele), end=" ")
        wyraz_ = input()
        try:
            lista_.append(float(wyraz_))
            nr_ele += 1
        except:
            try:
                wyraz_try = eval(wyraz_)
                lista_.append(float(wyraz_try))
                nr_ele += 1
            except:
                if wyraz_ == "":
                    break
                else:
                    print("Podana wartość nie jest liczbą")
    return lista_

def wiz(lista_: list, wynik_: tuple) -> None: #wizualizacja wników
    czysc_ekran()
    print("Wprowadzono listę:\n{}.".format(lista_))
    min_lista_, max_lista_ = wynik_
    print("Wartość minimalna listy to:  {}.".format(min_lista_))
    print("Wartość maksymanla listy to: {}.".format(max_lista_))

if __name__ == "__main__":
    main()
