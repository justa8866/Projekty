"""Ćwiczenie nr 5"""
"""Część 1"""
"""Zadanie nr 9"""
"""Dla każdego z ponizszych punktów napisz funkcje, która wykonuje odpowiednie zadanie dla listy liczb całkowitych bedącej jej argumentem. Przetestuj każdą funkcję w funkcji main."""

zad = {"a":"(a) Zamienia miejscami pierwszy i ostatni element w liście.", "b":"(b) Przesuwa wszystkie elementu o jedną pozycję w prawo a ostatni element przenosi na poczatek listy.","c":"(c) Zastepuje wszystkie parzyste elementy listy liczbą 0.", "d":"(d) Zastepuje każdy element listy, z wyjatkiem pierwszego i ostatniego, przez wieksza z dwóch sasiednich elementów.","e":"(e) Usuwa element środkowy, jesli długość listy jest nieparzysta, lub dwa środkowe elementy, jesli długość jest parzysta.", "f": "(f) Przenosi wszystkie parzyste elementy listy na jej poczatek, z zachowaniem kolejnosci elementów.", "g":"(g) Zwraca drugi co do wielkości element na liście", "h": "(h) Zwraca True, jesli lista jest posortowana w porzadku rosnacym. W przeciwnym przypadku zwraca False.", "i":"(i) Zwraca True, jesli lista zawiera jakiekolwiek dwie sąsiadujące równe elementy. W przeciwnym przypadku zwraca False", "j": "(j) Zwraca True, jesli lista zawiera jakiekolwiek dwa równe elementy. W przeciwnym przypadku zwraca False"}

def main() -> None:
    lista = []
    spr_menu = True

    while spr_menu:
        wybor = menu()
        spr_menu = sprawdz_wybor(wybor)

    lista = wprowadz_liste()
    wynik = eval("licz_" + wybor + "(lista)")
    wiz(lista, wynik, wybor, zad)

def licz_a(lista_: list) -> list:
    lista_new_ = lista_.copy()
    if len(lista_) == 0:
        return []
    else:
        lista_new_[0], lista_new_[-1] = lista_[-1], lista_[0]
        return lista_new_
def licz_b(lista_: list) -> list:
    if len(lista_) == 0:
        return []
    else:
        lista_new_ = lista_.copy()
        lista_new_[0] = lista_[-1]
        for i in range(len(lista_)-1):
            lista_new_[i  +1] = lista_[i]
        return lista_new_
def licz_c(lista_: list) -> list:
    if len(lista_) == 0:
        return []
    else:
        lista_new_ = lista_.copy()
        for i in range(len(lista_)):
            if i % 2 == 1:
                lista_new_[i] = 0
        return lista_new_
def licz_d(lista_: list) -> list:
    if len(lista_) == 0:
        return []
    elif len(lista_) <= 2:
       lista_new_ = lista_.copy()
       return lista_new_
    else:
        lista_new_ = lista_.copy()
        for i in range(1, len(lista_)-1):
            if lista_new_[i] < lista_[i-1]:
                lista_new_[i] = lista_[i -1]
            if lista_new_[i] < lista_[i+1]:
                lista_new_[i] = lista_[i+1]
        return lista_new_
def licz_e(lista_: list) -> list:
    if len(lista_) <= 2:
        return []
    else:
        lista_new_ = lista_.copy()
        if len(lista_) % 2 == 1:
            lista_new_.pop(len(lista_) // 2)
        else:
            lista_new_.pop((len(lista_) // 2)-1)
            lista_new_.pop((len(lista_) // 2)-1)
        return lista_new_
def licz_f(lista_: list) -> list:
    if len(lista_) == 0:
        return []
    else:
        lista_new_ = []
        lista_npar_ = []
        for i in range(len(lista_)):
            if lista_[i] % 2 == 0:
                lista_new_.append(lista_[i])
            else:
                lista_npar_.append(lista_[i])
        lista_new_.extend(lista_npar_)
        return lista_new_
def licz_g(lista_: list) -> list:
    if len(lista_) <= 1:
        return []
    else:
        lista_new_ = lista_.copy()
        lista_new_.sort()
        return lista_new_[-2]
def licz_h(lista_: list) -> bool:
    if len(lista_) == 0:
        return False
    else:
        lista_new_ = lista_.copy()
        lista_new_.sort()
        for i in range(len(lista_)):
            if lista_new_[i] != lista_[i]:
                return False
        return True
def licz_i(lista_: list) -> bool:
    if len(lista_) <= 1:
        return False
    else:
        for i in range(1,len(lista_)):
            if lista_[i] == lista_[i - 1]:
                return True
        return False
def licz_j(lista_: list) -> bool:
    if len(lista_) <= 1:
        return False
    else:
        lista_new_ = lista_
        lista_new_.sort()
        for i in range(1,len(lista_)):
            if lista_new_[i] == lista_new_[i - 1]:
                return True
        return False

def czysc_ekran() -> None: # czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def menu() -> str: # funkcja menu wyboru
    czysc_ekran()
    print("Program wczytuje listę liczb całkowitych. Następnie wykonuje odpowiednie zadanie:")
    print("(a) Zamienia miejscami pierwszy i ostatni element w liście.")
    print("(b) Przesuwa wszystkie elementu o jedną pozycję w prawo a ostatni element przenosi na poczatek listy.")
    print("(c) Zastepuje wszystkie parzyste elementy listy liczbą 0.")
    print("(d) Zastepuje każdy element listy, z wyjatkiem pierwszego i ostatniego, przez wieksza z dwóch sasiednich elementów.")
    print("(e) Usuwa element środkowy, jesli długość listy jest nieparzysta, lub dwa środkowe elementy, jesli długość jest parzysta.")
    print("(f) Przenosi wszystkie parzyste elementy listy na jej poczatek, z zachowaniem kolejnosci elementów.")
    print("(g) Zwraca drugi co do wielkości element na liście.")
    print("(h) Zwraca True, jesli lista jest posortowana w porzadku rosnacym. W przeciwnym przypadku zwraca False.")
    print("(i) Zwraca True, jeśli lista zawiera jakiekolwiek dwie sąsiadujące równe elementy. W przeciwnym przypadku zwraca False.")
    print("(j) Zwraca True, jesli lista zawiera jakiekolwiek dwa równe elementy. W przeciwnym przypadku zwraca False.")

    wybor_ = input("\nWprowadź odpowiednią literę (a, b, c, d, e, f, g, h, i lub j) i naciśnij ENTER aby utworzć odpowiednią listę.\n>>>")
    wybor_ = wybor_.lower()
    if len(wybor_) > 1:
        wybor_ = wybor_[-1]
    return wybor_
     
def sprawdz_wybor(wybor_: str) -> bool: # tworzy liste na podstawie wyboru wybor_ oraz zwraca informacje True - nie rozpoznano wyboru i False - rozpoznano wybór
    klawisze = "abcdefghij"
    suma = 0
    for i in klawisze:
        spr = wybor_.count(i)
        suma += spr
    if suma == 1:
        return False
    else:
        return True

def wprowadz_liste() -> list: # funkcja wczytuje listę
    lista_ = []
    nr_ele = 1
    wyraz_ = " "
    print("Wprowadzenie pustego elementu kończy wczytywanie listy.")
    while len(wyraz_) > 0:  
        print("Wprowadź {}. element listy:".format(nr_ele), end=" ")
        wyraz_ = input()
        try:
            lista_.append(int(wyraz_))
            nr_ele += 1
        except:
            if wyraz_ == "":
                break
            else:
                print("Podana wartość nie jest liczbą całkowitą.")
    print(lista_)
    return lista_

def wiz(lista_: list, wynik_: list, wybor_: str, zad_: dict) -> None: # wizualizacja wników
    czysc_ekran()
    print("Wczytano listę:", lista_)
    print("Wybrano operację:\n",zad_[wybor_], "\nWynik: ", wynik_, sep = "")

if __name__ == "__main__":
    main()
