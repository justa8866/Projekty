"""Ćwiczenie nr 5"""
"""Część 1"""
"""Zadanie Nr 1"""
"""Zakładajac, iż dana jest lista lista = [], napisac jedna lub dwie instrukcje iteracyjne for wypełniajace listę lista nastepujacymi liczbami:
(a) 1 2 3 4 5 6 7 8 9 10
(b) 0 2 4 6 8 10 12 14 16 18 20
(c) 1 4 9 16 25 36 49 64 81 100
(d) 0 0 0 0 0 0 0 0 0 0
(e) 0 1 0 1 0 1 0 1 0 1
(f) 0 1 2 3 4 0 1 2 3 4"""

def czysc_ekran() -> None: # czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def tworz_liste(liczba_od_: int, liczba_do_: int, krok_: int, ilosc_powturzen_: int, operator_: str) -> list:
     #funkcja tworzy listę liczba_n elementową o począdku  liczba_od_ do liczba_do_ włącznie z krokiem krok_ i operacją na kolejnych wyrazach ciągu - operator (wyraz ciągu i) np i**2 - podnieś do kwadratu.
    try:
        lista_ = []
        for j in range (0, ilosc_powturzen_):
            for i in range(liczba_od_, liczba_do_ + 1, krok_):
                lista_.append(eval(operator_))
        return lista_
    except:
        print("Wystąpił błąd uniemożliwiający stworzeie listy.")
        return []

def wybierz_parametry(wybor_: str) -> tuple: #funkcja zwraca krotkę parametry_ parametrów funkcji tworz_liste na podstawie wybor_
    if wybor_ == "a" or wybor_ == "A":
        parametry_ = (1,10,1,1,'i')
    elif wybor_ == "b" or wybor_ == "B":
        parametry_ = (0,20,2,1,'i')
    elif wybor_ == "c" or wybor_ == "C":
        parametry_ = (1,10,1,1,'i**2')
    elif wybor_ == "d" or wybor_ == "D":
        parametry_ = (0,0,1,10,'i')
    elif wybor_ == "e" or wybor_ == "E":
        parametry_= (0,1,1,5,'i')
    elif wybor_ == "f" or wybor_ == "F":
        parametry_ = (0,4,1,2,'i')
    return parametry_

def menu() -> str: # funkcja menu wyboru
    czysc_ekran()
    print("Program wykorzystując itrracje for tworzy odpowiednią listę.")
    print("(a) 1 2 3 4 5 6 7 8 9 10")
    print("(b) 0 2 4 6 8 10 12 14 16 18 20")
    print("(c) 1 4 9 16 25 36 49 64 81 100")
    print("(d) 0 0 0 0 0 0 0 0 0 0")
    print("(e) 0 1 0 1 0 1 0 1 0 1")
    print("(f) 0 1 2 3 4 0 1 2 3 4")
    wybor_ = input("\nWprowadź odpowiednią literę (a,b,c,d,e lub f) i wciśnij ENTER aby utworzć odpowiednią listę.\n>>>")
    if len(wybor_) >= 1:
        wybor_ = wybor_[-1]
    return wybor_
def sprawdz_wybor(wybor_: str) -> bool: # tworzy listę na podstawie wyboru wybor_ oraz zwraca informacje True - nie rozpoznano wyboru i False - rozpoznano wybór
    klawisze = "aAbBcCdDeEfF"
    suma = 0
    for i in klawisze:
        spr = wybor_.count(i)
        suma += spr
    if suma == 1:
        return False
    else:
        return True

def wiz(wynik_: list) -> None: # wizualizacja wników
    czysc_ekran()
    print("Lista =", wynik_,"\n")

def main() -> None:
    lista = []
    spr_menu = True
    while spr_menu:
        wybor = menu()
        spr_menu = sprawdz_wybor(wybor) 

    od_, do_, krok_, il_pow, oper = wybierz_parametry(wybor)

    lista = tworz_liste(od_, do_, krok_, il_pow, oper)
    wiz(lista)
    #return lista
if __name__ == "__main__":
    main()
