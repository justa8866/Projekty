"""Ćwiczenie nr 5"""
"""Część 1"""
"""Zadanie Nr 3"""
"""Napisz funkcję ile_ujemnych, która zwraca jako swój wynik liczbę ujemnych elementów listy podanej jako jedyny argument tej funkcji. Przetestuj te funkcje w funkcji main."""

def czysc_ekran() -> None: # czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def ile_ujemnych(lista_: list) -> int:#liczy ilość liczb ujemnych w liście lista_
    try:
        ile_ = 0
        if len(lista_) == 0:
            return 0
        else:
            for i in range(0, len(lista_)):
                if lista_[i] < 0:
                    ile_ += 1
            return ile_
    except:
        print("Element listy o indeksie {} i wartości {} nie mógł być sprawdzony".format(i, lista_[i]))
        lista_.pop(i)
        ile_ujemnych(lista_)

def wprowadz_liste() -> list: # funkcja wczytuje listę
    lista_ = []
    nr_ele = 1
    wyraz_ = " "
    print("Wprowadzenie pustego elementu kończy wczytywanie listy.")
    while len(wyraz_) > 0:
        print("Wprowadź {}. element listy:".format(nr_ele), end=" ")
        wyraz_ = input()
        try:
            lista_.append(float(wyraz_))
            nr_ele += 1
        except:
            try:
                wyraz_try = eval(wyraz_)
                lista_.append(float(wyraz_try))
                nr_ele += 1
            except:
                if wyraz_ == "":
                    break
                else:
                    print("Podana wartość nie jest liczbą")
    return lista_

def wiz(lista_: list, wynik_: list) -> None: # wizualizacja wników
    czysc_ekran()
    print("Wprowadzono listę:", lista_)
    print("Ilość wyrazów ujemnych w liście:", wynik_)

def main() -> None:
    czysc_ekran()
    print("Program wczytyje listę.\nNastępnie ilczy ilość liczb ujemnych w liście.\n")
    lista = wprowadz_liste()
    wynik = ile_ujemnych(lista)
    wiz(lista, wynik)

if __name__ == "__main__":
    main()
