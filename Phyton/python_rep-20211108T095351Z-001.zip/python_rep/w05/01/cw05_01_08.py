"""Ćwiczenie nr 5"""
"""Część 1"""
"""Zadanie nr 8"""
"""Napisz program, który dodaje wszystkie liczby od 2 do 10000 do poczatkowo pustej listy, po czym usuwa wielokrotnosci 2 (ale nie 2), wielokrotnosci 3 (ale nie 3), i tak dalej, az do
wielokrotnosci 100. Nastepnie program wypisuje liczby pozostałe na liscie."""

def main() -> None:
    czysc_ekran()
    print("Porgram tworzy listę. Do poczatkowo pustej listy dodaje wszystkie liczby od 2 do 10000 , po czym usuwa wielokrotnosci 2 (ale nie 2), wielokrotnosci 3 (ale nie 3), i tak dalej, aż do wielokrotności 100. Nastepnie program wypisuje liczby pozostałe na liście.\n")
    input("Wciśnij ENTER")
    lista = tworz_liste()
    wiz(lista)

def czysc_ekran() -> None: # czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def tworz_liste() -> list: # funkcja tworzy listę zgodnie z 4 linią
    lista_ = []
    for i in range(2,10001):
        lista_.append(i)

    for i in range(2,101):
        j = 0
        while j < len(lista_):
            if lista_[j] % i == 0 and lista_[j] != i:
                lista_.remove(lista_[j])
            j += 1
    return lista_

def wiz(lista_: list) -> None: #wizualizacja wników
    czysc_ekran()
    print("Utworzono listę:")
    for i in range(len(lista_)):
        if (i + 1) % 10 == 0:
            print("{:>4}".format(lista_[i]), end = ",\n")
        else:
            print("{:>4}".format(lista_[i]), end = ", ")
        #print("{:>4}".format(lista_[i]), sep = " ", end = ", ")

if __name__ == "__main__":
    main()
