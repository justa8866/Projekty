"""Ćwiczenie nr 5"""
"""Część 1"""
"""Zadanie nr 6"""
"""Napisz funkcję obliczającą sumę przemienną wszystkich elementów na liscie. Przykładowo, dla listy 1 4 16 9 9 7 4 9 11 funkcja powinna obliczyć wynik funkcji jako 1 - 4 + 9 - 16 + 9 - 7 + 4 - 9 + 11 = -2 Przetestuj tę funkcję w funkcji main."""

def main() -> None:
    czysc_ekran()
    print("Program wczytyje listę.\nNastępnie oblicza sumę naprzemienną wyrazów listy.\n")
    lista = wprowadz_liste()
    wynik = suma_naprzemienna(lista)
    wiz(lista, wynik)

def czysc_ekran() -> None: # czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def suma_naprzemienna(lista_: list) -> float: #oblicza sumę przemienną wyrazów listy
    if len(lista_) == 0:
        return None
    else:
        suma_ = 0
        for i in range(0, len(lista_)):
            suma_ += (lista_[i] * ((-1)**i))
    return suma_

def wprowadz_liste() -> list: # funkcja wczytuje listę
    lista_ = []
    nr_ele = 1
    wyraz_ = " "
    print("Wprowadzenie pustego elementu kończy wczytywanie listy.")
    while len(wyraz_) > 0:
        print("Wprowadź {}. element listy:".format(nr_ele), end=" ")
        wyraz_ = input()
        try:
            lista_.append(float(wyraz_))
            nr_ele += 1
        except:
            try:
                wyraz_try = eval(wyraz_)
                lista_.append(float(wyraz_try))
                nr_ele += 1
            except:
                if wyraz_ == "":
                    break
                else:
                    print("Podana wartość nie jest liczbą")
    return lista_

def wiz(lista_: list, wynik_: float) -> None: #wizualizacja wników
    czysc_ekran()
    print("Wprowadzono listę:\n{}.".format(lista_))
    print("Obliczona suma przemienna wyrazów listy: {}.".format(wynik_))

if __name__ == "__main__":
    main()
