"""Ćwiczenie nr 5"""
"""Część 1"""
"""Zadanie nr 10"""
"""Napisz funkcje equals(a, b), która sprawdza, czy dwie listy sa identyczne, to znaczy, że mają tyle samo takich samych elementów (i w tej samej kolejnosci). Przetestuj te funkcje w funkcji main."""

def main() -> None:
    czysc_ekran()
    print("Program wczytyje dwie listy.\nNastępnie sprawdza czy są identyczne.\n")

    print("Wprowadzenie pierwszej listy.")
    lista = wprowadz_liste()
    print("Wprowadzenie drugiej listy.")
    lista_2 = wprowadz_liste()

    wynik = equals(lista, lista_2)

    wiz(lista, lista_2, wynik)

def czysc_ekran():# czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def equals(lista_: list, lista_2_: list) -> bool: #prawdza czy są identyczne
    if len(lista_) != len(lista_2_):
        return False
    else:
        if len(lista_) == 0:
            return True
        else:
            for i in range(len(lista_)):
                if lista_[i] != lista_2_[i]:
                    return False
        return True


def wprowadz_liste() -> list: # funkcja wczytuje listę
    lista_ = []
    nr_ele = 1
    wyraz_ = " "
    print("Wprowadzenie pustego elementu kończy wczytywanie listy.")
    while len(wyraz_) > 0:
        print("Wprowadź {}. element listy:".format(nr_ele), end=" ")
        wyraz_ = input()
        try:
            lista_.append(float(wyraz_))
            nr_ele += 1
        except:
            try:
                wyraz_try = eval(wyraz_)
                lista_.append(float(wyraz_try))
                nr_ele += 1
            except:
                if wyraz_ == "":
                    break
                else:
                    print("Podana wartość nie jest liczbą")
    return lista_

def wiz(lista_: list, lista_2_: list, wynik_: bool) -> None: #wizualizacja wników
    czysc_ekran()
    print("Wprowadzono listy:\n{}\n{}.".format(lista_, lista_2_))
    if wynik_:
        print("Otrzymany wynik sprawdzenia: {}. Listy są identyczne.".format(wynik_))
    else:
        print("Otrzymany wynik sprawdzenia: {}. Listy nie są identyczne.".format(wynik_))

if __name__ == "__main__":
    main()
