"""Ćwiczenie nr 5"""
"""Część 1"""
"""Zadanie nr 7"""
"""Napisz program, który wczytuje kolejną liczbę i dodaje ją do listy, o ile nie wystepuje ona jeszcze na liscie. Gdy lista zawiera dziesieć liczb, program wyswietla jej zawartość i kończy pracę."""

def main() -> None:
    czysc_ekran()
    print("Program wczytuje kolejną liczbę i dodaje ją do listy, o ile nie wystepuje ona jeszcze na liscie. Gdy lista zawiera dziesieć liczb, program wyswietla jej zawartość i kończy pracę.\n")
    lista = wprowadz_liste()
    wiz(lista)

def czysc_ekran() -> None: # czyści ekran
    try:
        print("\033c")
    except:
        print("\x1bc")

def wprowadz_liste() -> list: # funkcja wczytuje listę
    lista_ = []
    nr_ele = 1
    while nr_ele <= 10:
        print("Wprowadź {}. element listy:".format(nr_ele), end=" ")
        wyraz_ = input()
        try:
            wyraz_ = float(wyraz_)
            if lista_.count(wyraz_) == 0:
                lista_.append(wyraz_)
                nr_ele += 1
            else:
                print("Podana liczba już jest na liście. Podaj inną liczbę.")
        except:
            print("Podana wartość nie jest liczbą")
    return lista_

def wiz(lista_: list) -> None: #wizualizacja wników
    czysc_ekran()
    print("Wprowadzono listę:\n{}.".format(lista_))

if __name__ == "__main__":
    main()
