"""Ćwiczenie nr 5"""
"""Część 2"""
"""Zadanie nr 1"""
"""Napisz program, który wypisze wszystkie liczby od 0 do 6 oprócz 3 i 6. Uzyj instrukcjicontinue."""

def main() -> None:

    print("\nProgram używając instrukci continue wypisuje wszystkie liczby całkowite od 0 d0 6 oprócz 3 i 6.\n")

    input("Wciśnij ENTER aby zacząć.")

    program_01245()

def program_01245() -> None:
    for i in range (7):
        if i == 3 or i == 6:
            continue
        else:
            print(i, end = ", ")
    print("\n")
if __name__ == "__main__":
    main()
