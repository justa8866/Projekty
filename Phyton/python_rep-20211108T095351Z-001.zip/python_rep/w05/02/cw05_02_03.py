"""Ćwiczenie nr 5"""
"""Część 2"""
"""Zadanie nr 3"""
"""Napisz program, który wczytuje liczbę rzeczywistą do zmiennej lim. Nastepnie wczytując kolejne liczby rzeczywiste sumuje je tak długo, aż suma przekroczy wartość zmiennej lim.
Użyj instrukcji break."""

def main() -> None:

    print("\nProgram wwczytuje liczbę rzeczywistą do zmiennej lim. Nastepnie wczytując kolejne liczby rzeczywiste sumuje je tak długo, aż suma przekroczy wartość zmiennej lim.\n")

    lim = wczytaj_r()
    print("Limit:", lim)
    program_suma_do_lim(lim)

def program_suma_do_lim(lim_: float) -> None:
    suma_ = 0
    while True:
        wyraz_ = wczytaj_r()
        suma_ += wyraz_
        print("Suma:", suma_)
        print("Limit:", lim_)
        if suma_ > lim_:
            break

def wczytaj_r() -> float:
    spr_ = True
    while spr_ :
        n_ = input("Podaj liczbę rzeczywistą:")
        try:
            n_ = float(n_)
            spr_ = False
            return n_
        except:
            print("Podana wartość nie jest liczbą rzeczywistą.")

if __name__ == "__main__":
    main()
