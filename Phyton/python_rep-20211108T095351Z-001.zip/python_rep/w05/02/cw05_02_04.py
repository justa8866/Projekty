"""Ćwiczenie nr 5"""
"""Część 2"""
"""Zadanie nr 4"""
"""Napisz program, który wczytuje liczbę rzeczywistąa do zmiennej lim. Nastepnie wczytując kolejne liczby rzeczywiste sumuje tylko liczby dodatnie tak długo, aż suma przekroczy wartość zmiennej lim. Użyj instrukcji break oraz continue."""

def main() -> None:

    print("\nProgram wczytuje liczbę rzeczywistą do zmiennej lim. Nastepnie wczytując  kolejne liczby rzeczywiste sumuje tylko liczby dodatnie tak długo, aż suma przekroczy wartość zmiennej lim.")

    lim = wczytaj_r()
    print("Limit:", lim)
    program_suma_do_lim(lim)

def program_suma_do_lim(lim_: float) -> None:
    suma_ = 0
    while True:
        wyraz_ = wczytaj_r()
        if wyraz_ <= 0:
            continue
        suma_ += wyraz_
        print("Suma:", suma_)
        print("Limit:", lim_)
        if suma_ > lim_:
            break

def wczytaj_r() -> float:
    spr_ = True
    while spr_:
        n_ = input("Podaj liczbę rzeczywistą: ")
        try:
            n_ = float(n_)
            spr_ = False
            return n_
        except:
            print("Podana wartość nie jest liczbą rzeczywistą.")

if __name__ == "__main__":
    main()
