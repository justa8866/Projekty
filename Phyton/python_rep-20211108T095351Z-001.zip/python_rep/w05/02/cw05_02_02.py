"""Ćwiczenie nr 5"""
"""Część 2"""
"""Zadanie nr 2"""
"""Napisz program, który wczytuje liczbe całkowita do zmiennej n, a nastepnie wypisuje wszystkie liczby od 0 do n oprócz liczb podzielnych przez 3 i 6. Uzyj instrukcji continue."""

def main() -> None:

    print("\nProgram wczytuje liczbe całkowita do zmiennej n, a nastepnie wypisuje wszystkie liczby od 0 do n oprócz liczb podzielnych przez 3 i 6 (nie 3 lub 6).\n")

    n = wczytaj_n()

    program_0_100_bez_3i6(n)

def program_0_100_bez_3i6(n_: int) -> None:
    if n_ >= 0:
        for i in range(n_ + 1):
            if i % 3 == 0 and i % 6 == 0:
                continue
            else:
                print(i, end = ", ")
        print("\n")
    else:
        for i in range (n_, 1):
            if i % 3 == 0 and i % 6 == 0:
                continue
            else:
                print(i, end = ", ")
        print("\n")

def wczytaj_n() -> int:
    n_ = input("Podaj liczbę całkowitą: ")
    try:
        n_ = int(n_)
        return n_
    except:
        print("Podana wartość nie jest liczbą całkowitą")
        wczytaj_n()

if __name__ == "__main__":
    main()
