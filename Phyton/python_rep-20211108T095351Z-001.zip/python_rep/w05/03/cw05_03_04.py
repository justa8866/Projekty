"""Ćwiczenie nr 5"""
"""Część 3"""
"""Zadanie nr 4"""
"""Napisz program, który wczytuje liczbę rzeczywistą do zmiennej lim. Jeżeli ciąg znaków wprowadzony przez użytkownika, nie reprezentuje liczby rzeczywistej, to zakończ program. W przeciwnym przypadku program ma wczytywać kolejne liczby rzeczywiste i sumować dodatnie z nich tak długo, aż suma przekroczy wartość zmiennej lim. Jeżeli kolejny wprowadzony
ciąg znaków nie reprezentuje liczby rzeczywistej, to taki ciąg należy zignorować."""

def main() -> None:

    print("\nProgram wczytuje liczbę rzeczywistą do zmiennej lim.\nJeżeli ciąg znaków wprowadzony przez użytkownika nie reprezentuje liczby rzeczywistej to program zakończy się.\nW przeciwnym przypadku program ma wczytywać kolejne liczby rzeczywiste i sumować dodatnie z nich tak długo, aż suma przekroczy wartość zmiennej lim.\nJeżeli kolejny wprowadzony ciąg znaków nie reprezentuje liczby rzeczywistej, to taki ciąg należy zignorować.\n")
    lim = input("Podaj liczbę rzeczywistą (lim):")
    program_suma_do_lim(lim)
def program_suma_do_lim(lim_: str) -> None: 
    try:
        lim_ = float(lim_)
        print("Limit (lim):", lim_)
        suma_ = 0
        while True:
            wyraz_ = wczytaj_r()
            if wyraz_ <= 0:
                continue
            suma_ += wyraz_
            print("Suma:", suma_)
            print("Limit (lim):", lim_)
            if suma_ > lim_:
                break
    except:
        print("Podana wartość (lim) nie jest liczbą rzeczywistą.")
def wczytaj_r() -> float:
    while True:
        n_ = input("Podaj liczbę rzeczywistą: ")
        try:
            n_ = float(n_)
            return n_
        except:
            print("Podana wartość nie jest liczbą rzeczywistą.")
if __name__ == "__main__":
    main()
