"""Ćwiczenie nr 5"""
"""Część 3"""
"""Zadanie nr 5"""
"""Napisz funkcję, inputComplex.W funkcji main wykorzystaj funkcje inputComplex do wczytania trzech liczb zespolonych
i wypisania ich sumy."""

def main() -> None:
    print("\033c")
    print("\nProgram wykorzystuje funkcje inputComplex do wczytania trzech liczb zespolonych i wypisania ich sumy.\n")
    suma_3_zespolonych()

def suma_3_zespolonych() -> None: 
    suma_ = 0j
    liczby_ = []
    for i in range(3):
        liczba_z_ = inputComplex()
        liczby_.append(liczba_z_)
        suma_ += liczba_z_
    wiz(suma_, liczby_)

def inputComplex() -> complex:
    while True:
        z_ = input("Podaj liczbę zespoloną (a+bj, np.: 2+3j): ")
        z_ = z_.replace(" ","")
        try:
            z_ = complex(z_)
            return z_
        except:
            print("Podana wartość nie jest liczbą zespoloną (a+bj, np.: 2+3j).")
def wiz(suma_: complex, liczby_: list) -> None:
    print("\033c")
    for i in range(3):
        print("{}. wczytana liczba zespolona: {}.".format(i +1, liczby_[i]))
    print("Obliczona suma wczytanych liczb zespolonych: {}".format(suma_))
if __name__ == "__main__":
    main()
