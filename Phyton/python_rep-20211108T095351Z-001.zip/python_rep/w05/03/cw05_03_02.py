"""Ćwiczenie nr 5"""
"""Część 3"""  
"""Zadanie nr 2"""
"""Napisz program, który wczytuje liczbę całkowitą do zmiennej n. Jeżeli ciąg znaków wprowadzony przez użytkownika, nie reprezentuje liczby całkowitej, to zakoncz program. W przeciwnym przypadku program ma wypisać wszystkie liczby od 0 do n oprócz liczb podzielnych przez 3 i 6."""

def main() -> None:

    print("\nProgram wczytuje liczbę całkowitą do zmiennej n. \nJeżeli ciąg znaków wprowadzony przez użytkownika nie reprezentuje liczby całkowitejto program się kończy. \nW przeciwnym przypadku program wypisuje wszystkie liczby od 0 do n oprócz liczb podzielnych przez 3 i 6. (nie 3 lub 6).\n")

    program_n_bez_3i6()

def program_n_bez_3i6() -> None: #prawdza czy są identyczne
    n_ = input("Podaj liczbę całkowitą: ")
    try:
        n_ = int(n_)
        if n_ >= 0:
            for i in range(n_ + 1):
                if i % 3 == 0 and i % 6 == 0:
                    continue
                else:
                    print(i, end = ", ")
            print("\n")
        else:
            for i in range (n_, 1):
                if i % 3 == 0 and i % 6 == 0:
                    continue
                else:
                    print(i, end = ", ")
        print("\n")
    except:
        print("Podana wartość nie jest liczbą całkowitą.")
if __name__ == "__main__":
    main()
