"""Ćwiczenie nr 5"""
"""Część 3"""  
"""Zadanie nr 1"""
"""Jakie typy wyjatków zostaną zgłoszone przez poniższy kod i jak mozża naprawić kod, aby temu zapobiec?"""

def main() -> None:
    
    print("\nJakie typy wyjatków zostaną zgłoszone przez poniższy kod i jak moża naprawić kod, aby temu zapobiec?")
    
    numbers = [1, 2, 3, 4]
    count = 0
    total = 0
    for value in numbers:
        total = total + value
        try:
            print(total / count)
        except ZeroDivisionError:
            print("Wystąpiła próba dzielenia przez zero.")

    print("\nPo popreawkach:")
    numbers = [1, 2, 3, 4]
    count = 0
    total = 0
    for value in numbers:
        total = total + value
        count += 1
        try:
            print(total / count)
        except ZeroDivisionError:
            print("Wystąpiła próba dzielenia przez zero.")
        except :
            print("Wystąpił nieoczekiwany błąd.")
if __name__ == "__main__":
    main()
