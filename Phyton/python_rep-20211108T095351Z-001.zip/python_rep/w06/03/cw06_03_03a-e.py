"""Ćwiczenie nr 6"""
"""Część 3"""
"""Zadanie nr 3"""
"""Dla każdego z poniższych punktów napisz funkcję, która pobiera jako argumenty dwa łancuchy znaków i zwraca jako wynik:"""

zad = {"a": "Utworzyć zbiór składajacy się z małych oraz wielkich liter, które wystepują jednocześnie w obu łancuchach.", "b": "Utworzyć zbiór składajacy się z małych oraz wielkich liter, które wystepują w co najmniej jednym łancuchu.", "c": "Utworzyć zbiór składajacy się z małych oraz wielkich liter, które nie wystepują w żadnym z łancuchów.", "d": "Utworzyć zbiór składajacy sie z wszystkich znaków (innych niż litery) wystepujących jednocześnie w obu łancuchach.", "e": "Utworzyć zbiór składajacy sie z wszystkich znaków (innych niż litery) wystepujacych w co najmniej jednym łancuchu."}
import string
def main() -> None:
    print("\033c")
    print("Program wczytuje dwa łąńcychy znaków. Następnie zgodnie z wyborem użytkownika wykonuje operację na wczytanych łańcuchach.")
    lancuch_01 = input("\nPodaj pierwszy łańcuch: ")
    lancuch_02 = input("\nPodaj drugi łańcuch: ")
    wybor = wybor_zadan()
    wynik = eval("licz_" + wybor + "(lancuch_01, lancuch_02)")
    wiz(zad, wybor, lancuch_01, lancuch_02, wynik)

def licz_a(lancuch_01_: str, lancuch_02_: str) -> set: # zgodnie z polceniem a
    set_lancuch_01_ = set(lancuch_01_)
    set_lancuch_02_ = set(lancuch_02_)
    wynik_ = set(string.ascii_letters)
    wynik_.intersection_update(set_lancuch_01_, set_lancuch_02_)
    return wynik_

def licz_b(lancuch_01_: str, lancuch_02_: str) -> set: # zgodnie z polceniem b
    set_lancuch_01_ = set(lancuch_01_)
    set_lancuch_02_ = set(lancuch_02_)
    wynik_ = set(string.ascii_letters)
    set_lancuch_01_.update(set_lancuch_02_)
    wynik_.intersection_update(set_lancuch_01_)
    return wynik_

def licz_c(lancuch_01_: str, lancuch_02_: str) -> set: # zgodnie z polceniem b
    set_lancuch_01_ = set(lancuch_01_)
    set_lancuch_02_ = set(lancuch_02_)
    wynik_ = set(string.ascii_letters)
    wynik_.difference_update(set_lancuch_01_, set_lancuch_02_)
    return wynik_

def licz_d(lancuch_01_: str, lancuch_02_: str) -> set: # zgodnie z polceniem d
    set_lancuch_01_ = set(lancuch_01_)
    set_lancuch_02_ = set(lancuch_02_)
    wynik_ = set(string.printable)
    litery_ = set(string.ascii_letters)
    wynik_.difference_update(litery_)
    wynik_.intersection_update(set_lancuch_01_, set_lancuch_02_)
    return wynik_

def licz_e(lancuch_01_: str, lancuch_02_: str) -> set: # zgodnie z polceniem e
    set_lancuch_01_ = set(lancuch_01_)
    set_lancuch_02_ = set(lancuch_02_)
    wynik_ = set(string.printable)
    litery_ = set(string.ascii_letters)
    wynik_.difference_update(litery_)
    set_lancuch_01_.update(set_lancuch_02_)
    wynik_.intersection_update(set_lancuch_01_)
    return wynik_

def wybor_zadan() -> str: # wczytuje literę zadania
    while True:
        print("\033c")
        print("Wybierz instrukcję z poniższych zadań:\n\n(a) {z[a]} \n\n(b) {z[b]} \n\n(c) {z[c]}\n\n(d) {z[d]} \n\n(e) {z[e]}".format(z = zad))
        wybor_ = input("\nWybierz a, b, c, d lub e i wciśnij ENTER.\n>>>")
        if len(wybor_) > 0:
            wybor_ = wybor_[-1]
            wybor_.lower()
            znaki_ = "abcdef"
            for znak in znaki_:
                if wybor_.count(znak) > 0:
                    return(wybor_)

def wiz(zad: dict, wybor: str, lancuch_01: str, lancuch_02: str, wynik: set) -> None: # wyzualizacja wyników
    print("\033c")
    print("Wczytano łańcuch nr 1:", lancuch_01)
    print("Wczytano łańcuch nr 2:", lancuch_02)
    print("\nWybrano zadanie {}:\n". format(wybor), zad[wybor], sep = "")
    print("\nWynik:", wynik, end = "\n\n")

if __name__ == "__main__":
    main()
