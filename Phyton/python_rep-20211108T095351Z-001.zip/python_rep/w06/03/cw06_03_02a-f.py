"""Ćwiczenie nr 6"""
"""Część 3"""
"""Zadanie nr 1"""
"""Załóżmy, że dane są trzy zbiory: set1, set2 i set3. Napisz instrukcje:"""

zad = {"a": "Utworzyć zbiór tych wszystkich elementów, które należą do set1 lub set2, ale nie należą do obydwu jednoczesnie.", "b": "Utworzyć zbiór tych wszystkich elementów, które należa tylko do jednego z trzech zbiorów set1, set2 i set3.", "c": "Utworzyć zbiór wszystkich elementów, które należa do dokładnie dwóch zbiorów sposród set1, set2 i set3.", "d": "Utworzyć zbiór wszystkich tych liczb całkowitych w zakresie od 1 do 25, które nie należa do set1.", "e": "Utworzyć zbiór wszystkich tych liczb całkowitych w zakresie od 1 do 25, które nie należą do któregoś z trzech zbiorów set1, set2 i set3.", "f": "Utworzyć zbiór wszystkich tych liczb całkowitych w zakresie od 1 do 25, które nie należa do żadnego z trzech zbiorów set1, set2 i set3."}

def main() -> None:
    print("\033c")
    print("Program wczytuje trzy zbiory. Następnie zgodnie z wyborem użytkownika wykonuje operację na wczytanych zbiorach.")
    nazwy_zbiorow = ["set1", "set2", "set3"]
    sety = {}
    for nazwa in nazwy_zbiorow:
        sety[nazwa] = wczytaj_zbior(nazwa)

    wybor = wybor_zadan()
    set_123 = [sety["set1"], sety["set2"], sety["set3"]]
    wynik = eval("licz_" + wybor + "(*set_123)")
    wiz(zad, wybor, nazwy_zbiorow, sety, wynik)

def licz_a(*set_: set) -> set: # róznica symetryczna ograniczona tylko do piierwszych 2 zbiorów w instrukcji for
    if len(set_) == 0:
        return set()
    else:
        wynik_ = set_[0]
        for i in range(1, 2): # !!!len(set_) gdy ogólnie
            wynik_ = wynik_ ^ set_[i]
        return wynik_

def licz_b(*set_: set) -> set: # róznica
    if len(set_) == 0:
        return set()
    else:
        wynik_ = set_[0]
        for i in range(1, len(set_)):
            wynik_ = wynik_ - set_[i]
        return wynik_

def licz_c(*set_: set) -> set: # iloczyn parami
    if len(set_) == 0:
        return set()
    else:
        set_new_ = [set(), set(), set()]
        for i in range(len(set_)):
            set_new_[i] = set_[i].copy()
        iloczyn_ = set_[0]
        for i in range(1, len(set_)):
            iloczyn_ = iloczyn_ & set_[i]
        for i in range(len(set_)):
            set_new_[i].difference_update(iloczyn_)
        wynik_ = set_new_[0] & set_new_[-1]
        for i in range(1, len(set_)):
            suma_ = set_new_[i] & set_new_[i - 1]
            wynik_ = wynik_ | suma_
        return wynik_

def licz_d(*set_: set) -> set: # zgodnie z punktem d
    wynik_ = set()
    for i in range(25):
        wynik_.add(i + 1)
    if len(set_) == 0:
        return wynik_
    else:
        wynik_ = wynik_.difference(set_[0])
        return wynik_

def licz_e(*set_: set) -> set: # zgodnie z punktem e
    wynik_ = set()
    for i in range(25):
        wynik_.add(i + 1)
    if len(set_) == 0:
        return wynik_
    else:
        iloczyn_ = set_[0]
        for i in range(len(set_)):
            iloczyn_ = iloczyn_.intersection(set_[i])
        wynik_ = wynik_ - iloczyn_
        return wynik_

def licz_f(*set_: set) -> set: # zgodnie z punktem f
    wynik_ = set()
    for i in range(25):
        wynik_.add(i + 1)
    if len(set_) == 0:
        return wynik_
    else:
        for i in range(len(set_)):
            wynik_ = wynik_.difference(set_[i])
        return wynik_

def wybor_zadan() -> str: # wczytuje literę zadania
    while True:
        print("\033c")
        print("Wybierz instrukcję z poniższych zadań:\n\n(a) {z[a]} \n\n(b) {z[b]} \n\n(c) {z[c]}\n\n(d) {z[d]} \n\n(e) {z[e]} \n\n(f) {z[f]} ".format(z = zad))
        wybor_ = input("\nWybierz a, b, c, d, e lub f i wciśnij ENTER.\n>>>")
        if len(wybor_) > 0:
            wybor_ = wybor_[-1]
            wybor_.lower()
            znaki_ = "abcdef"
            for znak in znaki_:
                if wybor_.count(znak) > 0:
                    return(wybor_)

def wczytaj_zbior(nazwa_zbioru_: str) -> set: # tworzy zbiór
    print("\nWczytanie pustego elementu kończy tworzenie zboizu.")
    nr_ele_ = 1
    zbior_ = set()
    while True:
        set_element_ = set()
        print("Podaj {} element zbioru {}: ". format(nr_ele_, nazwa_zbioru_), end = "")
        element_ = input()
        if element_ == "":
            break
        try:
            element_ = int(element_)
        except:
            try:
                element_ = float(element_)
            except:
                try:
                    element_ = eval(element_)
                except:
                    pass
        set_element_.add(element_)
        if set_element_ <= zbior_:
            print("Podany element już należał do zbioru.")
            continue
        zbior_.add(element_)
        nr_ele_ += 1
    return zbior_

def wiz(zad: dict, wybor: str, nazwy_zbiorow: list, sety: dict, wynik: set) -> None: # wyzualizacja wyników
    print("\033c")
    for nazwa in nazwy_zbiorow:
        print("Wczytano zbior", nazwa, "=", sety[nazwa])
    print("\nWybrano zadanie {}:\n". format(wybor), zad[wybor], sep = "")
    print("\nWynik:", wynik, end = "\n\n") 

if __name__ == "__main__":
    main()
