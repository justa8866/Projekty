"""Ćwiczenie nr 6"""
"""Część 3"""
"""Zadanie nr 4"""
"""Zaimplementuj znaną starożytnym Grekom metodę obliczania liczb pierwszych nazywaną sitem Eratostenesa. Metoda ta tworzy zbiór wszystkich liczb pierwszych nie wiekszych od n. Wczytaj liczbę do zmiennej n, po czym wstaw do zbioru primes wszystkie liczby od 2 do n. Nastepnie usuń wszystkie wielokrotności liczby 2 (z wyjatkiem 2), potem wszystkie wielokrotności liczby 3 (z wyjatkiem 3) i tak dalej aż do pierwiastka z liczby n. Po zakończeniu obliczeń wypisz zbiór primes."""

def main() -> None:
    print("\033c")
    print("Program wykorzystuje metodę obliczania liczb pierwszych nazywaną sitem Eratostenesa. Metoda ta tworzy zbiór wszystkich liczb pierwszych nie wiekszych od n. Na początku wczytuje liczbę do zmiennej n, po czym wstawia do zbioru primes wszystkie liczby od 2 do n. Nastepnie usuwa wszystkie wielokrotności liczby 2 (z wyjatkiem 2), potem wszystkie wielokrotnosci liczby 3 (z wyjatkiem 3) i tak dalej aż do pierwiastka z liczby n. Po zakończeniu obliczeń program wypisze zbiór obliczonych liczb pierwszych \"primes\".")
    n = wczytaj_n()
    primes = tworz_zbior_n(n)
    primes = sito(primes, n)
    wiz(n, primes)
def tworz_zbior_n(liczba_n_: int) -> set: # tworzy zbior od 2 do n liczba_n_ liczb naturalnych
    zbior_ = set()
    if liczba_n_ < 2:
        return zbior_
    for i in range(2, liczba_n_ + 1):
        zbior_.add(i)
    return zbior_
def sito(zbior_: set, liczba_n_: int) -> set:
    import math
    if liczba_n_ < 4:
        return zbior_
    liczba_niepw_ = set()
    for i in range(2, math.floor(math.sqrt(liczba_n_)) + 1):
        for j in range(2, (liczba_n_ // i) + 1):
            liczba_niepw_.clear()
            liczba_niepw_.add(i * j)
            zbior_.difference_update(liczba_niepw_)
    return zbior_
def wczytaj_n() -> int: # wczytuje liczbę naturalną do licza_n_
    while True:
        liczba_n_ = input("\nPodaj liczbę naturalną: ")
        try:
            liczba_n_ = int(liczba_n_)
            if liczba_n_ > 0:
                return liczba_n_
            else:
                print("Podana liczba nie jest liczbą naturalną.")
        except:
            print("Podana wartość nie jest liczbą naturalną.")
def wiz(liczba_n_: int, zbior_: set) -> None: # wyzualizacja wyników
    print("\033c")
    print("Dla liczby naruralnej n = {}.".format(liczba_n_))
    print("Obliczony zbiór liczb pierwszych \"primes\": ", zbior_, sep = "", end = "\n\n")

if __name__ == "__main__":
    main()
