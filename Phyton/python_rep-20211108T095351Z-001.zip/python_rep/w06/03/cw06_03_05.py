"""Ćwiczenie nr 6"""
"""Część 3"""
"""Zadanie nr 5"""
"""Zmodyfikuj rozwiazanie poprzedniego zadania poprzez utworzenie funkcji sieve(n), która zwraca jako swój wynik zbiór liczb pierwszych nie wiekszych od n."""


def main() -> None:
    print("\033c")
    print("Program wykorzystuje metodę obliczania liczb pierwszych, nie większych niż liczba naturalna n, nazywaną sitem Eratostenesa. Po zakonczeniu obliczeń program wypisze obliczony zbiór liczb pierwszych.")    
    n = wczytaj_n()
    primes = sieve(n)
    wiz(n, primes)

def sieve(n_: int) -> set: # tworzy zbior od 2 do n n_ liczb naturalnych
    zbior_ = set()
    import math
    if n_ < 4:
        return zbior_
    for i in range(2, n_ + 1):
        zbior_.add(i)
    liczba_niepw_ = set()
    for i in range(2, math.floor(math.sqrt(n_)) + 1):
        for j in range(2, (n_ // i) + 1):
            liczba_niepw_.clear()
            liczba_niepw_.add(i * j)
            zbior_.difference_update(liczba_niepw_)
    return zbior_

def wczytaj_n() -> int: # wczytuje liczbę naturalną do licza_n_
    while True:
        n_ = input("\nPodaj liczbę naturalną: ")
        try:
            n_ = int(n_)
            if n_ > 0:
                return n_
            else:
                print("Podana liczba nie jest liczbą naturalną.")
        except:
            print("Podana wartość nie jest liczbą naturalną.")

def wiz(n_: int, zbior_: set) -> None: # wyzualizacja wyników
    print("\033c")
    print("Dla liczby naruralnej n = {}.".format(n_))
    print("Obliczony zbiór liczb pierwszych : ", zbior_, sep = "", end = "\n\n")

if __name__ == "__main__":
    main()
