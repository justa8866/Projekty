"""Ćwiczenie nr 6 Część 3 Zadanie 5 Pylint - Sito Eratostenesa"""
import math
def main() -> None:
    """Sito Eratostnesa"""
    print("\033c")
    print("Program wykorzystuje metodę obliczania liczb pierwszych,", sep="")
    print(" nie większych niż liczba naturalna n, nazywaną sitem Eratostenesa.")
    print("Po zakonczeniu obliczeń program wypisze obliczony zbiór liczb pierwszych.")
    nnn = wczytaj_nnn()
    primes = sieve(nnn)
    wiz(nnn, primes)
def sieve(nnn_: int) -> set:
    """ tworzy zbior od 2 do n nnn_ liczb naturalnych """
    zbior_ = set()
    if nnn_ < 4:
        return zbior_
    for i in range(2, nnn_ + 1):
        zbior_.add(i)
    liczba_niepw_ = set()
    for i in range(2, math.floor(math.sqrt(nnn_)) + 1):
        for j in range(2, (nnn_ // i) + 1):
            liczba_niepw_.clear()
            liczba_niepw_.add(i * j)
            zbior_.difference_update(liczba_niepw_)
    return zbior_
def wczytaj_nnn() -> int:
    """ wczytuje liczbę naturalną do licza_n_ """
    while True:
        nnn_ = input("\nPodaj liczbę naturalną: ")
        try:
            nnn_ = int(nnn_)
            if nnn_ > 0:
                return nnn_
            print("Podana liczba nie jest liczbą naturalną.")
        except ValueError:
            print("Podana wartość nie jest liczbą naturalną.")
def wiz(nnn_: int, zbior_: set) -> None:
    """ wyzualizacja wyników """
    print("\033c")
    print("Dla liczby naruralnej n = {}.".format(nnn_))
    print("Obliczony zbiór liczb pierwszych : ", zbior_, sep=" ", end="\n\n")
if __name__ == "__main__":
    main()
