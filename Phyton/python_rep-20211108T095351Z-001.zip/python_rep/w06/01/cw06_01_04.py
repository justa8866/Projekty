"""Ćwiczenie nr 6"""
"""Część 1"""
"""Zadanie nr 4"""
"""Napisz funkcję wypisz_od_konca(*args), która wypisuje w kolejnych liniach swoje argumenty od ostatniego do pierwszego."""

def main():
    print("\033c")
    print("Program wczytuje argumenty a następnie przy pomocy funkcji wypisz_od_konca(*args) wypisuje w kolejnych liniach swoje argumenty od ostatniego do pierwszego.")
    arg = wprowadz_arg()
    wypisz_od_konca(*arg)
def wypisz_od_konca(*args: str) -> None:
    if len(args) == 0:
        return None
    print("\033c")
    for i in range(1, len(args) +1):
        print(args[-i])
def wprowadz_arg() -> list: # funkcja wczytuje listę liczb rzeczywistych
    arg_ = []
    nr_ele = 1
    print("Wprowadzenie pustego elementu kończy wczytywanie argumentów.")
    while True:
        print("Wprowadź {}. argument: ".format(nr_ele), end=" ")
        wyraz_ = input()
        if wyraz_ == "":
            break
        else:
            arg_.append(wyraz_)
            nr_ele += 1
    return arg_
if __name__ == "__main__":
    main()
