"""Ćwiczenie nr 6"""
"""Część 1"""  
"""Zadanie nr 1"""
"""Napisz funkcje maksymalna(*liczby), która jako swój wynik zwraca najwiekszą z liczb podanych jako argumenty. W funkcji main przetestuj napisaną funkcję z rózną liczbą argumentów."""

def main():
    print("\033c")
    print("Program wczytuje liczby rzeczywiste a następnie przy pomocy funkcji maksymalna(*liczby) zwraca najwiekszą z liczb.")
    liczby = wprowadz_float()
    print("Największa liczba to: ", maksymalna(*liczby),"\n")
def maksymalna(*liczby: float) -> float:
    if len(liczby) == 0:
        return None
    maks = liczby[0]
    for liczba in liczby:
        if liczba > maks:
            maks = liczba
    return maks
def wprowadz_float() -> list: # funkcja wczytuje listę liczb rzeczywistych
    liczby_ = []
    nr_ele = 1
    print("Wprowadzenie pustego elementu kończy wczytywanie liczb.")
    while True:
        print("Wprowadź {}. liczbę rzeczywistą: ".format(nr_ele), end=" ")
        wyraz_ = input()
        try:
            liczby_.append(float(wyraz_))
            nr_ele += 1
        except:
            if wyraz_ == "":
                break
            else:
                print("Podana wartość nie jest liczbą rzeczywistą.")
    return liczby_
if __name__ == "__main__":
    main()
