"""Ćwiczenie nr 6"""
"""Część 1"""  
"""Zadanie nr 2"""
"""Napisz funkcje suma(*liczby), która jako swój wynik zwraca sume liczb podanych jako argumenty. W funkcji main przetestuj napisaną funkcję z różna liczba argumentów."""

def main():
    print("\033c")
    print("Program wczytuje liczby rzeczywiste a następnie przy pomocy funkcji suma(*liczby) oblicza sumę podanyc liczb.")
    liczby = wprowadz_float()
    print("Suma liczb wynosi: ", suma(*liczby),"\n")
def suma(*liczby: float) -> float:
    if len(liczby) == 0:
        return None
    suma = 0
    for a in liczby:
        suma += a
    return suma
def wprowadz_float() -> list: # funkcja wczytuje listę liczb rzeczywistych
    liczby_ = []
    nr_ele = 1
    print("Wprowadzenie pustego elementu kończy wczytywanie liczb.")
    while True:
        print("Wprowadź {}. liczbę rzeczywistą: ".format(nr_ele), end=" ")
        wyraz_ = input()
        try:
            liczby_.append(float(wyraz_))
            nr_ele += 1
        except:
            if wyraz_ == "":
                break
            else:
                print("Podana wartość nie jest liczbą rzeczywistą.")
    return liczby_
if __name__ == "__main__":
    main()
