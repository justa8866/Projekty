"""Ćwiczenie nr 6"""
"""Część 2"""
"""Zadanie nr 2"""
"""Napisz program, który wczytuje liczbę całkowitą n oraz dwie liczby zmiennoprzecinkowe lewy oraz prawy, a nastepnie wywołuje trójargumentowa funkcje wypisz_losowe, która w kolejnych n liniach wypisuje na 20 miejscach z 9 miejscami po przecinku kolejne liczby zwracane przez wywołanie random.uniform(lewy, prawy). Każde kolejne trzy cyfry w cześci całkowitej powinny być oddzielone przecinkami."""

def main():
    print("\033c")
    print("Program wczytuje liczbę naturalną oraz dwie liczby zmiennoprzecinkowe (lewy, prawy) a następnie wywołuje trójargumentową funkcję wypisz_losowe, która w kolejnych n liniach wypisuje na 20 miejscach z 9 miejscami po przecinku kolejne liczby zwracane przez wywołanie random.uniform(lewy, prawy).")
    liczba_n = wprowadz_n()
    lewy, prawy = wprowadz_lp()
    wypisz_losowe(liczba_n, lewy, prawy)
def wypisz_losowe(liczba_n_: int,lewy_: float, prawy_: float) -> None:
    import random
    print("\033c")
    if lewy_ >= prawy_ or liczba_n_<= 0:
        return None
    try:
        liczba_n_ = int(liczba_n_)
        lewy_ = float(lewy_)
        prawy_ = float(prawy_)
        for i in range (liczba_n_):
            print("{0:>20,.9f}".format(random.uniform(lewy_, prawy_)))
    except:
        return None
def wprowadz_n() -> int: # funkcja wczytuje liczbę naturalną
    while True:
        print("Wprowadź liczbę naturalną (ilość liczb losowych): ", end=" ")
        liczba_n_ = input()
        try:
            liczba_n_ = int(liczba_n_)
            if liczba_n_ > 0:
                break
            print("Wprowadzona liczba nie jest liczbą naturalną")
        except:
            print("Wprowadzona wartość nie jest licbą naturalną.")
    return liczba_n_
def wprowadz_lp() -> float: # funkcja wczytuje liczbę rzeczywistą
    while True:
        print("Wprowadź liczbę rzeczywistą (lewy): ", end=" ")
        lewy_ = input()
        try:
            lewy_ = float(lewy_)
            break
        except:
            print("Wprowadzona wartość nie jest licbą rzeczywistą.")
    while True:
        print("Wprowadź liczbę rzeczywistą (prawy): ", end=" ")
        prawy_ = input()
        try:
            prawy_ = float(prawy_)
            if prawy_ > lewy_:
                break
            print("Wprowadzona liczba nie jest liczbą rzeczywistą większą od {}.".format(lewy_))
        except:
            print("Wprowadzona wartość nie jest licbą rzeczywistą.")
    return lewy_, prawy_
if __name__ == "__main__":
    main()
