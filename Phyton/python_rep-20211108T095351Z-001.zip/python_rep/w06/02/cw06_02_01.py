"""Ćwiczenie nr 6"""
"""Część 2"""
"""Zadanie nr 1"""
"""Napisz program, który wczytuje dwie liczby lewy oraz prawy, a nastepnie wywołuje funkcje wypisz_potegi, która w kolejnych liniach wypisuje kolejne potegi dwójki: 2**lewy,2**(lewy+1),...,2**prawy. Kazde kolejne trzy cyfry powinny byc oddzielone przecinkami."""

def main():
    print("\033c")
    print("Program wczytuje dwie licby naturalne (lewy, prawy) a następnie przy pomocy funkcji wypisz_potęgi wypisuje w kolejnych liniach kolejne potęgi dwójki od potengi lewy do prawy.")
    lewy, prawy  = wprowadz_lp()
    wypisz_potengi(lewy, prawy)
def wypisz_potengi(lewy_: int, prawy_: int) -> None:
    print("\033c")
    if lewy_ > prawy_:
        return None
    try:
        lewy_ = int(lewy_)
        prawy_ = int(prawy_)
        for i in range (lewy_, prawy_ + 1):
            print("{0:,}".format(2**i)
    except:
        return None
def wprowadz_lp() -> tuple: # funkcja wczytuje liczby naturalne
    lewy_ = 0
    prawy_ = 0
    while True:
        print("Wprowadź liczbę naturalną (lewy): ", end=" ")
        lewy_ = input()
        try:
            lewy_ = int(lewy_)
            if lewy_ > 0:
                break
            print("Wprowadzona liczba nie jest liczbą naturalną")
        except:
            print("Wprowadzona wartość nie jest licbą naturalną.")
    while True:
        print("Wprowadź liczbę naturalną (prawy): ", end=" ")
        prawy_ = input()
        try:
            prawy_ = int(prawy_)
            if prawy_ > 0 and prawy_ >= lewy_:
                break
            print("Wprowadzona liczba nie jest liczbą naturalną większą lub równą {}.".format(lewy_))
        except:
            print("Wprowadzona wartość nie jest licbą naturalną.")
    return lewy_, prawy_
if __name__ == "__main__":
    main()
