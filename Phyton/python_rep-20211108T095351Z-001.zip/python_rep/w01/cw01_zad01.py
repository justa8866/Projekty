"""Ćwiczenie nr 01"""
"""Zadanie nr 1. Napisz program, który wypisuje sume dni pierwszych trzech miesiecy dowolnego roku przestepnego."""
print("Suma dni pierszuch trzech miesięcy dowolnego roku przestępnego to:",31+29+31)
