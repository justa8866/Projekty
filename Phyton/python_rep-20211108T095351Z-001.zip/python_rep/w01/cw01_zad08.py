"""Ćwiczenie nr 1"""
"""Zadanie nr 8. Napisz program, który utworzy na ekranie imitacje ponizszego obrazu Pieta Mondriana."""

import sys

szer_tab_1=42

print("\n \n")

a=("-"*szer_tab_1)
b="{:5s}|{:4s}|{:8s}|{:10s}|{:4s}|{:4s}" .format("*"*5,"*"*5,"*"*8,"*"*10,"*"*4,"*"*4)
c="{:5s}|{:4s}|{:8s}|{:10s}|{:4s}|{:4s}" .format("*"*5,"-"*5,"*"*8,"*"*10,"*"*4,"*"*4)
d="{:5s}|{:4s}|{:8s}|{:10s}|{:4s}|{:4s}" .format("*"*5,"@"*5,"*"*8,"*"*10,"*"*4,"*"*4)
e="{:5s}|{:4s}|{:8s}|{:10s}|{:4s}|{:4s}" .format("*"*5,"%"*5,"*"*8,"#"*10,"*"*4,"*"*4)

for i in range(1,16):
  if i in (3,7,13):
    print(a)
  elif i==11:
    print(c)
  elif i==12:
    print(d)
  elif i in range(4,7):
    print(e)
  else:
    print(b)

print("\n \n")
