"""Ćwiczenie nr 1"""
"""Zadanie nr 10. Napisz program, który rysuje dom, wygladajacy dokładnie tak jak ponizej."""
#     +
#    + +
#   +   +
#  +-----+
#  | .-. |
#  | | | |
#  +-+-+-+

print("    +\n   + +\n  +   +\n +-----+\n | .-. |\n | | | |\n +-+-+-+") 
