""""Ćwiczenie nr 1"""
"""Zadanie nr 5 Napisz program, który wyswietla na ekranie nazwę Python wewnatrz ramki, np.: Python . Uzyj takich znaków
jak: |, -, +."""

#print("    ____________\n   |            |\n   |   Python   |\n   |____________|")

print("   +------------+\n   |   Python   |\n   +------------+")
