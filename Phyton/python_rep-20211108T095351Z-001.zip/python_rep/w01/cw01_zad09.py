"""Ćwiczenie nr 1"""
"""Zadanie nr 9. Napisz program, który utworzy na ekranie imitacje innego (wyszukanego prze Ciebie w Internecie) obrazu Pieta Mondriana"""

szer_tab_1=15

print("\n \n")

a=("-"*szer_tab_1)
b="|{:5s}|{:7s}|" .format("#"*5,"$"*7)
c="|{:5s}|{:7s}|" .format("-"*5,"$"*7)
d="|{:5s}|{:7s}|" .format(""*5,"$"*7)
e="|{:7s}|{:5s}|" .format("$"*7,"%"*5,)
f="|{:7s}|{:5s}|" .format("$"*7,"-"*5,)
g="|{:7s}|{:5s}|" .format("$"*7,"#"*5,)

for i in range(1,16):
  if i in (1,6,15):
    print(a)
  elif i==2:
    print(b)
  elif i==3:
    print(c)
  elif i in (4,5):
    print(d)
  elif i in range(7,11):
    print(e)
  elif i==12:
    print(f)
  elif i in (13,14):
    print(g)

print("\n \n")
