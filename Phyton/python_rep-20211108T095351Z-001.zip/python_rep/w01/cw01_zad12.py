"""Ćwiczenie nr 1"""
"""Zadanie nr 12. Napisz program, który wypisuje w kolejnych liniach trzy pozycje, takie jak nazwiska Twoich trzech najlepszych przyjaciół lub trzech ulubionych filmów."""

def main():
  imie_1 = input("Podaj imię pirwszego znajomego: ")
  imie_1=sprawdzenie(imie_1)
  imie_2 = input("\nPodaj imię drugiego znajomego:  ")
  imie_2=sprawdzenie(imie_2)
  imie_3 = input("\nPodaj imię trzeciego znajomego: ")
  imie_3=sprawdzenie(imie_3)
  
  pokaz(imie_1,imie_2,imie_3)

def pokaz(imie_1,imie_2,imie_3):
  print()
  print("Imię pierwszego znajomego to: ", imie_1.capitalize())
  print("Imię drugiego znajomego to:   ", imie_2.capitalize())
  print("Imię trzeciego znajomego to:  ", imie_3.capitalize())

def sprawdzenie(imie):
  imie = imie.strip(" ")
  spr=1
  
  while (imie.isalpha() == False or len(imie)<3) and spr<2 :
    imie = input("Proszę! Podaj to imię : ")
    spr=spr+1
  while (imie.isalpha() == False or len(imie)<3) and spr==2:
    imie = input("Proszę po raz ostatni! Podaj imię: ")
    spr=spr+1
  while imie.isalpha() == True and len(imie)>2:
    print("Dziękuję!")
    break
  while (imie.isalpha() == False or len(imie)<3) and spr==3:
    print("Jak chcesz przejdźmy dalej!")
    spr=spr+1
    imie = "nie podano"
 
  return imie

main()

