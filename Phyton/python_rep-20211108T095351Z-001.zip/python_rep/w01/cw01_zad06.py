""""Ćwiczenie nr 1"""
"""Zadanie nr 6. Napisz program, który drukuje twarz podobna do nastepujacej."""

print("  \\\\\///\n +\"\"\"\"\"+\n(| ó ó |)\n  | ^ |\n | ‘-’ |\n  \+++/")
