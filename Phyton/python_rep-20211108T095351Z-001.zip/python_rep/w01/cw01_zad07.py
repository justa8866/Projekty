""""Ćwiczenie nr 1"""
"""Zadanie nr 7. Napisz program, który wypisze Twoje imie i nazwisko wielkimi literami."""

print(" *           *        *          * * *       * * *    *    *     *\n **         **       * *        *     *     *         *    **    *\n * *       * *      *   *       *     *     *         *    * *   *\n *  *     *  *     * * * *      * * *       *         *    *  *  *\n *   *   *   *    *       *     *    *      *         *    *   * *\n *    * *    *   *         *    *     *     *         *    *    **\n *     *     *  *           *   *      *     * * *    *    *     *\n") 
print()
print()
print(" *     *   * * *    *   * * *    *      *   *              *          *      *\n *     *  *         *   *        *     *    *             * *         *     *\n *     *  *         *   *        *   *      *            *   *        *   *\n *     *  *         *   * * *    * *        *           * * * *       * *\n *     *  *         *   *        *   *      *          *       *      *   *\n *     *  *         *   *        *     *    *         *         *     *     *\n  * * *    * * *    *   * * *    *      *   * * * *  *           *    *      *\n")
