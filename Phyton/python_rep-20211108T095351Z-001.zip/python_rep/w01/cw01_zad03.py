"""Ćwiczenie nr 1"""
"""Zadanie nr 3. Napisz program, który drukuje iloczyn pierwszych dziesieciu liczb całkowitych dodatnich, 1 * 2  ... * 10."""

#print("Iloczyn pierwszych dziesieciu liczb całkowitych dodatnich to:",1*2*3*4*5*6*7*8*9*10)

#print("Iloczyn pierwszych dziesieciu liczb całkowitych dodatnich to:",3628800)

import math
print("Iloczyn pierwszych dziesieciu liczb całkowitych dodatnich to:",math.factorial(10))
