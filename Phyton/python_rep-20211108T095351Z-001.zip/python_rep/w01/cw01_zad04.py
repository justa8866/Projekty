"""Ćwiczenie nr 1"""
"""Zadanie nr 4. Napisz program, który drukuje saldo konta po pierwszym, drugim i trzecim roku. Na koncie jest poczatkowo 1000 zł a oprocentowanie wynosi 6 procent rocznie."""

saldo=100.00 #Początkowe saldo konta

#print("Saldo konta po pierwszym roku wyniesie",round(saldo*1.06,2), "zł")
#print("Saldo konta po drugim roku wyniesie",round(saldo*1.06**2,2), "zł")
#print("Saldo konta po trzecim roku wyniesie",round(saldo*1.06**3,2), "zł")

#print("Saldo konta po pierwszym roku wyniesie: {:.2f} zł".format(saldo*1.06))
#print("Saldo konta po drugim roku wyniesie: {:.2f} zł".format(saldo*1.06**2))
#print("Saldo konta po trzecim roku wyniesie: {:.2f} zł".format(saldo*1.06**3))

print("Saldo konta po pierwszym roku wyniesie: {:.2f} zł\nSaldo konta po drugim roku wyniesie:    {:.2f} zł\nSaldo konta po trzecim roku wyniesie:   {:.2f} zł".format(saldo*1.06,saldo*1.06**2,saldo*1.06**3))
