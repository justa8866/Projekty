"""Ćwiczenie nr 1"""
"""Zadanie nr 11. Napisz program, który rysuje zwierze mówiace pozdrowienie. Zwierze moze byc podobne (ale nie takie samo jak nastepujace"""

print("      ////  @   --------\n    _(’\"’) //  / Hello  \ \n   /    ^ // <   Junior  |\n  //______|    \ Coder! /\n // \    /      -------\n @  (_|_)")
