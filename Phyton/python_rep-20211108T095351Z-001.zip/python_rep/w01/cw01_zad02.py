"""Ćwiczenie nr 1"""
"""Zadanie nr 2. Napisz program, który wypisuje sume pierwszych dziesieciu liczb całkowitych dodatnich, 1 + 2 + ... + 10"""

#print("Suma pierwszych dziesieciu liczb całkowitych dodatnich to:",1+2+3+4+5+6+7+8+9+10)

print("Suma pierwszych dziesieciu liczb całkowitych dodatnich to:",55)
